#include "super_string/super_string.hpp"
#include "boost/date_time/gregorian/gregorian.hpp"
#include "unit_test/testfrmwk.hpp"
#include <iostream>
 
using std::string;

void test_convert(std::string s)
{
  check("test convert", true);
  std::cout << s << std::endl;
}
 

int
main()
{

  {
    super_string s("(abc)3333()(456789) [123] (1) (cde)");
    
    //replace parens around digits with #--the digits--#
    s.replace_all_regex("\\(([0-9]+)\\)", "#--$1--#");

    check("replace_all_regex",
          s == std::string("(abc)3333()#--456789--# [123] #--1--# (cde)") );      
 
  }
  //*************************************************************
  //Split tests
  {

    super_string s("These   are   some    \t words--with whitespace");
    super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+|--", out_vec);
  
    check("split_regex succeeded", out_vec.size() == 6);      
    check("split_regex succeeded", out_vec[0] == "These");      
    check("split_regex succeeded", out_vec[4] == "with");      
    
    std::cout << "There were " << count << " tokens found." << std::endl;
      
  }
  {

    super_string s1("2006-10-01");
    super_string s2("2006/10/01");
    super_string s3("2006.10.01");

    super_string::string_vector out_vec;
    std::string re("[-/.]"); //split on - or / or .
    unsigned int count = s1.split_regex(re, out_vec);
    check("split_regex succeeded", out_vec.size() == 3);      
    check("split_regex succeeded", out_vec[0] == "2006");      
    check("split_regex succeeded", out_vec[1] == "10");      
    check("split_regex succeeded", out_vec[2] == "01");      

    out_vec.clear();
    count = s2.split_regex(re, out_vec);
    check("split_regex succeeded", out_vec.size() == 3);      
    check("split_regex succeeded", out_vec[0] == "2006");      
    check("split_regex succeeded", out_vec[1] == "10");      
    check("split_regex succeeded", out_vec[2] == "01");      

    out_vec.clear();
    count = s3.split_regex(re, out_vec);
    check("split_regex succeeded", out_vec.size() == 3);      
    check("split_regex succeeded", out_vec[0] == "2006");      
    check("split_regex succeeded", out_vec[1] == "10");      
    check("split_regex succeeded", out_vec[2] == "01");      

    std::cout << "There were " << count << " tokens found." << std::endl;
      
  }


  {
    super_string stuff("first-|-second-|-third");
    super_string::string_vector out_vec;
    if (stuff.split("-|-", out_vec)) {
      check("split succeeded", out_vec.size() == 3);      
      check("split succeeded", out_vec[0] == "first");      
      check("split succeeded", out_vec[1] == "second");      
      check("split succeeded", out_vec[2] == "third");      
    }
    else {
      check("split -- none found", false);
    }
  }
  //*************************************************************
  //Case insensitive replace
  {
    super_string s("foo Foo FOO");
    s.ireplace_all("foo", "bar");
    check("replace all", s == "bar bar bar" );
  }
  {
    super_string s("FOO foo foo");
    s.ireplace_first("foo", "bar");
    check("replace first", s == "bar foo foo" );
  }
  {
    super_string s("foo foo FOO");
    s.ireplace_last("foo", "bar");
    check("replace first", s == "foo foo bar" );
  }
  {
    super_string s("FOO foo FoO foo");
    s.ireplace_nth("foo", "bar", 2);
    check("replace nth", s == "FOO foo bar foo" );
  }
  //*************************************************************
  //Replace
  {
    super_string s("foo foo foo");
    s.replace_all("foo", "bar");
    check("replace all", s == "bar bar bar" );
  }
  {
    super_string s("foo foo foo");
    s.replace_first("foo", "bar");
    check("replace first", s == "bar foo foo" );
  }
  {
    super_string s("foo foo foo");
    s.replace_last("foo", "bar");
    check("replace first", s == "foo foo bar" );
  }
  {
    super_string s("foo of the foo of the foo of the foo");
    s.replace_nth("foo", "bar", 2);
    std::cout << s << std::endl;
    check("replace nth", s == "foo of the foo of the bar of the foo" );
  }
  //*************************************************************
  //Contains
  {
    super_string s("hello 2006-02-23");
    check("regex contains", s.contains_regex("\\d{4}-\\d{2}-\\d{2}"));
    check("regex contains", !s.contains_regex("[A-Z]"));
    check("regex contains", s.contains_regex("[a-z]"));
  }
  {
    super_string s("hello");
    check("contains", s.contains("lo"));
    check("!contains ", !s.contains("hi"));
  }
  {
    super_string s("hELlo");
    check("icontains ", s.icontains("llO"));
    check("!icontains", !s.icontains("Hi"));
  }

  {
    super_string s("hello");
    check("ends with", s.ends_with("lo"));
    check("!ends with", !s.ends_with("hi"));
  }
  {
    super_string s("hELlo");
    check("iends with", s.iends_with("llO"));
    check("!iends with", !s.iends_with("Hi"));
  }

  {
    super_string s("hello");
    check("starts with", s.starts_with("hel"));
    check("!starts with", !s.starts_with("hi"));
    check("starts with", s.starts_with("ll", 2));
  }
  {
    super_string s("hELlo");
    check("istarts with", s.istarts_with("hel"));
    check("!istarts with", !s.istarts_with("Hi"));
    check("istarts with", s.istarts_with("ll", 2));
  }
  //*************************************************************
  //append, prepend, insert_at
  {
    super_string s;
    double dbl = 1.543;
    s.append(dbl);
    check("append double", s == std::string("1.543"));
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s += " - "; //std::string method
    s.append(d);
    check("append date", s == std::string("1.543 - 2006-Jun-29"));
    
  }
  {
    super_string s("hello world");
    double dbl = 1.543;
    s.prepend(dbl);
    std::cout << s << std::endl;
    check("prepend double", s == std::string("1.543hello world"));
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s.prepend(d);
    check("prepend date", s == std::string("2006-Jun-291.543hello world"));
    
  }
  { 
    super_string s("hello  world");
    double dbl = 1.543;
    s.insert_at(6, dbl);
    std::cout << s << std::endl;
    check("insert_at double", s == std::string("hello 1.543 world"));
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s.insert_at(1, d);
    check("insert_at date", s == std::string("h2006-Jun-29ello 1.543 world"));
    
  }

  //*************************************************************
  //trim
  {
    super_string s(" \t  hello world \t");
    s.trim();
    check("trim ", s == std::string("hello world"));
  }
  {
    super_string s("   hello world ");
    super_string s2 = s.trim_copy();
    check("trim  copy", s == std::string("   hello world "));
    check("trim", s2 == std::string("hello world"));
  }

  {
    super_string s("   hello world ");
    s.trim_left();
    check("trim left", s == std::string("hello world "));
  }
  {
    super_string s("   hello world ");
    super_string s2 = s.trim_left_copy();
    check("trim left copy", s == std::string("   hello world "));
    check("trim left", s2 == std::string("hello world "));
  }
  {
    super_string s("   hello world   ");
    s.trim_right();
    check("trim right", s == std::string("   hello world"));
  }
  {
    super_string s("   hello world   ");
    super_string s2 = s.trim_right_copy();
    check("trim right copy", s == std::string("   hello world   "));
    check("trim right", s2 == std::string("   hello world"));
  }

  {
    super_string s("convert test, dude");
    test_convert(s);
  }

  //*************************************************************
  //case conversion
  {
    super_string s("lower");
    s.to_upper();
    check("to upper test", s == std::string("LOWER"));
  }
  {
    super_string s("UPPsdf sdf sdf E sdf d 123&88))");
    s.to_lower();
    check("to lower test", s == std::string("uppsdf sdf sdf e sdf d 123&88))"));
  }

  {
    super_string s("lower");
    super_string s2 = s.to_upper_copy();
    check("to upper copy test", s2 == std::string("LOWER"));
  }
  {
    super_string s("UPPsdf sdf sdf E sdf d 123&88))");
    super_string s2 = s.to_lower_copy();
    check("to lower test", s2 == std::string("uppsdf sdf sdf e sdf d 123&88))"));
  }
  

  //*************************************************************
  //wide string tests
  {
    wsuper_string s(L"   hello world ");
    s.trim_left();
    check("trim left", s == std::wstring(L"hello world "));
  }


  return printTestStats();
}
