#ifndef _BASIC_SUPER_STRING_HPP__
#define _BASIC_SUPER_STRING_HPP__


/* Copyright 2006 CrystalClear Software, Inc.
 * Use, modification and distribution is subject to the 
 * Boost Software License, Version 1.0. (See accompanying
 * file LICENSE-1.0 or http://www.boost.org/LICENSE-1.0)
 *
 * Author:  Jeff Garland 
 * Last Modified: $Date: 2006/07/02 00:25:07 $
 * Created: Sat Jun  29 14:02:41 2006 
 */


#include <boost/algorithm/string.hpp>
#include "boost/algorithm/string/regex.hpp"
#include <boost/regex.hpp>
#include <string>
#include <vector>
#include <sstream>


/** Souped up string class that includes fancy query, replacement, 
 *  and conversion functions.
 * 
 *  This type has the following main goals:
 *  - Is a drop-in replacement convertable to std::string and std::wstring
 *  - Provide case conversions and case insensitive comparison
 *  - Provide white space triming functions
 *  - Provide a split functions to parse a string into pieces base on string or regex
 *  - Provide sophisticated text replacement functions based on strings or regex
 *  - Provide append and insert functions for types
 *  - Blow the doors off Java string ;-)
 *
 * Overall, this class is mostly a convience wrapper around functions
 * available in  boost.string_algo and boost.regex.  This is best illustrated
 * with some code:
 *
 *@code

  super_string s("    (456789) [123]  2006-10-01    abcdef   ");
  s.to_upper();
  cout << s << endl;
  
  s.trim();  //lop of the whitespace on both sides
  cout << s << endl;
  
  double dbl = 1.23456;
  s.append(dbl);  //append any streamable type 
  s+= "  ";
  cout << s << endl;
  
  date d(2006, Jul, 1);
  s.insert_at(28, d);  //insert any streamable type
  cout << s << endl;
  
  //find the yyyy-mm-dd date format
  if (s.contains_regex("\\d{4}-\\d{2}-\\d{2}")) {
    //replace parens around digits with square brackets [the digits]
    s.replace_all_regex("\\(([0-9]+)\\)", "__[$1]__");
    cout << s << endl;
    
    
    //split the string on white space to process parts
    super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+", out_vec);
    if (count) {
      for(int i=0; i < out_vec.size(); ++i) {
        out_vec[i].replace_first("__","");  //get rid of first __ in string
        cout << i << "  " << out_vec[i] << endl;
      }
    }
  }
  
  //wide strings too...
  wsuper_string ws(L"   hello world ");
  ws.trim_left();
  wcout << ws << endl;
 @endcode
 *
 @code
 Expected output is:


    (456789) [123]  2006-10-01    ABCDEF   
(456789) [123]  2006-10-01    ABCDEF
(456789) [123]  2006-10-01    ABCDEF1.23456  
(456789) [123]  2006-10-01  2006-Jul-01  ABCDEF1.23456  
__[456789]__ [123]  2006-10-01  2006-Jul-01  ABCDEF1.23456  
0  [456789]__
1  [123]
2  2006-10-01
3  2006-Jul-01
4  ABCDEF1.23456
hello world 
 @endcode
 
*/
template<class char_type>
class basic_super_string : public std::basic_string<char_type> {
public:
  typedef std::basic_string<char_type>                base_string_type;
  typedef typename base_string_type::const_iterator   iterator_type;
  typedef typename base_string_type::size_type        size_type;
  typedef std::basic_stringstream<char_type>          string_stream_type;
  typedef std::vector<basic_super_string<char_type> > string_vector;
  
  basic_super_string() 
  {}

  basic_super_string(const base_string_type& s) :
    base_string_type(s)
  {}

  basic_super_string(iterator_type beg, iterator_type end) :
    base_string_type(beg, end)
  {}


  //See if the string contains the regular expression somewhere
  bool contains_regex (const base_string_type& s) const;

  //Query functions for start / contains
  bool contains    (const base_string_type& s) const;
  bool starts_with (const base_string_type& s, size_type offset=0) const;
  bool ends_with   (const base_string_type& s) const;

  //Case insensitive query functions 
  bool icontains   (const base_string_type& s) const;
  bool istarts_with(const base_string_type& s, size_type offset=0) const;
  bool iends_with  (const base_string_type& s) const;

  //Split the string based on the predicate string
  unsigned int split(const base_string_type& predicate, 
                     string_vector& result)             const;

  unsigned int split_regex(const base_string_type& predicate_regex, 
                           string_vector& result)             const;
  

  //Enhanced replace functions
  void         replace_all_regex  (const base_string_type& match_regex, 
                                   const base_string_type& replace_regex);

  void         replace_first(const base_string_type& match_string, 
                             const base_string_type& replace_string);
  void         replace_last (const base_string_type& match_string, 
                             const base_string_type& replace_string);
  void         replace_nth  (const base_string_type& match_string, 
                             const base_string_type& replace_string, 
                             size_type n);
  void         replace_all  (const base_string_type& match_string, 
                             const base_string_type& replace_string);

  //Case insensitive enhanced replace functions
  void         ireplace_first(const base_string_type& match_string, 
                              const base_string_type& replace_string);
  void         ireplace_last (const base_string_type& match_string, 
                              const base_string_type& replace_string);
  void         ireplace_nth  (const base_string_type& match_string, 
                              const base_string_type& replace_string, 
                              size_type n);
  void         ireplace_all  (const base_string_type& match_string, 
                              const base_string_type& replace_string);
  
  //White space trimming functions
  void               trim();
  void               trim_left();
  void               trim_right();
  basic_super_string trim_copy()       const;
  basic_super_string trim_left_copy()  const;
  basic_super_string trim_right_copy() const;
  

  //Case Conversion
  void               to_upper();
  void               to_lower();
  basic_super_string to_lower_copy() const;
  basic_super_string to_upper_copy() const;


  //Type  conversion functions
  template<class T> void append    (const T& value);
  template<class T> void prepend   (const T& value);
  template<class T> void insert_at (size_type pos, const T& value);

private:

};


/** Split a string into a string of vectors based on equality to a string
 *
 *@code
    super_string stuff("first-|-second-|-third");
    super_string::string_vector out_vec;
    if (stuff.split("-|-", out_vec)) {
      //iterate thru the vector and process
      //out_vec[0] == first
      //out_vec[1] == second
      //out_vec[2] == third
    }
 *@endcode
 *@returns count of splits found
 *@param predicate String used to test against.
 *@param result Returns the each split string or the whole string as the first element
 *              of the vector.
 */
template<class char_type>
inline
unsigned int 
basic_super_string<char_type>::split(const base_string_type& predicate, 
                                     string_vector& result) const
{

  namespace alg = boost::algorithm;
  
  alg::iter_split(result, *this, 
                  alg::first_finder(predicate, alg::is_equal()));
  
  //iter_split will return entire string if no matches found
  return result.size()-1; //todo bug here is result not empty
}

/** Split a string into a string of vectors based regex string.
 *
 *@code
    super_string s("These   are   some    \t words--with whitespace");
    super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+|--", out_vec);

    if (count) {
      //iterate thru the vector and process
      //out_vec[0] == These
      //out_vec[4] == with
    }
 *@endcode
 *@returns count of splits found
 *@param predicate_regex Regular expression used to find string split points.
 *@param result Returns the each split string or the whole string as the first element
 *              of the vector.
 */
template<class char_type>
inline
unsigned int 
basic_super_string<char_type>::split_regex(const base_string_type& predicate_regex, 
                                           string_vector& result)  const
{

  boost::basic_regex<char_type> re(predicate_regex);
  boost::regex_token_iterator<iterator_type> i(this->begin(), this->end(), re, -1);
  boost::regex_token_iterator<iterator_type> j;
  
  unsigned int count = 0;
  while(i != j) {
    base_string_type s = *i;
    result.push_back(s);
    count++;
    i++;
  }
  return count;
  
}


/** Query function using regular expression
 * 
 *
 @code
    super_string s("hello 2006-02-23");
    s.contains_regex("\\d{4}-\\d{2}-\\d{2}")); //true
    s.contains_regex("[A-Z]")); //false
 @endcode
 *
 *@param predicate_regex regular expression predicate_string string to check against
 *@throw boost::regex_error if predicate_string is not a valid regular expression
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::contains_regex(const base_string_type& predicate_regex) const
{
  boost::regex::basic_regex<char_type> pred(predicate_regex);
  return boost::regex_search(*this,
                             pred,
                             boost::match_default);
}


/** Replace the all instance of the match_string with the replace_format.

 @code

    super_string s("(abc)3333()(456789) [123] (1) (cde)");
    
    //replace parens around digits with #--the digits--#
    s.replace_all_regex("\\(([0-9]+)\\)", "#--$1--#");

    //s == "(abc)3333()#--456789--# [123] #--1--# (cde)"      

  @endcode
 *
 *@throw boost::regex_error if match_regex is not a valid regular expression
 *@param match_regex Regular expression to match against
 *@param replace_format Replacement expresssion
 */
template<class char_type>
inline
void
basic_super_string<char_type>::replace_all_regex(const base_string_type& match_regex, 
                                                 const base_string_type& replace_format) 
{
  boost::regex::basic_regex<char_type> pred(match_regex);
  boost::algorithm::replace_all_regex(*this, pred, replace_format);
}


/** Replace the all instance of the match_string with the replace_string
 * Has no effect on the string if there are no instances of match_string
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_all("foo", "bar", 1);
    //s == "bar bar bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
void
basic_super_string<char_type>::replace_all(const base_string_type& match_string, 
                                           const base_string_type& replace_string) 
{
  boost::algorithm::replace_all(*this, match_string, replace_string);
}


/** Replace the nth instance of the match_string with the replace_string
 * Has no effect on the string if there is no 'nth' version of the match
 * string.
 *@code
    super_string s("foo foo foo");
    s.replace_nth("foo", "bar", 1);
    //s == "foo bar foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 *@param n The instance to replace starting at 0
 */
template<class char_type>
inline
void
basic_super_string<char_type>::replace_nth(const base_string_type& match_string, 
                                           const base_string_type& replace_string,
                                           size_type n) 
{
  boost::algorithm::replace_nth(*this, match_string, n, replace_string);
}


/** Replace the first instance of the match_string with the replace_string
 * Has no effect on the string if there is  match_string does not appear 
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_first("foo", "bar");
    //s == "bar foo foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
void
basic_super_string<char_type>::replace_first(const base_string_type& match_string, 
                                             const base_string_type& replace_string) 
{
  this->replace_nth(match_string, replace_string, 0);
}


/** Replace the last instance of the match_string with the replace_string
 * Has no effect on the string if there is  match_string does not appear 
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_last("foo", "bar");
    //s == "foo foo bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
void
basic_super_string<char_type>::replace_last(const base_string_type& match_string, 
                                            const base_string_type& replace_string) 
{
  boost::algorithm::replace_last(*this, match_string, replace_string);
}

/** Case insensitive replace the all instance of the match_string with the replace_string
 * Has no effect on the string if there are no instances of match_string
 * in the string.
 *@code
    super_string s("foo FOO Foo");
    s.ireplace_all("foo", "bar", 1);
    //s == "bar bar bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
void
basic_super_string<char_type>::ireplace_all(const base_string_type& match_string, 
                                           const base_string_type& replace_string) 
{
  boost::algorithm::ireplace_all(*this, match_string, replace_string);
}


/** Case insensitive replace of the nth instance of the match_string 
 *  with the replace_string. Has no effect on the string if there is 
 *  no 'nth' version of the match string.
 *@code
    super_string s("foo FOO foo");
    s.ireplace_nth("foo", "bar", 1);
    //s == "foo bar foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 *@param n The instance to replace starting at 0
 */
template<class char_type>
inline
void
basic_super_string<char_type>::ireplace_nth(const base_string_type& match_string, 
                                            const base_string_type& replace_string,
                                            size_type n) 
{
  boost::algorithm::ireplace_nth(*this, match_string, n, replace_string);
}


/** Case insensitive replace the first instance of the match_string 
 *  with the replace_string.  Has no effect on the string if there 
 *  match_string does not appear in the string.
 *@code
    super_string s("FOO foo foo");
    s.ireplace_first("foo", "bar");
    //s == "bar foo foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
void
basic_super_string<char_type>::ireplace_first(const base_string_type& match_string, 
                                             const base_string_type& replace_string) 
{
  this->ireplace_nth(match_string, replace_string, 0);
}


/** Case insensitive replace of the last instance of the match_string 
 *  with the replace_string.  Has no effect on the string if there 
 *  match_string does not appear in the string.
 *@code
    super_string s("foo foo FOO");
    s.ireplace_last("foo", "bar");
    //s == "foo foo bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
void
basic_super_string<char_type>::ireplace_last(const base_string_type& match_string, 
                                             const base_string_type& replace_string) 
{
  boost::algorithm::ireplace_last(*this, match_string, replace_string);
}


/** Query function to see if a string contains given string.
 * 
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::contains(const base_string_type& predicate_string) const
{
  return boost::algorithm::contains(*this, predicate_string);
}

/** Case insensitive query function to see if a string contains
 *  a given string.
 * 
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::icontains(const base_string_type& predicate_string) const
{
  return boost::algorithm::icontains(*this, predicate_string);
}


/** Query function to see if a string or substring ends with a given string.
 * 
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::ends_with(const base_string_type& predicate_string) const
{
  return boost::algorithm::ends_with(*this, predicate_string);
}

/** Case insensitive query function to see if a string or substring ends 
 *  with a given string.
 @code
    super_string s("hELlo");
    s.iends_with("llO"); //true
    s.iends_with("Hi")   //false
 @endcode
 *
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::iends_with(const base_string_type& predicate_string) const
{
  return boost::algorithm::iends_with(*this, predicate_string);
}


/** Query function to see if a string or substring starts with a given string.
 * 
 *@param predicate_string string to check against
 *@param offset point in string to start at - 0 is first position.
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::starts_with(const base_string_type& predicate_string,
                                           size_type offset) const
{
  return boost::algorithm::starts_with(this->substr(offset), predicate_string);
}

/** Case insensitive query function to see if a string or substring starts 
 *  with a given string.
 *@code

    super_string s("hELlo");
    s.istarts_with("el", 1); //returns true

 *@endcode
 *@param predicate_string string to check against
 *@param offset point in string to start at - 0 is first position.
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::istarts_with(const base_string_type& predicate_string, 
                                            size_type offset) const
{
  return boost::algorithm::istarts_with(this->substr(offset), predicate_string);
}


/** Generic function to append any type to the string
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    s.append(dbl);
    s += " - "; //std::string method
    //append a date to the string
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s.append(d);
    //s == "1.543 - 2006-Jun-29"

@endcode
 *
 */
template<class char_type>
template<class T>
inline
void 
basic_super_string<char_type>::append(const T& value)
{
  string_stream_type ss;
  ss << value;
  *this += ss.str();
}

/** Generic function to prepend any type to the string
 *  This function will work with any type that is OutputStreamable.

@code

    super_string s( "Hello There");
    double dbl = 1.543;
    s.prepend(dbl);
    //s == "1.543 Hello There"

@endcode

 *
 */
template<class char_type>
template<class T>
inline
void 
basic_super_string<char_type>::prepend(const T& value)
{
  string_stream_type ss;
  ss << value;
  this->insert(0, ss.str());
}

/** Generic function to insert an OutputStreamable type into the string.
 *  
@code

    super_string s( "Hello  There");
    double dbl = 1.543;
    s.prepend(dbl);
    //s == "Hello 1.543 There"

@endcode
 *@param position Zero-based index of location in string to insert data
 *@param value Value to insert into the string
 */
template<class char_type>
template<class T>
inline
void 
basic_super_string<char_type>::insert_at(size_type position, const T& value)
{
  string_stream_type ss;
  ss << value;
  this->insert(position, ss.str());
}



/** Trim in-place whitespace from the both sides of the string.
 * 
 *
 */
template<class char_type>
inline
void 
basic_super_string<char_type>::trim()
{
  boost::algorithm::trim(*this);
}


/** Trim whitespace from the both sides of the string making a copy.
 * 
 *
 */
template<class char_type>
inline
basic_super_string<char_type>
basic_super_string<char_type>::trim_copy() const
{
  base_string_type s = *this;
  boost::algorithm::trim(s);
  return s;
}


/** Trim in-place whitespace from the left side of the string.
 * 
 *
 */
template<class char_type>
inline
void 
basic_super_string<char_type>::trim_left()
{
  boost::algorithm::trim_left(*this);
}


/** Trim whitespace from the left side of the string making a copy.
 * 
 *
 */
template<class char_type>
inline
basic_super_string<char_type>
basic_super_string<char_type>::trim_left_copy() const
{
  base_string_type s = *this;
  boost::algorithm::trim_left(s);
  return s;
}

/** Trim in-place whitespace from the right side of the string.
 * 
 *
 */
template<class char_type>
inline
void 
basic_super_string<char_type>::trim_right()
{
  boost::algorithm::trim_right(*this);
}


/** Trim whitespace from the right side of the string making a copy.
 * 
 *
 */
template<class char_type>
inline
basic_super_string<char_type>
basic_super_string<char_type>::trim_right_copy() const
{
  base_string_type s = *this;
  boost::algorithm::trim_right(s);
  return s;
}


/** Change to upper case using the standard locale
 * 
 *
 */
template<class char_type>
inline
void
basic_super_string<char_type>::to_upper()
{
  boost::algorithm::to_upper(*this);
}


/** Change to lower case using the standard locale
 * 
 *
 */
template<class char_type>
inline
void
basic_super_string<char_type>::to_lower()
{
  boost::algorithm::to_lower(*this);
}


/** Change to upper case using the standard locale
 * 
 *
 */
template<class char_type>
inline
basic_super_string<char_type>
basic_super_string<char_type>::to_upper_copy() const
{
  base_string_type s = *this;
  boost::algorithm::to_upper(s);
  return s;
}


/** Change to lower case using the standard locale
 * 
 *
 */
template<class char_type>
inline
basic_super_string<char_type>
basic_super_string<char_type>::to_lower_copy() const
{
  base_string_type s = *this;
  boost::algorithm::to_lower(s);
  return s;
}


typedef basic_super_string<char>    super_string;
typedef basic_super_string<wchar_t> wsuper_string;


#endif
