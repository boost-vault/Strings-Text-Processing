
/*expected  output
    (456789) [123]  2006-10-01    ABCDEF   
(456789) [123]  2006-10-01    ABCDEF
(456789) [123]  2006-10-01    ABCDEF1.23456  
(456789) [123]  2006-10-01  2006-Jul-01  ABCDEF1.23456  
__[456789]__ [123]  2006-10-01  2006-Jul-01  ABCDEF1.23456  
0  [456789]__
1  [123]
2  2006-10-01
3  2006-Jul-01
4  ABCDEF1.23456
hello world 
*/
#include "super_string/super_string.hpp"
#include "boost/date_time/gregorian/gregorian.hpp"
#include <iostream>
 
using std::string;
using std::cout;
using std::wcout;
using std::endl;
using namespace boost::gregorian;


int
main()
{

  super_string s("    (456789) [123]  2006-10-01    abcdef   ");
  s.to_upper();
  cout << s << endl;
  
  s.trim();  //lop of the whitespace on both sides
  cout << s << endl;
  
  double dbl = 1.23456;
  s.append(dbl);  //append any streamable type 
  s+= "  ";
  cout << s << endl;
  
  date d(2006, Jul, 1);
  s.insert_at(28, d);  //insert any streamable type
  cout << s << endl;
  
  //find the yyyy-mm-dd date format
  if (s.contains_regex("\\d{4}-\\d{2}-\\d{2}")) {
    //replace parens around digits with square brackets [the digits]
    s.replace_all_regex("\\(([0-9]+)\\)", "__[$1]__");
    cout << s << endl;
    
    
    //split the string on white space to process parts
    super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+", out_vec);
    if (count) {
      for(int i=0; i < out_vec.size(); ++i) {
        out_vec[i].replace_first("__","");  //get rid of first __ in string
        cout << i << "  " << out_vec[i] << endl;
      }
    }
  }
  
  //wide strings too...
  wsuper_string ws(L"   hello world ");
  ws.trim_left();
  wcout << ws << endl;
  
  return 0;

}
