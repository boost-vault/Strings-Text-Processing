#ifndef LIBS_EXPRESSIVE_PROTO_EXAMPLE_LOOKAHEAD_EXPR_HPP
#define LIBS_EXPRESSIVE_PROTO_EXAMPLE_LOOKAHEAD_EXPR_HPP
#include <boost/xpressive/proto/tags.hpp>
#include <boost/fusion/tuple.hpp>
#include <boost/mpl/range_all.hpp>
#include <boost/mpl/size.hpp>
#include <boost/utility/object_tracked.hpp>
#include <bitset>

namespace boost
{
namespace lookahead
{
  template
  < class
  >
  char const**
enum_names
  ( void
  )
;
namespace special
{
      enum
    numerals
    /**@brief
     *  Special vocabulary
     */
    { epsilon //epsilon, i.e. empty string
    };
        static
      char const*
    names[]=
    { "epsilon"
    };
    
}//exit special namespace

  template
  <
  >
  char const**
enum_names
  < special::numerals
  >
  ( void
  )
{
    return special::names;
}

}//exit lookahead namespace

namespace mpl 
{ 
namespace aux 
{

template<> struct integral_rank<lookahead::special::numerals> : integral_rank<unsigned> 
{
    typedef unsigned diff_type;
    typedef lookahead::special::numerals limits_type;
    static limits_type const min_limit=lookahead::special::epsilon;
    static limits_type const max_limit=lookahead::special::epsilon;
};

}}//exit mpl::aux namespace

namespace lookahead
/**@brief
 *  Define classes needed to extend proto grammar expressions with
 *  lookahead attributes:
 *
 *  NOTATION:
 *    In the following, terminal means terminal as used in
 &    defining grammars, *not* terminal as used in proto.
 *
 *    empty: can the expression derive empty string?
 *    first: the set of terminals
 *      that can start strings derived from the expresssion.
 *    follow: the set of terminals
 *      that can follow strings derived from the expresssion.
 */
{
    typedef
#ifdef BOOST_IO_FILTERS_MOUT_HPP
  marg_ostream
#else
  std::ostream
#endif      
ostrm_type
;
  template
  < class Numerals
  >
  struct
numeral_set
/**@brief
 *  Set of Numerals
 */
: std::bitset
  < mpl::size<mpl::range_all<Numerals> >::value
  >
{
        static
      unsigned const
    our_size
    =mpl::size<mpl::range_all<Numerals> >::value
    ;
        typedef
      std::bitset<our_size>
    super_type
    ;
    numeral_set
      ( void
      )
    {}
    numeral_set
      ( Numerals a_num
      )
    {
        this->set(a_num);
    }
    numeral_set
      ( numeral_set const& a_this
      )
    : super_type(a_this)
    {}
      numeral_set&
    set
      ( Numerals Num
      )
    {
        super_type::set(Num);
        return *this;
    }
        friend
      numeral_set
    operator|
      ( numeral_set const& left
      , numeral_set const& right
      )
    {
        return static_cast<super_type const&>(left) 
             | static_cast<super_type const&>(right)
        ; 
    }
      numeral_set const&
    operator=
      ( numeral_set const& a_that
      )
    {
        if(this != &a_that)
        {
            super_type::operator=(static_cast<super_type const&>(a_that));
        }
        return *this;
    }
      numeral_set const&
    operator|=
      ( numeral_set const& a_that
      )
    {
        super_type::operator|=(static_cast<super_type const&>(a_that));
        return *this;
    }
        
        friend
      ostrm_type&
    operator<<
      ( ostrm_type& a_strm
      , numeral_set const& a_set
      )
    {
        char const**names=enum_names<Numerals>();
        a_strm<<"{ ";
        unsigned j=0;
        for( unsigned i=0; i<our_size;++i)
        {
            if(a_set.test(i))
            {
                if(j>0)
                { 
                    a_strm<<", ";
                }
                ++j;
                a_strm<<names[i];
            }
        }
        a_strm<<"} ";
        return a_strm;
    }
 private:    
    numeral_set
      ( super_type const& a_super
      )
    : super_type(a_super)
    {}
};
  
  enum
numerals_empty
{ empty_unknown  
, empty_not      //grammar expression cannot derive empty string
, empty_yes      //grammar expression can    derive empty string
};

  template
  <
  >
  char const**
enum_names
  < numerals_empty
  >
  ( void
  )
{
        static
      char const*
    names[]=
    { "empty_unknown"
    , "empty_not"
    , "empty_yes"
    };
    return names;
}    

  enum
numerals_attr
{ attr_empty
, attr_first
, attr_follow
};

  template
  <
  >
  char const**
enum_names
  < numerals_attr
  >
  ( void
  )
{
        static
      char const*
    names[]=
    { "empty"
    , "first"
    , "follow"
    };
    return names;
}    

  template
  < numerals_attr Num
  , class NumeralsInp
  >
  struct
attr_value
{
        typedef
      numeral_set<NumeralsInp>
    type
    ;
};    
  template
  < class NumeralsInp
  >
  struct
attr_value
  < attr_empty
  , NumeralsInp
  >
{
        typedef
      numerals_empty
    type
    ;
};    
  template
  < class NumeralsInp
  >
  struct
delta
/**@brief
 *  The "delta" or difference between the unextended and extended
 *  grammar expression.
 */
: utility::object_tracked
{
        typedef
      fusion::tuple
      < typename attr_value
        < attr_empty
        , NumeralsInp
        >::type
      , typename attr_value
        < attr_first
        , NumeralsInp
        >::type
      , typename attr_value
        < attr_follow
        , NumeralsInp
        >::type
      >
    tuple_type
    ;
      tuple_type
    my_tuple
    ;
 public:
        typedef
      numeral_set<NumeralsInp>
    numeralset_type
    ;
      template
      < numerals_attr Num
      >
      typename fusion::result_of::at_c<tuple_type,int(Num)>::type
    mut_attr
      ( void
      )
    {
        return fusion::at_c<Num>(my_tuple);
    }
      template
      < numerals_attr Num
      >
      void 
    put_attr
      ( typename fusion::result_of::at_c<tuple_type const,int(Num)>::type value_attr
      )
    {
        fusion::at_c<Num>(my_tuple)=value_attr;
    }
      template
      < numerals_attr Num
      >
      typename fusion::result_of::at_c<tuple_type const,int(Num)>::type
    get_attr
      ( void
      )const
    {
        return fusion::at_c<Num>(my_tuple);
    }
      numerals_empty
    get_empty(void)const
    {
        return get_attr<attr_empty>();
    }
      numeralset_type const&
    get_first(void)const
    {
        return get_attr<attr_first>();
    }
      numeralset_type const&
    get_follow(void)const
    {
        return get_attr<attr_follow>();
    }
      numeralset_type
    get_dirsymb(void)const
    {
        numeralset_type result=get_attr<attr_first>();
        if(get_attr<attr_empty>() == empty_yes)
        {
            result|=get_attr<attr_follow>();
        }
        return result;
    }
 protected:
    delta(void)
    {
        numerals_empty a_empty(empty_unknown);
        put_attr<attr_empty>(a_empty);
    }
    delta(NumeralsInp a_inp)
    /**@brief
     *  Should only be called by extension of terminal expression.
     */
    {
        numerals_empty a_empty(empty_not);
        put_attr<attr_empty>(a_empty);
        numeralset_type a_first(a_inp);
        put_attr<attr_first>(a_first);
    }
    delta(numerals_empty a_num)
    /**@brief
     *  Should only be called with a_num == empty_yes
     *  and by delta_term_expr<.,TermArg0,special::numerals> ctor
     *  where TermArg0::value = special::epsilon.
     */
    {
        numerals_empty a_empty(empty_yes);
        put_attr<attr_empty>(a_empty);
    }
    delta(delta const& a_that)
    : my_tuple(a_that.my_tuple)
    {}
      delta const&
    operator=(delta const& a_that)
    {
        my_tuple=a_that.my_tuple;
        return *this;
    }
      void
    put_empty(numerals_empty a_empty)
    {
        put_attr<attr_empty>(a_empty);
    }
      void
    put_first(numeralset_type const& a_first)
    {
        put_attr<attr_first>(a_first);
    }
 public:
      void
    put_follow(numeralset_type const& a_follow)
    {
        put_attr<attr_follow>(a_follow);
    }
};
  template
  < class NumeralsInp
  , class TermArg0
  , class Value
  >
  struct
delta_term_expr
: delta
  < NumeralsInp
  >
{
};
  template
  < class NumeralsInp
  , class TermArg0
  >
  struct
delta_term_expr
  < NumeralsInp
  , TermArg0
  , special::numerals
  >
/**@brief
 *  Represents a terminal expression in grammar.
 */
: delta
  < NumeralsInp
  >
{
        typedef
      delta
      < NumeralsInp
      >
    super_type
    ;
    delta_term_expr(void)
    : super_type
      ( empty_yes
      )
    {}
};
  template
  < class NumeralsInp
  , class TermArg0
  >
  struct
delta_term_expr
  < NumeralsInp
  , TermArg0
  , NumeralsInp
  >
/**@brief
 *  Represents a terminal expression in grammar.
 */
: delta
  < NumeralsInp
  >
{
        typedef
      delta
      < NumeralsInp
      >
    super_type
    ;
    delta_term_expr(void)
    : super_type
      ( TermArg0::value
      )
    {}
};
  template
  < class NumeralsInp
  , class Expr
  , class Tag
  >
  struct
delta_tag_expr
: delta
  < NumeralsInp
  >
{
        typedef
      delta
      < NumeralsInp
      >
    super_type
    ;
        typedef
        typename
      super_type::numeralset_type
    numeralset_type
    ;
    delta_tag_expr(void)
    : super_type(empty_unknown)
    {}
      void
    put_empty(numerals_empty a_empty)
    {
        super_type::put_empty(a_empty);
    }
      void
    put_first(numeralset_type const& a_first)
    {
        super_type::put_first(a_first);
    }
};
  template
  < class NumeralsInp
  , class Expr
  >
  struct
delta_tag_expr
  < NumeralsInp
  , Expr
  , boost::proto::tag::terminal
  >
: delta_term_expr
  < NumeralsInp
  , typename Expr::proto_arg0
  , typename Expr::proto_arg0::value_type
  >
{
        typedef
      delta_term_expr
      < NumeralsInp
      , typename Expr::proto_arg0
      , typename Expr::proto_arg0::value_type
      >
    super_type
    ;
        typedef
        typename
      super_type::numeralset_type
    numeralset_type
    ;
    delta_tag_expr(void)
    {}
      void
    put_empty(numerals_empty a_empty)
    {
        super_type::put_empty(a_empty);
    }
      void
    put_first(numeralset_type const& a_first)
    {
        super_type::put_first(a_first);
    }
    
};
  template
  < class NumeralsInp
  , class Expr
  >
  struct
delta_expr
: delta_tag_expr
  < NumeralsInp
  , Expr
  , typename Expr::proto_tag
  >
{
};
  template
  < class NumeralsInp
  , class Expr
  >
  struct
expr
;
  template
  < class NumeralsInp
  >
  struct
generator
{
    template<typename Expr>
    struct apply
    {
        typedef expr<NumeralsInp,Expr> type;
    };
    
    template<typename Expr>
    static expr<NumeralsInp,Expr> make(Expr const &extendee)
    {
        typedef expr<NumeralsInp,Expr> expr_type;
        return expr_type(extendee);
    }
};
  template
  < class NumeralsInp
  >
  struct
domain
: proto::domain
  < generator
    < NumeralsInp
    > 
  >
{};
  template
  < class NumeralsInp
  , class Expr
  >
  struct
expr
: proto::extends
  < Expr
  , expr
    < NumeralsInp
    , Expr
    >
  , domain
    < NumeralsInp
    >
  >
, delta_expr
  < NumeralsInp
  , Expr
  >
{
        typedef
      proto::extends
      < Expr
      , expr
        < NumeralsInp
        , Expr
        >
      , domain
        < NumeralsInp
        >
      >
    base_type
    ;
    explicit expr(Expr const &expr = Expr())
      : base_type(expr)
    {}

    using base_type::operator=;
        
};

}//exit lookahead namespace
}//exit boost namespace
  boost::lookahead::ostrm_type&
operator<<
  ( boost::lookahead::ostrm_type& os
  , boost::lookahead::special::numerals n
  )
{
    os<<boost::lookahead::enum_names<boost::lookahead::special::numerals>()[n];
    return os;
}    
  boost::lookahead::ostrm_type&
operator<<
  ( boost::lookahead::ostrm_type& os
  , boost::lookahead::numerals_empty n
  )
{
    os<<boost::lookahead::enum_names<boost::lookahead::numerals_empty>()[n];
    return os;
}    
  boost::lookahead::ostrm_type&
operator<<
  ( boost::lookahead::ostrm_type& os
  , boost::lookahead::numerals_attr n
  )
{
    os<<boost::lookahead::enum_names<boost::lookahead::numerals_attr>()[n];
    return os;
}    
#endif
