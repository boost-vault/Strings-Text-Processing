//Purpose:
//  Prototype calculating context free grammar lookahead.
//ChangeLog:
//  2007-05-28.0551
//    cp'ed from cfg_lookahead.cpp to try using proto::extends to add
//    lookahead attributes to nodes in grammar expression tree.
//
#define USE_TRACE_SCOPE
#ifdef USE_TRACE_SCOPE
#include <boost/utility/trace_scope.hpp>
#else
#include <iostream>
#endif
#include <string>
#include <algorithm>
#include <bitset>
#include <boost/xpressive/proto/proto.hpp>
#include <boost/xpressive/proto/context.hpp>
#include <boost/xpressive/proto/fusion.hpp>
#include <boost/xpressive/proto/proto_typeof.hpp>
#include <boost/mpl/arg.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/mpl/at.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/fold.hpp>
#include <boost/mpl/range_all.hpp>
#include <boost/type_traits/is_const.hpp>
#include <boost/type_traits/remove_const.hpp>
#include <boost/type_traits/remove_reference.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/test/minimal.hpp>

#include "lookahead_expr.hpp"

  namespace
grm_arith_syms_lex
{
      enum
    numerals
    { ident //identifier
    , value //literal value
    , addop //add operator
    , mulop //multiply operator
    , lpar  //left parenthesis
    , rpar  //right parenthesis
    };
        static
      char const*
    names[]=
    { "ident"
    , "value"
    , "addop"
    , "mulop"
    , "lpar" 
    , "rpar" 
    };
        typedef
      boost::lookahead::ostrm_type
    ostrm_type
    ;
      ostrm_type&
    operator<<
      ( ostrm_type& a_os
      , numerals a_num
      )
    {
        return a_os<<names[a_num];
    }
      
}

using namespace boost;

    typedef
  proto::not_<proto::_>
match_none
;
BOOST_MPL_ASSERT((is_same<match_none,match_none::proto_base_expr>));
  template
  < class Enum
  , template<Enum>class Wrap
  >
  struct
or_enum_op
{
      template
      < class Head
      , class Tail
      >
      struct
    apply
    {
            typedef
          proto::or_
          < typename Wrap<Head::value>::type
          , typename Tail::proto_base_expr//type
          >
        type
        ;
    };
};

  enum
symbol_numerals
{ sym_spc
, sym_inp
, sym_out
};
    
  template
  < class NumeralsInp
  , class NumeralsOut
  >
  struct
lookahead_syms
{
        typedef
      NumeralsInp
    numerals_inp
    ;
        typedef
      NumeralsOut
    numerals_out
    ;
        typedef
      lookahead::special::numerals
    numerals_spc
    ;
      template
      < numerals_spc Num
      >
      struct
    s
    {
            typedef
          numerals_spc
        numerals_type
        ;
            typedef
            typename
          proto::terminal
          < mpl::integral_c<numerals_type,Num>
          >::type 
        base_type
        ;
            typedef
            typename
          lookahead::expr<numerals_inp,base_type>
        type
        ;
            static
          type
        _(void)
        {
            static type const x
            ;
            return x;
        }
    };
    
      template
      < numerals_inp Num
      >
      struct
    i //defines input pattern (terminal symbols in grammar)
    {
            typedef
          numerals_inp
        numerals_type
        ;
            typedef
            typename
          proto::terminal
          < mpl::integral_c<numerals_type,Num>
          >::type 
        base_type
        ;
            typedef
            typename
          lookahead::expr<numerals_inp,base_type>
        type
        ;
            static
          type
        _(void)
        {
            static type const x
            ;
            return x;
        }
    };
      
      template
      < numerals_out Num
      >
      struct
    o//defines output pattern (non-terminal symbols in grammar).
    {
            typedef
          numerals_out
        numerals_type
        ;
            typedef
            typename
          proto::terminal
          < mpl::integral_c<numerals_type,Num>
          >::type 
        base_type
        ;
            typedef
            typename
          lookahead::expr<numerals_inp,base_type>
        type
        ;
            static
          type
        _(void)
        {
            static type const x
            ;
            return x;
        }
    };
    
};    
  template
  < class NumeralsInp
  , class NumeralsOut
  >
  struct
grammar_patterns
: lookahead_syms
  < NumeralsInp
  , NumeralsOut
  >
{
        typedef
      NumeralsInp
    numerals_inp
    ;
        typedef
      NumeralsOut
    numerals_out
    ;
        typedef
      lookahead::special::numerals
    numerals_spc
    ;
        typedef
      lookahead_syms
      < numerals_inp
      , numerals_out
      >
    syms_type
    ;
        template
        < class Head
        , class Tail
        >
        struct
      or_enum_inp
      : or_enum_op
        < numerals_inp
        , syms_type::template i
        >::template
        apply
        < Head
        , Tail
        >
      {};    
        typedef
        typename
      mpl::fold
      < mpl::range_all<numerals_inp>
      , match_none
      , or_enum_inp
        < mpl::arg<2>
        , mpl::arg<1>
        >
      >::type
    grm_inps
    ;
        template
        < class Head
        , class Tail
        >
        struct
      or_enum_out
      : or_enum_op
        < numerals_out
        , syms_type::template o
        >::template
        apply
        < Head
        , Tail
        >
      {};    
        typedef
        typename
      mpl::fold
      < mpl::range_all<numerals_out>
      , match_none
      , or_enum_out
        < mpl::arg<2>
        , mpl::arg<1>
        >
      >::type
    grm_outs
    ;
        template
        < class Head
        , class Tail
        >
        struct
      or_enum_spc
      : or_enum_op
        < numerals_spc
        , syms_type::template s
        >::template
        apply
        < Head
        , Tail
        >
      {};    
        typedef
        typename
      mpl::fold
      < mpl::range_all<numerals_spc>
      , match_none
      , or_enum_spc
        < mpl::arg<2>
        , mpl::arg<1>
        >
      >::type
    grm_spcs
    ;
        typedef
      proto::or_
      < grm_outs
      , grm_inps
      , grm_spcs
      >
    grm_syms
    ;
      struct
    production_rhs
    /**@brief
     *  Right Hand Side of grammar production
     */
    ;
      struct
    grm_seq
    : proto::shift_right
      < production_rhs
      , production_rhs
      >
    {};
      struct
    grm_alt
    : proto::bitwise_or
      < production_rhs
      , production_rhs
      >
    {};
    
      struct 
    production_rhs
    : proto::or_
      < grm_seq
      , grm_alt
      , grm_syms
      >
    {};
    
      struct
    production_def
    : proto::assign
      < grm_outs
      , production_rhs
      >
    {};  
        
      struct
    production_list
    : proto::or_
      < production_def
      , proto::comma
        < production_list
        , production_def
        >
      >
    {};  
        
};
namespace lookahead_eval
{
namespace value_containers
{
  template
  < class ValueType
  , class Indices
  >
  struct
values_indexed
{
        typedef
      ValueType
    value_type
    ;
        static
      unsigned const
    our_size=mpl::size<mpl::range_all<Indices> >::value
    ;
        typedef
      value_type
    values_type
      [ our_size
      ]
    ;
    values_indexed
      ( void
      )
    {
    }
      value_type const&
    operator[]
      ( Indices index
      )
      const
    { 
        return my_values[index];
    }
      value_type&
    operator[]
      ( Indices index
      )
    { 
        return my_values[index];
    }
    
        static
      value_type const&
    default_value
      ( void
      )
    {
        static value_type a_default;
        return a_default;
    }
 protected:
      void
    init
      ( value_type const& a_value
      )
    {
        std::fill_n
        ( my_values
        , our_size
        , a_value
        );
    }
      void
    init
      ( void
      )
    {
        this->init(default_value());
    }
      values_type
    my_values
    ;       
};

  template
  < class NumeralsOut
  >
  struct
values_empty
: values_indexed
  < lookahead::numerals_empty
  , NumeralsOut
  >
{
        typedef
      values_indexed
      < lookahead::numerals_empty
      , NumeralsOut
      >
    super_type
    ;

    values_empty(void)
    {
        this->init(lookahead::empty_unknown);
    }
};

  template
  < class NumeralsSet
  , class NumeralsVec
  >
  struct
values_set_vec
: values_indexed
  < lookahead::numeral_set
    < NumeralsSet
    >
  , NumeralsVec
  >
{
};

}//exit containers namespace
  template
  < lookahead::numerals_attr AttrNum
  , class NumeralsInp
  , class NumeralsOut
  >
  struct
soln_vec
/**@brief
 *  Meta function returning type of vector of solutions 
 *  to container of equations "imnplied" by
 *  container of grammar productions.
 */
{
        typedef
      value_containers::values_set_vec
      < NumeralsInp
      , NumeralsOut
      >
    type
    ;
};
  template
  < class NumeralsInp
  , class NumeralsOut
  >
  struct
soln_vec
  < lookahead::attr_empty
  , NumeralsInp
  , NumeralsOut
  >
{
        typedef
      value_containers::values_empty
      < NumeralsOut
      >
    type
    ;
};
  template
  < lookahead::numerals_attr AttrNum
  , class NumeralsInp
  , class NumeralsOut
  >
  struct
soln_context
;
  template
  < class Context
  >
  struct
eval_assign_comma
{
        typedef
      Context
    ctx_type
    ;
        typedef
        typename
      Context::numerals_inp
    numerals_inp
    ;
        typedef
        typename
      Context::numerals_out
    numerals_out
    ;
      template
      < class Arg0
      , class Arg1
      >
      struct
    assign
    {
            typedef
          void
        result_type
        ;
            typedef
          lookahead::expr
          < numerals_inp
          , proto::expr
            < proto::tag::assign
            , proto::args2
              < Arg0
              , Arg1
              >
            , 2l
            >
          >
        expr_type
        ;
          result_type
        operator()(expr_type& a_expr, ctx_type& a_ctx)const
        {
            Arg1& a_1_expr(proto::arg_c<1>(a_expr));
            proto::eval(a_1_expr,a_ctx);
        }
    };
      template
      < class Arg0
      , class Arg1
      >
      struct
    comma
    {
            typedef
          void
        result_type
        ;
            typedef
          lookahead::expr
          < numerals_inp
          , proto::expr
            < proto::tag::comma
            , proto::args2
              < Arg0
              , Arg1
              >
            , 2l
            >
          >
        expr_type
        ;
          result_type
        operator()(expr_type& a_expr, ctx_type& a_ctx)const
        {
            Arg0& a_0_expr(proto::arg_c<0>(a_expr));
            proto::eval(a_0_expr,a_ctx);
            
            Arg1& a_1_expr(proto::arg_c<1>(a_expr));
            proto::eval(a_1_expr,a_ctx);

        }
    };

};//exit eval_assign_comma template<Context>

namespace eval_uncurried
/**@brief
 *  Provide a namespace for defining the eval templates for
 *  calculating lookahead attributes.  The reason the eval
 *  templates are defined here instead of in the respective
 *  context classes is because the context classes are
 *  templates themselves and the eval templates cannot
 *  be specialized and expected to work because, I guess,
 *  the compiler cannot deduce the template arguments
 *  because they're in a non-deduced context.  WARNING:
 *  this is just a guess, I'm not at all familiar
 *  enough with section "14.8.2.4 Deducing template arguments
 *  from a type" to have much confidence in this guess.
 *
 *  A simplified example of the problem which these
 *  templates are supposed to solve is:
 *
template<unsigned Id> struct type_id
{
    unsigned const my_id;
    type_id(void):my_id(Id){}
};
template<class X,class Y>struct C
;
template<class T> struct A1 
{
    template<class U> struct B
    ;
    template<class V>struct B<C<T,V> >
    {
        typedef type_id<1> A1_B_C_T_V;
    };
};
template<class T,class V>struct B2
;
template<class T,class V>struct B2<T,C<T,V> >
{
    typedef type_id<2> A2_B_C_T_V;
};
template<class T> struct A2
{
    template<class U> struct B
    ;
    template<class V> struct B
    : B2<T,V>
    {
    };
};

int main(void)
{
        typedef
      A1<int>::B
      < C
        < int
        , float
        >
      >::A1_B_C_T_V  
    type1_type;
        typedef
      A2<int>::B
      < C
        < int
        , float
        >
      >::A2_B_C_T_V  
    type2_type;
    return 0;
}
    
 *  gives the following error messages:

demo.cpp: In function 'int main()':
demo.cpp:59: error: 'A1_B_C_T_V' in class 'A1<int>::B<C<int, float> >' does not name a type
  
 *
 *  The A2::B uses the external B2 as super to avoid the above error.
 *  The B2 template in this example plays the part of the eval templates in
 *  the following uncurried_XXX namespaces (where XXX is empty, first, follow).
 */
{
namespace uncurried_empty
{
    static
  lookahead::numerals_attr const
attr_num
= lookahead::attr_empty
;  
    typedef
  lookahead::numerals_empty
value_type
;   
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Expr
  >
  struct
eval
;
  template
  < class NumeralsInp
  , class NumeralsOut
  , class NumeralsAny
  , NumeralsAny NumAny
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::terminal
      , proto::args0<mpl::integral_c<NumeralsAny,NumAny> >
      , 0l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::terminal
        , proto::args0<mpl::integral_c<NumeralsAny,NumAny> >
        , 0l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
    }
        
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , NumeralsOut NumAny
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::terminal
      , proto::args0<mpl::integral_c<NumeralsOut,NumAny> >
      , 0l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp
      , proto::expr 
        < proto::tag::terminal
        , proto::args0<mpl::integral_c<NumeralsOut,NumAny> >
        , 0l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
        value_type const result_this=a_ctx[NumAny];
        a_expr.put_empty(result_this);
    }
        
};
  template
  < class Tag
  >
  struct
binary_empty
;
  template
  <
  >
  struct
binary_empty
  < proto::tag::shift_right
  >
{
        static
      value_type
    op
      ( value_type arg0
      , value_type arg1
      )
    {
        using namespace lookahead;
            static
          value_type const
        table
          [3][3]
        = //empty_unknown, empty_not    , empty_yes    
        { { empty_unknown, empty_not    , empty_unknown } //empty_unknown
        , { empty_not    , empty_not    , empty_not     } //empty_not
        , { empty_unknown, empty_not    , empty_yes     } //empty_yes
        };
        return table[arg0][arg1];
    }
};
  template
  <
  >
  struct
binary_empty
  < proto::tag::bitwise_or
  >
{
        static
      value_type
    op
      ( value_type arg0
      , value_type arg1
      )
    {
        using namespace lookahead;
            static
          value_type const
        table
          [3][3]
        = //empty_unknown, empty_not    , empty_yes    
        { { empty_unknown, empty_unknown, empty_yes     } //empty_unknown
        , { empty_unknown, empty_not    , empty_yes     } //empty_not
        , { empty_yes    , empty_yes    , empty_yes     } //empty_yes
        };
        return table[arg0][arg1];
    }
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Tag
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < Tag
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < Tag
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
        Arg0& a_0_expr(proto::arg_c<0>(a_expr));
        proto::eval(a_0_expr,a_ctx);
        value_type const result_0=a_0_expr.get_empty();
        
        Arg1& a_1_expr(proto::arg_c<1>(a_expr));
        proto::eval(a_1_expr,a_ctx);
        value_type const result_1=a_1_expr.get_empty();
        
        value_type const result_this=binary_empty<Tag>::op(result_0,result_1);
        a_expr.put_empty(result_this);
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr
    < NumeralsInp
    , proto::expr
      < proto::tag::assign
      , proto::args2
        < Arg0
        , Arg1
        >
      , 2l
      >//proto::expr<assign...>
    >//lookahead::expr
  >
: eval_assign_comma
  < soln_context
    < attr_num
    , NumeralsInp
    , NumeralsOut
    >
  >::template assign
  < Arg0
  , Arg1
  >
{
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::comma
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
: eval_assign_comma
  < soln_context
    < attr_num
    , NumeralsInp
    , NumeralsOut
    >
  >::template comma
  < Arg0
  , Arg1
  >
{
};

}//exit uncurried_empty namespace

namespace uncurried_first
{
  lookahead::numerals_attr const 
attr_num
= lookahead::attr_first
;
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Expr
  >
  struct
eval
;
  template
  < class NumeralsInp
  , class NumeralsOut
  , class NumeralsAny
  , NumeralsAny NumAny
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::terminal
      , proto::args0<mpl::integral_c<NumeralsAny,NumAny> >
      , 0l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::terminal
        , proto::args0<mpl::integral_c<NumeralsAny,NumAny> >
        , 0l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
    }
        
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , NumeralsOut NumAny
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::terminal
      , proto::args0<mpl::integral_c<NumeralsOut,NumAny> >
      , 0l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp
      , proto::expr 
        < proto::tag::terminal
        , proto::args0<mpl::integral_c<NumeralsOut,NumAny> >
        , 0l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
        typedef typename ctx_type::values_type::value_type value_type;
        value_type const& a_result=a_ctx[NumAny];
        a_expr.put_first(a_result);
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Tag
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < Tag
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < Tag
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
        Arg0&  a_0_expr(proto::arg_c<0>(a_expr));
        proto::eval(a_0_expr,a_ctx);
        
        Arg1&  a_1_expr(proto::arg_c<1>(a_expr));
        proto::eval(a_1_expr,a_ctx);
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::shift_right
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::shift_right
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
      #ifdef USE_TRACE_SCOPE
        utility::trace_scope ts("first::shift_right");
      #endif
        typedef typename ctx_type::values_type::value_type value_type;
        Arg0&  a_0_expr(proto::arg_c<0>(a_expr));
        proto::eval(a_0_expr,a_ctx);
        value_type const result_0=a_0_expr.get_first();
        bool const empty_0=a_0_expr.get_empty() == lookahead::empty_yes;
        
        Arg1&  a_1_expr(proto::arg_c<1>(a_expr));
        proto::eval(a_1_expr,a_ctx);
        value_type const result_1=a_1_expr.get_first();
        
        value_type const result_this
          = result_0 
          | ( empty_0
            ? result_1
            : value_type()
            )
          ;
      #ifdef USE_TRACE_SCOPE
        mout()
          <<"shift_right:result_0="<<result_0
          <<":result_1="<<result_1
          <<":empty_0="<<empty_0
          <<":result_this="<<result_this
          <<":id_0="<<a_0_expr.id_get()
          <<"\n";
      #endif
        a_expr.put_first(result_this);
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::bitwise_or
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
        typename
      ctx_type::result_type
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::bitwise_or
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
      #ifdef USE_TRACE_SCOPE
        utility::trace_scope ts("first::bitwise_or");
      #endif
        typedef typename ctx_type::values_type::value_type value_type;
        Arg0&  a_0_expr(proto::arg_c<0>(a_expr));
        proto::eval(a_0_expr,a_ctx);
        value_type const result_0=a_0_expr.get_first();
        
        Arg1&  a_1_expr(proto::arg_c<1>(a_expr));
        proto::eval(a_1_expr,a_ctx);
        value_type const result_1=a_1_expr.get_first();
        
        value_type const result_this
          = result_0 
          | result_1
          ;
      #ifdef USE_TRACE_SCOPE
        mout()
          <<"bitwise_or:result_0="<<result_0
          <<":result_1="<<result_1
          <<":result_this="<<result_this
          <<"\n";
      #endif
        a_expr.put_first(result_this);
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr
    < NumeralsInp
    , proto::expr
      < proto::tag::assign
      , proto::args2
        < Arg0
        , Arg1
        >
      , 2l
      >//proto::expr<assign...>
    >//lookahead::expr
  >
: eval_assign_comma
  < soln_context
    < attr_num
    , NumeralsInp
    , NumeralsOut
    >
  >::template assign
  < Arg0
  , Arg1
  >
{
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::comma
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
: eval_assign_comma
  < soln_context
    < attr_num
    , NumeralsInp
    , NumeralsOut
    >
  >::template comma
  < Arg0
  , Arg1
  >
{
};

}//exit uncurried_first namespace

namespace uncurried_follow
{
    static
  lookahead::numerals_attr const
attr_num  
= lookahead::attr_follow
;
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Expr
  >
  struct
eval
;
  template
  < class NumeralsInp
  , class NumeralsOut
  , class NumeralsAny
  , NumeralsAny NumAny
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::terminal
      , proto::args0<mpl::integral_c<NumeralsAny,NumAny> >
      , 0l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
      void
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::terminal
        , proto::args0<mpl::integral_c<NumeralsAny,NumAny> >
        , 0l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
    }
        
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , NumeralsOut NumAny
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::terminal
      , proto::args0<mpl::integral_c<NumeralsOut,NumAny> >
      , 0l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
      void
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp
      , proto::expr 
        < proto::tag::terminal
        , proto::args0<mpl::integral_c<NumeralsOut,NumAny> >
        , 0l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
            typedef
          lookahead::numeral_set<NumeralsInp>
        follow_type
        ;
        follow_type const a_expr_follow=a_expr.get_follow();
        a_ctx[NumAny]|=a_expr_follow;
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Tag
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < Tag
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
      void
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < Tag
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
        Arg1&  a_1_expr(proto::arg_c<1>(a_expr));
        proto::eval(a_1_expr,a_ctx);
        Arg0&  a_0_expr(proto::arg_c<0>(a_expr));
        proto::eval(a_0_expr,a_ctx);
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::shift_right
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
      void
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::shift_right
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
            typedef
          lookahead::numeral_set<NumeralsInp>
        follow_type
        ;
        follow_type const a_expr_follow=a_expr.get_follow();
      #ifdef USE_TRACE_SCOPE
        utility::trace_scope ts("follow::shift_right");
        mout()
          <<"bitwise_or:a_expr_follow="<<a_expr_follow
          <<"\n";
      #endif
        Arg1&  a_1_expr(proto::arg_c<1>(a_expr));
        a_1_expr.put_follow(a_expr_follow);
        proto::eval(a_1_expr,a_ctx);
        
        follow_type const a_1_expr_follow=a_1_expr.get_dirsymb();
        Arg0&  a_0_expr(proto::arg_c<0>(a_expr));
        a_0_expr.put_follow(a_1_expr_follow);
        proto::eval(a_0_expr,a_ctx);
        
    }
        
};
  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::bitwise_or
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
{
        typedef
      soln_context
      < attr_num
      , NumeralsInp
      , NumeralsOut
      >
    ctx_type
    ;  
        typedef
      void
    result_type
    ;
        typedef
      lookahead::expr 
      < NumeralsInp 
      , proto::expr 
        < proto::tag::bitwise_or
        , proto::args2<Arg0,Arg1>
        , 2l
        >  
      >
    expr_type
    ;
      result_type
    operator()(expr_type& a_expr, ctx_type& a_ctx)const
    {
            typedef
          lookahead::numeral_set<NumeralsInp>
        follow_type
        ;
        follow_type const a_expr_follow=a_expr.get_follow();
      #ifdef USE_TRACE_SCOPE
        utility::trace_scope ts("follow::bitwise_or");
        mout()
          <<"bitwise_or:a_expr_follow="<<a_expr_follow
          <<"\n";
      #endif
        Arg1&  a_1_expr(proto::arg_c<1>(a_expr));
        a_1_expr.put_follow(a_expr_follow);
        proto::eval(a_1_expr,a_ctx);
        
        Arg0&  a_0_expr(proto::arg_c<0>(a_expr));
        a_0_expr.put_follow(a_expr_follow);
        proto::eval(a_0_expr,a_ctx);
        
    }
        
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr
    < NumeralsInp
    , proto::expr
      < proto::tag::assign
      , proto::args2
        < Arg0
        , Arg1
        >
      , 2l
      >//proto::expr<assign...>
    >//lookahead::expr
  >
: eval_assign_comma
  < soln_context
    < attr_num
    , NumeralsInp
    , NumeralsOut
    >
  >::template assign
  < Arg0
  , Arg1
  >
{
};

  template
  < class NumeralsInp
  , class NumeralsOut
  , class Arg0
  , class Arg1
  >
  struct
eval
  < NumeralsInp
  , NumeralsOut
  , lookahead::expr 
    < NumeralsInp
    , proto::expr 
      < proto::tag::comma
      , proto::args2<Arg0,Arg1>
      , 2l
      >
    >  
  >
: eval_assign_comma
  < soln_context
    < attr_num
    , NumeralsInp
    , NumeralsOut
    >
  >::template comma
  < Arg0
  , Arg1
  >
{
};

}//exit uncurried_follow namespace
}//exit eval_uncurried

  template
  < lookahead::numerals_attr AttrNum
  >
  struct
uncurried_attr
;
  template
  <
  >
  struct
uncurried_attr
  < lookahead::attr_empty
  >
{
      template
      < class Inp
      , class Out
      , class Expr
      >
      struct
    eval
    : eval_uncurried::uncurried_empty::eval
      < Inp
      , Out
      , Expr
      >
    {
    };
};

  template
  <
  >
  struct
uncurried_attr
  < lookahead::attr_first
  >
{
      template
      < class Inp
      , class Out
      , class Expr
      >
      struct
    eval
    : eval_uncurried::uncurried_first::eval
      < Inp
      , Out
      , Expr
      >
    {
    };
};

  template
  <
  >
  struct
uncurried_attr
  < lookahead::attr_follow
  >
{
      template
      < class Inp
      , class Out
      , class Expr
      >
      struct
    eval
    : eval_uncurried::uncurried_follow::eval
      < Inp
      , Out
      , Expr
      >
    {
    };
};

namespace flow_assign
/**@brief
 *  Provide template flow_update which, based on template
 *  argument of type, lookahead::numerals_attr,
 *  copies arguments  right to left or left to right.
 */
{
//private:
      enum
    numerals_flow
    { flow_left_to_right
    , flow_right_to_left
    };
    
      template
      < numerals_flow FlowNum
      , class Left
      , class Right
      >
      struct
    lhs_rhs
    {
        lhs_rhs(Left& a_left, Right const& a_right)
        : my_left(a_left)
        , my_right(a_right)
        {}
          Left&
        my_left
        ;
          Right const&
        my_right
        ;
    };
      template
      < class Left
      , class Right
      >
      struct
    lhs_rhs
      < flow_left_to_right
      , Left
      , Right
      >
    {
        lhs_rhs(Left const& a_left, Right& a_right)
        : my_left(a_right)
        , my_right(a_left)
        {}
          Right&
        my_left
        ;
          Left const&
        my_right
        ;
    };
    
      template
      < lookahead::numerals_attr AttrNum
      >
      struct
    attr_flow
    /**@brief
     *  Maps AttrNum to numerals_flow
     */
    {
            static
          numerals_flow const
        flow_num
        = flow_right_to_left
        ;
    };
      template
      <
      >
      struct
    attr_flow
      < lookahead::attr_follow
      >
    {
            static
          numerals_flow const
        flow_num
        = flow_left_to_right
        ;
    };
//public:    
      template
      < lookahead::numerals_attr AttrNum
      >
      struct
    flow_update
    {
          template
          < class Left
          , class Right
          >
            static
          void
        copy
          ( Left& a_left
          , Right& a_right
          )
        {
            numerals_flow const a_flow=attr_flow<AttrNum>::flow_num;
            lhs_rhs<a_flow,Left,Right> a_lhs_rhs(a_left,a_right);
            a_lhs_rhs.my_left=a_lhs_rhs.my_right;
        }
    };   
    
}//exit flow_assign namespace

  template
  < lookahead::numerals_attr AttrNum
  , class NumeralsInp
  , class NumeralsOut
  >
  struct
soln_context
: soln_vec
  < AttrNum
  , NumeralsInp
  , NumeralsOut
  >::type
{
        typedef
      NumeralsInp
    numerals_inp
    ;
        typedef
      NumeralsOut
    numerals_out
    ;
        static
      lookahead::numerals_attr const
    attr_num
    = AttrNum
    ;
        typedef
        typename
      soln_vec
      < AttrNum
      , NumeralsInp
      , NumeralsOut
      >::type
    values_type
    ;
        typedef
      void
    result_type
    ;
        using
      values_type::
    our_size
    ;
        explicit    
    soln_context
      ( void
      )
    {
    }
    
 private:    
      template
      < typename EquationList
      >
      struct
    ctx_solved
    /**@brief
     *  Check whether each equation in EquationList is
     *  solved (lhs == rhs) and after check, do update
     *  of value (either lhs or rhs) if needed.
     */
    : proto::callable_context
      < ctx_solved
        < EquationList
        >
      >
    {
            typedef
          bool
        result_type
        ;
            explicit
        ctx_solved
          ( values_type& a_values
          )
          : my_lhs(a_values)
        {}
          template
          < typename Left
          , typename Right 
          >
          result_type
        operator()
          ( proto::tag::assign
          , Left & left
          , Right& right
          )
        {
            typedef typename values_type::value_type value_type;
            numerals_out const index_left=Left::base_type::proto_base_expr::proto_arg0::value;
            value_type& value_left  = my_lhs[index_left];
            value_type& value_right = right.template mut_attr<attr_num>();
            result_type const result_this=value_left == value_right;
            mout()
              <<":flow_update:"<<index_left <<"\n"
              <<"  :value_left ="<<value_left <<"\n"
              <<"  :value_right="<<value_right<<"\n"
              ;
            if(!result_this)
            {
                flow_assign::flow_update<attr_num>::copy
                  ( value_left
                  , value_right
                  );
            }
            return result_this;
        }
          template
          < typename Left
          , typename Right 
          >
          result_type
        operator()
          ( proto::tag::comma
          , Left & left
          , Right& right
          )
        {
            result_type const result_left =proto::eval(left , *this);
            result_type const result_right=proto::eval(right, *this);
            return result_left && result_right;
        }
     private:
          values_type&
        my_lhs
        /**@brief
         *  values on left hand side of EquationList.
         */
        ;
    };
 public:
      template
      < typename ProdList
      >
      bool
    solve
      ( ProdList& a_productions
      , unsigned iter=our_size+1
      )
    {
        std::string attr_name(lookahead::enum_names<lookahead::numerals_attr>()[attr_num]);
        utility::trace_scope ts("solve:"+attr_name);
        ctx_solved<ProdList> is_solved(*this);
        bool solved=false;
        do
        {
            mout()<<":iter="<<iter<<"\n";
            ++mout();
            proto::eval(a_productions,*this);
            solved=proto::eval(a_productions,is_solved);
            --mout();
        }
        while
        ( --iter > 0
        && !solved
        );
        return solved;
    }
      template
      < typename Expr
      >
      struct 
    eval
    : uncurried_attr<attr_num>::template eval<numerals_inp, numerals_out, Expr>
    {
    };
};

}//exit lookahead_eval namespace

  template
  < class NumeralsInp
  , class NumeralsOut
  >
  struct
cfg_lookahead
/**@brief
 *  Calculate the First and Follow sets for a list of
 *  grammar productions.
 *
 ** References:
 *  
 *  Thomas W. Christopher
 *  "Chapter 3: Analysis of Grammars"
 *  unpublished
 *  copyright: 1994
 *     On 2004-07-04 it was available at:
 *       http://facweb.cs.depaul.edu/tchristopher/grmanl.pdf
 */
{
        typedef
        typename
      grammar_patterns
      < NumeralsInp
      , NumeralsOut
      >::production_list
    production_list
    ;
        typedef
      lookahead_eval::soln_context
      < lookahead::attr_empty
      , NumeralsInp
      , NumeralsOut
      > 
    ctx_empty_type
    ;
      ctx_empty_type
    my_ctx_empty
    ;
        typedef
      lookahead_eval::soln_context
      < lookahead::attr_first
      , NumeralsInp
      , NumeralsOut
      > 
    ctx_first_type
    ;
      ctx_first_type
    my_ctx_first
    ;
        typedef
      lookahead_eval::soln_context
      < lookahead::attr_follow
      , NumeralsInp
      , NumeralsOut
      >
    ctx_follow_type
    ;
      ctx_follow_type
    my_ctx_follow
    ;
        explicit
    cfg_lookahead
      ( void
      )
    {}
      template
      < typename ProdList
      >
        typename
      enable_if //This just assures a_productions has correct type.
      < proto::matches
        < ProdList
        , production_list
        >
      , bool
      >::type
    solve
      ( ProdList const& a_productions //list of grammar productions.
      )
    {
        bool solved=true;
        if     (!my_ctx_empty  .solve(a_productions))
        {
            mout()<<"failed empty solution\n";
            solved=false;
        }
        else if(!my_ctx_first  .solve(a_productions))
        {
            mout()<<"failed first solution\n";
            solved=false;
        }
        else if(!my_ctx_follow .solve(a_productions))
        {
            mout()<<"failed follow solution\n";
            solved=false;
        }
        return solved;
    }        
};

  namespace
grm_arith_syms_syn
{
//#define EXPR_TAIL    
      enum
    numerals
    { fact
    , term
  #ifdef EXPR_TAIL
    , expr_tail
  #endif
    , expr
    };
        static
      char const*
    names[]=
    { "fact"
    , "term"
  #ifdef EXPR_TAIL
    , "expr_tail"
  #endif
    , "expr"
    };
        typedef
      boost::lookahead::ostrm_type
    ostrm_type
    ;
      ostrm_type&
    operator<<
      ( ostrm_type& a_os
      , numerals a_num
      )
    {
        return a_os<<names[a_num];
    }
}
namespace boost
{
namespace lookahead
{
  template
  <
  >
  char const**
enum_names
  < grm_arith_syms_lex::numerals
  >
  ( void
  )
{
    return grm_arith_syms_lex::names;
}
  template
  <
  >
  char const**
enum_names
  < grm_arith_syms_syn::numerals
  >
  ( void
  )
{
    return grm_arith_syms_syn::names;
}
}//exit lookahead namespace
}//exit boost namespace

namespace boost { namespace mpl { namespace aux {

template<> struct integral_rank<grm_arith_syms_lex::numerals> : integral_rank<unsigned> 
{
    typedef unsigned diff_type;
    typedef grm_arith_syms_lex::numerals limits_type;
    static limits_type const min_limit=grm_arith_syms_lex::ident;
    static limits_type const max_limit=grm_arith_syms_lex::rpar;
};

template<> struct integral_rank<grm_arith_syms_syn::numerals> : integral_rank<unsigned> 
{
    typedef unsigned diff_type;
    typedef grm_arith_syms_syn::numerals limits_type;
    static limits_type const min_limit=grm_arith_syms_syn::fact;
    static limits_type const max_limit=grm_arith_syms_syn::expr;
};

}}}//exit boost::mpl::aux namespace

  template
  < lookahead::numerals_attr AttrNum
  , class NumeralsInp
  , class NumeralsOut
  >
  struct
soln_check
{
        typedef
        typename
      lookahead_eval::soln_vec
      < AttrNum
      , NumeralsInp
      , NumeralsOut
      >::type
    values_vec
    ;
        static
      bool
    ok
      ( values_vec const& vec_actual
      , values_vec const& vec_expected
      )
    /**@brief
     *  Checks that vec_actual == vec_expected and
     *  prints diagnostics if not.
     */
    {
        bool result_vec=true;
        for(unsigned i=0; i<values_vec::our_size; ++i)
        {
            NumeralsOut out=NumeralsOut(i);
            typedef typename values_vec::value_type value_type;
            value_type const& val_actual  =vec_actual  [out];
            value_type const& val_expected=vec_expected[out];
            bool const result_val=val_actual == val_expected;
            result_vec = result_vec && result_val;
            if( !result_val )
            {
                mout()
                  <<"failed:"<<out<<"\n"
                  <<"  expected="<<val_expected<<"\n"
                  <<"  actual  ="<<val_actual<<"\n"
                  ; 
            }
        }
        return result_vec;
    }
};    

  namespace
grm_arith_def
{
        typedef
      grm_arith_syms_lex::numerals
    inp
    ;
        typedef
      grm_arith_syms_syn::numerals
    out
    ;
        typedef
      grammar_patterns
      < inp
      , out
      >
    patterns_type
    ;
        using
      namespace
    lookahead::special
    ;
        using
      namespace
    grm_arith_syms_lex
    ;
        using
      namespace
    grm_arith_syms_syn
    ;
      struct
    def
    : patterns_type
    {
            using 
          patterns_type::
        i
        ;
            using 
          patterns_type::
        o
        ;
            using
          patterns_type::
        s
        ;
            typedef
          cfg_lookahead
          < inp
          , out
          >
        lookahead_type
        ;
        def(void)
        {
            BOOST_PROTO_AUTO(s_epsilon,s<epsilon>::_());
          #ifdef EXPR_TAIL  
            BOOST_PROTO_AUTO(o_expr_tail,o<expr_tail>::_());
          #endif
            BOOST_PROTO_AUTO(o_expr,o<expr>::_());
            BOOST_PROTO_AUTO(o_term,o<term>::_());
            BOOST_PROTO_AUTO(o_fact,o<fact>::_());
            
            BOOST_PROTO_AUTO(i_ident,i<ident>::_());
            BOOST_PROTO_AUTO(i_value,i<value>::_());
            BOOST_PROTO_AUTO(i_addop,i<addop>::_());
            BOOST_PROTO_AUTO(i_mulop,i<mulop>::_());
            BOOST_PROTO_AUTO(i_lpar ,i<lpar >::_());
            BOOST_PROTO_AUTO(i_rpar ,i<rpar >::_());

            mout()<<"creating my_grm:"<<utility::object_tracked::members_size()<<"\n";
            ++mout();
            BOOST_PROTO_AUTO
            ( my_grm
          #ifdef EXPR_TAIL
            , ( o_expr
                = o_term  >> o_expr_tail
              , o_expr_tail
                = i_addop >> o_term  >> o_expr_tail | s_epsilon
          #else
            , ( o_expr
                = o_term  >> i_addop >> o_expr      | o_term
          #endif
              , o_term
                = o_fact  >> i_mulop >> o_term      | o_fact
              , o_fact
                = i_lpar  >> o_expr  >> i_rpar      | i_ident | i_value
              )
            );

            --mout();
            mout()<<"created my_grm:"<<utility::object_tracked::members_size()<<"\n";
            lookahead_type my_lookahead;
            //my_lookahead.solve(my_grm);
            bool passed_empty=true;
            {//enter empty tests
                bool& passed_attr=passed_empty;
                typedef lookahead_type::ctx_empty_type ctx_type;
                ctx_type& my_ctx=my_lookahead.my_ctx_empty;
                std::string name_attr(lookahead::enum_names<lookahead::numerals_attr>()[ctx_type::attr_num]);
                utility::trace_scope ts(name_attr+" tests");
                typedef ctx_type::values_type values_type;
                typedef values_type::value_type value_type;
                bool passed_expr=true;
                {//check initial spc eval
                        typedef 
                      s<epsilon>::type
                    addop_var_type;
                    addop_var_type addop_var_value;
                    proto::eval
                      ( addop_var_value
                      , my_ctx
                      );
                    value_type const actual=addop_var_value.get_empty();
                    BOOST_CHECK(actual == lookahead::empty_yes);
                    passed_expr = passed_expr && (actual == lookahead::empty_yes);
                }
                {//check initial inp eval
                        typedef 
                      i<addop>::type
                    addop_var_type;
                    addop_var_type addop_var_value;
                    proto::eval
                      ( addop_var_value
                      , my_ctx
                      );
                    value_type const actual=addop_var_value.get_empty();
                    BOOST_CHECK(actual == lookahead::empty_not);
                    passed_expr = passed_expr && (actual == lookahead::empty_not);
                }
                {//check initial out eval
                        typedef 
                      o<fact>::type
                    addop_var_type;
                    addop_var_type addop_var_value;
                    proto::eval
                      ( addop_var_value
                      , my_ctx
                      );
                    value_type const actual=addop_var_value.get_empty();                      
                    BOOST_CHECK(actual == lookahead::empty_unknown);
                    passed_expr = passed_expr && (actual == lookahead::empty_unknown);
                }
                {//binary >>
                  {// s >> s:
                      BOOST_PROTO_AUTO(a_expr,(s_epsilon >> s_epsilon));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_yes);
                      passed_expr = passed_expr && (actual == lookahead::empty_yes);
                  }
                  {// s >> i:
                      BOOST_PROTO_AUTO(a_expr,(s_epsilon >> i_addop));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_not);
                      passed_expr = passed_expr && (actual == lookahead::empty_not);
                  }
                  {// i >> i:
                      BOOST_PROTO_AUTO(a_expr,(i_addop >> i_addop));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_not);
                      passed_expr = passed_expr && (actual == lookahead::empty_not);
                  }
                  {// i >> o
                      BOOST_PROTO_AUTO(a_expr,(i_addop >> o_term));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_not);
                      passed_expr = passed_expr && (actual == lookahead::empty_not);
                  }
                  {// o >> i
                      BOOST_PROTO_AUTO(a_expr,(o_term  >> i_addop));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_not);
                      passed_expr = passed_expr && (actual == lookahead::empty_not);
                  }
                  {// o >> o
                      BOOST_PROTO_AUTO(a_expr,(o_term  >> o_term));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_unknown);
                      passed_expr = passed_expr && (actual == lookahead::empty_unknown);
                  }
                  
                }//binary >>
                {//binary |
                  {// s | s:
                      BOOST_PROTO_AUTO(a_expr,(s_epsilon | s_epsilon));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_yes);
                      passed_expr = passed_expr && (actual == lookahead::empty_yes);
                  }
                  {// s | i:
                      BOOST_PROTO_AUTO(a_expr,(s_epsilon | i_addop));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_yes);
                      passed_expr = passed_expr && (actual == lookahead::empty_yes);
                  }
                  {// i | i:
                      BOOST_PROTO_AUTO(a_expr,(i_addop | i_addop));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_not);
                      passed_expr = passed_expr && (actual == lookahead::empty_not);
                  }
                  {// i | o
                      BOOST_PROTO_AUTO(a_expr,(i_addop | o_term));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_unknown);
                      passed_expr = passed_expr && (actual == lookahead::empty_unknown);
                  }
                  {// o | i
                      BOOST_PROTO_AUTO(a_expr,(o_term  | i_addop));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_unknown);
                      passed_expr = passed_expr && (actual == lookahead::empty_unknown);
                  }
                  {// o | o
                      BOOST_PROTO_AUTO(a_expr,(o_term  | o_term));
                      proto::eval
                      ( a_expr
                      , my_ctx
                      );
                      value_type const actual=a_expr.get_empty();                      
                      BOOST_CHECK(actual == lookahead::empty_unknown);
                      passed_expr = passed_expr && (actual == lookahead::empty_unknown);
                  }
                  
                }//binary |
                {// i >> i >> i
                    BOOST_PROTO_AUTO(a_expr,(i_addop  >> i_addop >> i_addop));
                    proto::eval
                    ( a_expr
                    , my_ctx
                    );
                    value_type const actual=a_expr.get_empty();                      
                    BOOST_CHECK(actual == lookahead::empty_not);
                    passed_expr = passed_expr && (actual == lookahead::empty_not);
                }
                {//combination of >> and |
                    BOOST_PROTO_AUTO(a_expr,(i_lpar  >> o_expr  >> i_rpar      | s_epsilon ));
                    proto::eval
                    ( a_expr
                    , my_ctx
                    );
                    value_type const actual=a_expr.get_empty();                      
                    BOOST_CHECK(actual == lookahead::empty_yes);
                    passed_expr = passed_expr && (actual == lookahead::empty_yes);
                }
                passed_attr = passed_attr && passed_expr;
                {// solve
                    std::string passed_name=name_attr+"::solve_tests";
                    utility::trace_scope ts(passed_name);
                    bool const passed_ctx=my_ctx.solve
                    ( my_grm
                    );
                    BOOST_CHECK(passed_ctx);
                    passed_attr=passed_attr && passed_ctx;
                    {
                        values_type expected;
                        expected[fact]
                          =lookahead::empty_not
                          ;
                        expected[term]
                          = expected[fact]
                          ;
                        expected[expr]
                          = expected[fact]
                          ;
                        mout()<<passed_name<<"="<<passed_ctx<<"\n";
                        ++mout();
                        typedef soln_check<ctx_type::attr_num,numerals_inp,numerals_out> soln_check_type;
                        passed_attr=passed_attr && soln_check_type::ok(my_ctx,expected);
                        --mout();
                    }
                }
                BOOST_CHECK(passed_attr);
            }//exit empty tests
            bool passed_first=true;
            if(passed_empty)
            {//enter first tests
                bool& passed_attr=passed_first;
                typedef lookahead_type::ctx_first_type ctx_type;
                ctx_type& my_ctx=my_lookahead.my_ctx_first;
                std::string name_attr(lookahead::enum_names<lookahead::numerals_attr>()[ctx_type::attr_num]);
                utility::trace_scope ts(name_attr+" tests");
                typedef ctx_type::values_type values_type;
                typedef values_type::value_type value_type;
                {//check initial inp eval
                        typedef 
                      i<addop>::type
                    addop_var_type;
                    addop_var_type a_expr;
                    value_type expected;
                    expected
                      .set(addop)
                      ;
                    {
                        value_type const actual=a_expr.get_first();
                        bool const solved=actual == expected;
                        BOOST_CHECK(solved);
                        if(!solved)
                        {
                            std::cout<<"init.i<addop>="<<actual<<"\n";
                        }
                    }
                    {
                        proto::eval
                          ( a_expr
                          , my_ctx
                          );
                        value_type const actual=a_expr.get_first();
                        bool const solved=actual == expected;
                        BOOST_CHECK(solved);
                        passed_attr = passed_attr && solved;
                        if(!solved)
                        {
                            std::cout<<"eval.i<addop>="<<actual<<"\n";
                        }
                    }
                }
                {// solve
                    std::string passed_name=name_attr+"::solve_tests";
                    utility::trace_scope ts(passed_name);
                    bool const passed_ctx=my_ctx.solve
                    ( my_grm
                    );
                    BOOST_CHECK(passed_ctx);
                    passed_attr=passed_attr && passed_ctx;
                    {
                        values_type expected;
                        expected[fact]
                          .set(lpar)
                          .set(ident)
                          .set(value)
                          ;
                        expected[term]
                          = expected[fact]
                          ;
                        expected[expr]
                          = expected[fact]
                          ;
                        mout()<<passed_name<<"="<<passed_ctx<<"\n";
                        ++mout();
                        typedef soln_check<ctx_type::attr_num,numerals_inp,numerals_out> soln_check_type;
                        passed_attr=passed_attr && soln_check_type::ok(my_ctx,expected);
                        --mout();
                    }
                }
                BOOST_CHECK(passed_attr);
            }//exit first tests
            bool passed_follow=true;
            if(passed_first)
            {//enter follow tests
                bool& passed_attr=passed_follow;
                typedef lookahead_type::ctx_follow_type ctx_type;
                ctx_type& my_ctx=my_lookahead.my_ctx_follow;
                std::string name_attr(lookahead::enum_names<lookahead::numerals_attr>()[ctx_type::attr_num]);
                utility::trace_scope ts(name_attr+" tests");
                typedef ctx_type::values_type values_type;
                typedef values_type::value_type value_type;
                {//check initial inp eval
                        typedef 
                      i<addop>::type
                    addop_var_type;
                    addop_var_type a_expr;
                    value_type expected;
                    {
                        value_type const actual=a_expr.get_follow();
                        bool const solved=actual == expected;
                        BOOST_CHECK(solved);
                        passed_attr = passed_attr && solved;
                        if(!solved)
                        {
                            std::cout<<"init.i<addop>="<<actual<<"\n";
                        }
                    }
                }
                {// solve
                    std::string passed_name=name_attr+"::solve_tests";
                    utility::trace_scope ts(passed_name);
                    bool const passed_ctx=my_ctx.solve
                    ( my_grm
                    );
                    BOOST_CHECK(passed_ctx);
                    passed_attr=passed_attr && passed_ctx;
                    {
                        values_type expected;
                        expected[fact]
                          .set(addop)
                          .set(mulop)
                          .set(rpar)
                          ;
                        expected[term]
                          .set(addop)
                          .set(rpar)
                          ;
                        expected[expr]
                          .set(rpar)
                          ;
                        mout()<<passed_name<<"="<<passed_ctx<<"\n";
                        ++mout();
                        typedef soln_check<ctx_type::attr_num,numerals_inp,numerals_out> soln_check_type;
                        passed_attr=passed_attr && soln_check_type::ok(my_ctx,expected);
                        --mout();
                    }
                }
                BOOST_CHECK(passed_attr);
            }//exit follow tests
        }
        
    };
}
void test_arith_eff(void)
{
    grm_arith_def::def();
}
int test_main(int,char**)
{
    test_arith_eff();
    return 0;
}
