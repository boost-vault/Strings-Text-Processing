///////////////////////////////////////////////////////////////////////////////
// as_marker_pop_capture.hpp
//
//  Copyright 2010 Erik Rydgren. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_XPRESSIVE_DETAIL_STATIC_TRANSFORMS_AS_MARKER_POP_CAPTURE_HPP_FER_10_01_2010
#define BOOST_XPRESSIVE_DETAIL_STATIC_TRANSFORMS_AS_MARKER_POP_CAPTURE_HPP_FER_10_01_2010

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/xpressive/detail/detail_fwd.hpp>
#include <boost/xpressive/detail/static/static.hpp>
#include <boost/proto/core.hpp>

namespace boost { namespace xpressive { namespace grammar_detail
{

    ///////////////////////////////////////////////////////////////////////////////
    // as_marker_pop_capture
    //   Insert mark pop capture tags before and after the expression
    struct as_marker_pop_capture : proto::transform<as_marker_pop_capture>
    {
        template<typename Expr, typename State, typename Data>
        struct impl : proto::transform_impl<Expr, State, Data>
        {
            typedef
                typename shift_right<
                    terminal<detail::mark_pop_capture_begin_matcher>::type
                  , typename shift_right<
                        typename proto::result_of::right<typename impl::expr>::type
                      , terminal<detail::mark_pop_capture_end_matcher >::type
                    >::type
                >::type
            result_type;

            result_type operator ()(
                typename impl::expr_param expr
              , typename impl::state_param
              , typename impl::data_param
            ) const
            {
                int mark_nbr = detail::get_mark_number(proto::child(proto::left(expr)));
                detail::mark_pop_capture_begin_matcher begin(mark_nbr);
                detail::mark_pop_capture_end_matcher end(mark_nbr);

                result_type that = {{begin}, {proto::right(expr), {end}}};
                return that;
            }
        };
    };

    ///////////////////////////////////////////////////////////////////////////////
    // as_marker_pop_grab_capture
    //   Insert mark pop capture tags before and after the expression
    struct as_marker_pop_n_cap_capture : proto::transform<as_marker_pop_n_cap_capture>
    {
        template<typename Expr, typename State, typename Data>
        struct impl : proto::transform_impl<Expr, State, Data>
        {
            typedef
                typename shift_right<
                    terminal<detail::mark_pop_capture_begin_matcher>::type
                  , typename shift_right<
                        typename proto::result_of::right<typename impl::expr>::type
                      , terminal<detail::mark_pop_n_cap_capture_end_matcher>::type
                    >::type
                >::type
            result_type;

            result_type operator ()(
                typename impl::expr_param expr
              , typename impl::state_param state
              , typename impl::data_param data
            ) const
            {
                int cap_mark_nbr = detail::get_mark_number(proto::left(proto::left(expr)));
                int pop_mark_nbr = detail::get_mark_number(proto::right(proto::left(expr)));
                detail::mark_pop_capture_begin_matcher begin(pop_mark_nbr);
                detail::mark_pop_n_cap_capture_end_matcher end(pop_mark_nbr, cap_mark_nbr);

                result_type that = {{begin}, {proto::right(expr), {end}}};
                return that;
            }
        };
    };
}}}

#endif
