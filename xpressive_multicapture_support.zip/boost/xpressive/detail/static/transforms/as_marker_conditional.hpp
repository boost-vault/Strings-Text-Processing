///////////////////////////////////////////////////////////////////////////////
// as_marker_conditional.hpp
//
//  Copyright 2010 Erik Rydgren. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_XPRESSIVE_DETAIL_STATIC_TRANSFORMS_AS_MARKER_CONDITIONAL_HPP_FER_10_01_2010
#define BOOST_XPRESSIVE_DETAIL_STATIC_TRANSFORMS_AS_MARKER_CONDITIONAL_HPP_FER_10_01_2010

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/xpressive/detail/detail_fwd.hpp>
#include <boost/xpressive/detail/static/static.hpp>
#include <boost/proto/core.hpp>

namespace boost { namespace xpressive { namespace grammar_detail
{

    ///////////////////////////////////////////////////////////////////////////////
    // as_marker_conditional
    //   Create conditional by converting expression into (marker.matched >> expression | !marker.matched)
    struct as_marker_conditional : proto::transform<as_marker_conditional>
    {
        template<typename Expr, typename State, typename Data>
        struct impl : proto::transform_impl<Expr, State, Data>
        {
            typedef typename proto::result_of::right<typename impl::expr>::type xpr_type;

            typedef 
                typename bitwise_or<
                    typename shift_right<
                        terminal<detail::mark_conditional_matcher<mpl::false_> >::type
                      , xpr_type
                    >::type
                  , terminal<detail::mark_conditional_matcher<mpl::true_> >::type
                >::type
            result_type;

            result_type operator ()(
                typename impl::expr_param expr
              , typename impl::state_param
              , typename impl::data_param data
            ) const
            {
                int mark_nbr = detail::get_mark_number(proto::left(expr));
                detail::mark_conditional_matcher<mpl::false_> cond(mark_nbr);
                detail::mark_conditional_matcher<mpl::true_> cond_inv(mark_nbr);
                result_type that = {{{cond}, proto::right(expr)}, {cond_inv}};
                return that;
            }
        };
    };
}}}

#endif
