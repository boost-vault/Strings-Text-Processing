///////////////////////////////////////////////////////////////////////////////
// mark_conditional_matcher.hpp
//
//  Copyright 2010 Erik Rydgren. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_XPRESSIVE_DETAIL_CORE_MATCHER_MARK_CONDITIONAL_MATCHER_HPP_FER_10_01_2010
#define BOOST_XPRESSIVE_DETAIL_CORE_MATCHER_MARK_CONDITIONAL_MATCHER_HPP_FER_10_01_2010

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/mpl/bool.hpp>
#include <boost/xpressive/detail/detail_fwd.hpp>
#include <boost/xpressive/detail/core/quant_style.hpp>
#include <boost/xpressive/detail/core/state.hpp>

namespace boost { namespace xpressive { namespace detail
{

    ///////////////////////////////////////////////////////////////////////////////
    // mark_conditional_matcher
    template<typename Invert>
    struct mark_conditional_matcher
      : quant_style<quant_fixed_width, 0, true>
    {
        int mark_number_;

        explicit mark_conditional_matcher(int mark_number)
          : mark_number_(mark_number)
        {
            BOOST_ASSERT(0 < this->mark_number_);
        }

        template<typename BidiIter, typename Next>
        bool match(match_state<BidiIter> &state, Next const &next) const
        {
            BOOST_ASSERT(this->mark_number_ < static_cast<int>(state.mark_count_));
            sub_match_impl<BidiIter> &br = state.sub_match(this->mark_number_);
            return br.matched ^ Invert() && next.match(state);
        }

    private:

        mark_conditional_matcher &operator =(mark_conditional_matcher const &);
    };

}}}

#endif
