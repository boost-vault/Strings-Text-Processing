///////////////////////////////////////////////////////////////////////////////
// mark_pop_capture_end_matcher.hpp
//
//  Copyright 2010 Erik Rydgren. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_XPRESSIVE_DETAIL_CORE_MATCHER_MARK_POP_CAPTURE_END_MATCHER_HPP_FER_10_01_2010
#define BOOST_XPRESSIVE_DETAIL_CORE_MATCHER_MARK_POP_CAPTURE_END_MATCHER_HPP_FER_10_01_2010

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/xpressive/detail/detail_fwd.hpp>
#include <boost/xpressive/detail/core/quant_style.hpp>
#include <boost/xpressive/detail/core/state.hpp>

namespace boost { namespace xpressive { namespace detail
{

    ///////////////////////////////////////////////////////////////////////////////
    // mark_pop_capture_end_matcher
    //
    struct mark_pop_capture_end_matcher
      : quant_style<quant_none, 0, false>
    {
        int mark_number_;

        mark_pop_capture_end_matcher(int mark_number)
          : mark_number_(mark_number)
        {
            BOOST_ASSERT(0 < this->mark_number_);
        }

        template<typename BidiIter, typename Next>
        bool match(match_state<BidiIter> &state, Next const &next) const
        {
            BOOST_ASSERT(this->mark_number_ < static_cast<int>(state.mark_count_));
            sub_match_impl<BidiIter> &br = state.sub_match(this->mark_number_);

            if (br.captures.empty())
                return false;

            sub_match_capture<BidiIter> capture = br.captures.back();
            br.captures.pop_back();

            BidiIter br_old_first = br.first;
            BidiIter br_old_second = br.second;
            bool br_old_zero_width = br.zero_width_;

            if (br.captures.empty()) {
                br.matched = false;
            }
            else {
                br.first = br.captures.back().first;
                br.second = br.captures.back().second;
            }

            // Tell the outer repeat that br is not zero width. 
            // Popbr has its own internal limit against wild recursion (no more captures).
            br.zero_width_ = false; 

            if(next.match(state))
            {
                return true;
            }

            br.captures.push_back(capture);

            br.first = br_old_first;
            br.second = br_old_second;
            br.matched = true;
            br.zero_width_ = br_old_zero_width;

            return false;
        }
    };

    struct mark_pop_n_cap_capture_end_matcher
      : quant_style<quant_none, 0, false>
    {
        int pop_mark_number_;
        int cap_mark_number_;

        mark_pop_n_cap_capture_end_matcher(int pop_mark_number, int cap_mark_number)
          : pop_mark_number_(pop_mark_number), cap_mark_number_(cap_mark_number)
        {
            BOOST_ASSERT(0 < this->pop_mark_number_);
            BOOST_ASSERT(0 < this->cap_mark_number_);
        }

        template<typename BidiIter, typename Next>
        bool match(match_state<BidiIter> &state, Next const &next) const
        {
            BOOST_ASSERT(this->pop_mark_number_ < static_cast<int>(state.mark_count_));
            BOOST_ASSERT(this->cap_mark_number_ < static_cast<int>(state.mark_count_));
            sub_match_impl<BidiIter> &popbr = state.sub_match(this->pop_mark_number_);
            sub_match_impl<BidiIter> &capbr = state.sub_match(this->cap_mark_number_);

            if (popbr.captures.empty())
                return false;

            BidiIter popbr_old_first = popbr.first;
            BidiIter popbr_old_second = popbr.second;
            bool popbr_old_zero_width = popbr.zero_width_;

            BidiIter capbr_old_first = capbr.first;
            BidiIter capbr_old_second = capbr.second;
            bool capbr_old_matched = capbr.matched;

            sub_match_capture<BidiIter> popped_capture = popbr.captures.back();
            popbr.captures.pop_back();

            if (popbr.captures.empty()) 
            {
                popbr.matched = false;
            }
            else 
            {
                popbr.first = popbr.captures.back().first;
                popbr.second = popbr.captures.back().second;
            }

            // Tell the outer repeat that popbr is not zero width. 
            // Popbr has its own internal limit against wild recursion (no more captures).
            popbr.zero_width_ = false; 

            capbr.first = popped_capture.first;
            capbr.second = state.cur_;
            capbr.matched = true;
            sub_match_capture<BidiIter> capture(capbr);

            if (capbr.capture_type_ == detail::capture_early)
                capbr.captures.push_back(capture);

            if(next.match(state))
            {
                if (capbr.capture_type_ == detail::capture_late)
                    capbr.captures.push_front(capture);

                return true;
            }

            if (capbr.capture_type_ == detail::capture_early)
                capbr.captures.pop_back();

            capbr.first = capbr_old_first;
            capbr.second = capbr_old_second;
            capbr.matched = capbr_old_matched;

            popbr.captures.push_back(popped_capture);
            popbr.first = popbr_old_first;
            popbr.second = popbr_old_second;
            popbr.matched = true;
            popbr.zero_width_ = popbr_old_zero_width;

            return false;
        }
    };

}}}

#endif
