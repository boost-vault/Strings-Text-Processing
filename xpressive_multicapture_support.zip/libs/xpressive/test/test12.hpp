///////////////////////////////////////////////////////////////////////////////
// test12.hpp
//
//  Copyright 2010 Erik Rydgren. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "./test.hpp"

///////////////////////////////////////////////////////////////////////////////
// get_test_cases
//
template<typename BidiIterT>
boost::iterator_range<xpr_test_case<BidiIterT> const *> get_test_cases()
{
    typedef typename boost::iterator_value<BidiIterT>::type char_type;
    typedef xpr_test_case<BidiIterT> xpr_test_case;
    typedef basic_regex<BidiIterT> regex_type;

    static char_type const *nilbr = 0;
    static char_type const *nilcap = 0;
    static char_type const *nextbr = nilcap-1;
    static xpr_test_case const test_cases[] =
    {
      xpr_test_case
        (
            "test175"
          , L("aabb")
          , regex_type(*(s1= _ >> _ ))
          , backrefs(L("aabb"), L("bb"), nilbr)
          , captures(
              L("aabb"), nextbr
            , L("aa"), L("bb"), nextbr
            , nilcap)
        )
      , xpr_test_case
        (
            "test176"
          , L("abba")
          , regex_type( repeat<2,2>(s1 = _) >> repeat<2,2>(s2 = _) )
          , backrefs(L("abba"), L("b"), L("a"), nilbr)
          , captures(
              L("abba"), nextbr
            , L("a"), L("b"), nextbr
            , L("b"), L("a"), nextbr
            , nilcap)
        )
      , xpr_test_case
        (
            "test177"
          , L("startabccbarest")
          , regex_type( bos >> (s1 = -*_) >> +(s2 = _) >> +(-s2 = s2) >> (s2 &= ~before(nil)) >> (s3 = *_) >> eos )
          , backrefs(L("startabccbarest"), L("start"), L(""), L("rest"), nilbr)
          , captures(
              L("startabccbarest"), nextbr
            , L("start"), nextbr
            , nextbr
            , L("rest"), nextbr
            , nilcap)
        )
      , xpr_test_case
        (
            "test178"
          , L("aabb")
          , regex_type( bos >> *(s1 = 'a') >> *(-s1 = 'b') >> (s1 &= ~before(nil)) >> eos )
          , backrefs(L("aabb"), L(""), nilbr)
        )
      , xpr_test_case
        (
            "test179"
          , L("aabbb")
          , regex_type( bos >> *(s1 = 'a') >> *(-s1 = 'b') >> (s1 &= ~before(nil)) >> eos )
          , no_match
        )
      , xpr_test_case
        (
            "test180"
          , L("aab")
          , regex_type( bos >> *(s1 = 'a') >> *(s2-s1 = 'b') >> (s1 &= ~before(nil)) >> eos )
          , no_match
        )
      , xpr_test_case
        (
            "test181"
          , L("abacbcaaacbcaabaa")
          , regex_type( (s1 = _) >> +_ >> (s1-s1 = s1) >> s1 )
          , backrefs(L("acbcaaacbcaa"), L("acbcaa"), nilbr)
          , captures(
              L("acbcaaacbcaa"), nextbr,
              L("acbcaa"), nextbr,
              nilcap)
        )
    };

    return boost::make_iterator_range(test_cases);
}
