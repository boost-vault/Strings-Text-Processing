/*=============================================================================
    Copyright (c) 2002-2003 Joel de Guzman
    http://spirit.sourceforge.net/

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/
////////////////////////////////////////////////////////////////////////////
//
//  Plain calculator example demostrating the grammar and semantic actions.
//  This is discussed in the "Grammar" and "Semantic Actions" chapters in
//  the Spirit User's Guide.
//
//  [ JDG 5/10/2002 ]
//
//  Copied from */libs/spirit/example/fundamental/calc_plain.cpp; then
//  modified to handle tagged unions instead of characters as terminals.
//  This was done in reponse to post:
/*
http://article.gmane.org/gmane.comp.parsers.spirit.general/12646
 */
//  with Subject: Re: Parsing of non-strings.
//
////////////////////////////////////////////////////////////////////////////
#include <boost/spirit/core.hpp>
#include <boost/range/iterator_range.hpp>
#include <iostream>
#include <string>
#define USE_VARIANT_TAGGED
#ifdef  USE_VARIANT_TAGGED
#include <boost/variant/variant_tagged.hpp>
#include <boost/mpl/vector.hpp>
#endif

////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace boost::spirit;

////////////////////////////////////////////////////////////////////////////
//
//  Semantic actions
//
////////////////////////////////////////////////////////////////////////////
namespace
{
      enum
    tok_nums
    { op0_num  //number
    , op2_add  //'+'
    , op2_sub  //'-'
    , op2_mul  //'*'
    , op2_div  //'/'
    , con_lpar //'('
    , con_rpar //')'
    };
      char const*
    tok_names[]=
    { "number"
    , "+"
    , "-"
    , "*"
    , "/"
    , "("
    , ")"
    };
        typedef
      int
    value_int
    ;
      struct 
    value_none//value of op2_* tokens
    {};
    
  #ifdef USE_VARIANT_TAGGED
        typedef
      boost::variant_tagged
      < boost::mpl::vector
        < value_int  //op0_num
        , value_none //op2_add
        , value_none //op2_sub
        , value_none //op2_mul
        , value_none //op2_dif
        , value_none //con_lpar
        , value_none //con_rpar
        >
      , tok_nums
      >
    atom
    ;
  #else

    union word {
        value_int  w_int; //op0_num value
        value_none w_op2; //op2_xxx,con_xxxx value
    };
    
    struct atom {
        tok_nums a_type; // encodes the type
        union word a_w;
        atom(atom const& a)
        : a_type(a.a_type)
        , a_w(a.a_w)
        {}
        atom(value_int a_int)
        : a_type(op0_num)
        {
            a_w.w_int = a_int;
        }
        atom(tok_nums a_num)
        : a_type(a_num)
        {
            a_w.w_op2 = value_none();
        }
    };
  #endif  
      ostream&
    operator<<
      ( ostream& sout
      , atom const& a_atom
      )
    {
        tok_nums a_tag=
        #ifdef USE_VARIANT_TAGGED
          a_atom.tag()
        #else
          a_atom.a_type
        #endif
        ;
        sout<<"("<<tok_names[a_tag]<<", ";
        if(a_tag == op0_num)
        {
            sout<<
            #ifdef USE_VARIANT_TAGGED
              a_atom.get<op0_num>()
            #else
              a_atom.a_w.w_int
            #endif
              ;
        }
        sout<<") ";
        return sout;
    }

        typedef
      std::vector
      < atom
      >
    tok_stream
    ;
        typedef
      tok_stream::const_iterator
    tok_iter
    ;
        typedef
      boost::iterator_range<tok_iter>
    tok_range
    ;
    void    do_int (atom tok)
    {
        cout << "PUSH" << tok << endl;
    }

    void    do_add1(tok_iter beg, tok_iter end)    
    { 
        cout << tok_names[op2_add]<<"(unary)\n"     ; 
        cout << "  "<<tok_range(beg,end) <<"\n";
    }
    void    do_sub1(tok_iter beg, tok_iter end)    
    { 
        cout << tok_names[op2_sub]<<"(unary)\n"     ; 
        cout << "  "<<tok_range(beg,end) <<"\n";
    }
    void    do_add (tok_iter beg, tok_iter end)    
    { 
        cout << tok_names[op2_add]<<"\n"     ; 
        cout << "  "<<tok_range(beg,end) <<"\n";
    }
    void    do_sub(tok_iter beg, tok_iter end)
    { 
        cout << tok_names[op2_sub]<<"\n"     ; 
        cout << "  "<<tok_range(beg,end) <<"\n";
    }
    void    do_mul(tok_iter beg, tok_iter end)
    { 
        cout << tok_names[op2_mul]<<"\n"     ; 
        cout << "  "<<tok_range(beg,end) <<"\n";
    }
    void    do_div(tok_iter beg, tok_iter end)
    { 
        cout << tok_names[op2_div]<<"\n"     ; 
        cout << "  "<<tok_range(beg,end) <<"\n";
    }
    
    struct toklit//modelled after chlit<CharT> in primitives.hpp
    : char_parser<toklit>
    {
        toklit(tok_nums ch_)
        : ch(ch_) {}

        bool test(atom a_atom) const
        {
            tok_nums a_tag=
            #ifdef USE_VARIANT_TAGGED
              a_atom.tag()
            #else
              a_atom.a_type
            #endif
            ;
            return a_tag == ch;
        }
        tok_nums   ch;
    };
    
}

////////////////////////////////////////////////////////////////////////////
//
//  Our calculator grammar
//
////////////////////////////////////////////////////////////////////////////
struct calculator : public grammar<calculator>
{
    template <typename ScannerT>
    struct definition
    {
        definition(calculator const& /*self*/)
        {
            expression
                =   term
                    >> *( toklit(op2_add) >> term[&do_add]
                        | toklit(op2_sub) >> term[&do_sub]
                        )
                ;

            term
                =   factor
                    >> *( toklit(op2_mul) >> factor[&do_mul]
                        | toklit(op2_div) >> factor[&do_div]
                        )
                ;

            factor
                =   toklit(op0_num)[&do_int]
                |   toklit(con_lpar) >> expression >> toklit(con_rpar)
                |   (toklit(op2_sub) >> factor)[&do_sub1]
                |   (toklit(op2_add) >> factor)[&do_add1]
                ;
        }

        rule<ScannerT> expression, term, factor;

        rule<ScannerT> const&
        start() const { return expression; }
    };
};

////////////////////////////////////////////////////////////////////////////
//
//  Main program
//
////////////////////////////////////////////////////////////////////////////
int
main()
{
    calculator calc;    //  Our parser

    tok_stream str;
  #ifdef  USE_VARIANT_TAGGED
    {
        value_none a_none;
        str.push_back(atom::_<op0_num>(10    ));
        str.push_back(atom::_<op2_add>(a_none));
        str.push_back(atom::_<op0_num>(11    ));
        str.push_back(atom::_<op2_mul>(a_none));
        str.push_back(atom::_<op0_num>(12    ));
    }
  #else
    str.push_back(atom(10));
    str.push_back(atom(op2_add));
    str.push_back(atom(11));
    str.push_back(atom(op2_mul));
    str.push_back(atom(12));
  #endif
    {
        tok_iter beg(str.begin());
        tok_iter end(str.end());
        parse_info<tok_iter> info = parse(beg,end, calc);

        if (info.full)
        {
            cout << "-------------------------\n";
            cout << "Parsing succeeded\n";
            cout << "-------------------------\n";
        }
        else
        {
            cout << "-------------------------\n";
            cout << "Parsing failed\n";
            cout << "stopped at: \": " << tok_range(info.stop,end) << "\"\n";
            cout << "-------------------------\n";
        }
    }
    cout << "Bye... :-) \n\n";
    return 0;
}


