#ifndef _BASIC_CONST_SUPER_STRING_HPP__
#define _BASIC_CONST_SUPER_STRING_HPP__


/* Copyright 2006 CrystalClear Software, Inc.
 * Use, modification and distribution is subject to the 
 * Boost Software License, Version 1.0. (See accompanying
 * file LICENSE-1.0 or http://www.boost.org/LICENSE-1.0)
 *
 * Author:  Jeff Garland 
 * Last Modified: $Date: 2006/07/03 02:43:02 $
 * Created: Sat Jun  29 14:02:41 2006 
 */


#include <boost/const_string/const_string.hpp>
#include <boost/const_string/concatenation.hpp>
#include <boost/const_string/io.hpp>

#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/regex.hpp>
#include <boost/regex.hpp>
#include <boost/format.hpp>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

/** Souped up immutable string class based on boost::const_string that 
 *  includes fancy query, replacement, and conversion functions.
*/
template<class char_type>
class basic_const_super_string : public boost::const_string<char_type> {
public:
  typedef boost::const_string<char_type>              ss_base_string_type;
  typedef boost::const_string<char_type>              base_string_type;
  typedef std::basic_string<char_type>                std_string_type;
  typedef typename base_string_type::const_iterator   iterator_type;
  typedef typename base_string_type::size_type        size_type;
  typedef std::basic_stringstream<char_type>          string_stream_type;
  typedef std::vector<basic_const_super_string<char_type> > string_vector;
  
  basic_const_super_string() 
  {}

  basic_const_super_string(const char_type* const s) :
    base_string_type(s)
  {}

  basic_const_super_string(const base_string_type& s) :
    base_string_type(s)
  {}

  basic_const_super_string(iterator_type beg, iterator_type end) :
    base_string_type(beg, end)
  {}

  //Append contents of a file to the string
  basic_const_super_string append_file(const std_string_type& filepath) const;

  //See if the string contains the regular expression somewhere
  bool contains_regex (const base_string_type& s) const;

  //Query functions for start / contains
  bool contains    (const base_string_type& s) const;
  bool starts_with (const base_string_type& s, size_type offset=0) const;
  bool ends_with   (const base_string_type& s) const;

  //Case insensitive query functions 
  bool icontains   (const base_string_type& s) const;
  bool istarts_with(const base_string_type& s, size_type offset=0) const;
  bool iends_with  (const base_string_type& s) const;

  //Split the string based on the predicate string
  unsigned int split(const base_string_type& predicate, 
                     string_vector& result)             const;

  unsigned int split_regex(const base_string_type& predicate_regex, 
                           string_vector& result)             const;
  

  //Enhanced replace functions
  basic_const_super_string
  replace_all_regex  (const base_string_type& match_regex, 
                      const base_string_type& replace_regex) const;

  basic_const_super_string 
  replace_first(const base_string_type& match_string, 
                const base_string_type& replace_string) const;

  basic_const_super_string 
  replace_last (const base_string_type& match_string, 
                const base_string_type& replace_string) const;

  basic_const_super_string 
  replace_nth  (const base_string_type& match_string, 
                const base_string_type& replace_string, 
                size_type n) const;

  basic_const_super_string 
  replace_all  (const base_string_type& match_string, 
                const base_string_type& replace_string) const;

  //Case insensitive enhanced replace functions
  basic_const_super_string 
  ireplace_first(const base_string_type& match_string, 
                 const base_string_type& replace_string) const;

  basic_const_super_string 
  ireplace_last (const base_string_type& match_string, 
                 const base_string_type& replace_string) const;

  basic_const_super_string 
  ireplace_nth  (const base_string_type& match_string, 
                 const base_string_type& replace_string, 
                 size_type n) const;

  basic_const_super_string 
  ireplace_all  (const base_string_type& match_string, 
                 const base_string_type& replace_string) const;
  
  //White space trimming functions
  basic_const_super_string trim()       const;
  basic_const_super_string trim_left()  const;
  basic_const_super_string trim_right() const;
  

  //Case Conversion
  basic_const_super_string  to_lower() const;
  basic_const_super_string  to_upper() const;


  //Type  conversion functions
  //JKG TODO: look at doing some meta-programming magic to write
  //the these functions with few overloads.
  template<typename T>
  basic_const_super_string<char_type> append    (const T& value) const;

  template<typename T1, typename T2>
  basic_const_super_string<char_type> append    (const T1& val1, 
                                                 const T2& val2) const;

  template<typename T1, typename T2, typename T3>
  basic_const_super_string<char_type> append    (const T1& val1, 
                                                 const T2& val2,
                                                 const T3& val3) const;
  
  template<typename T1, typename T2, typename T3, typename T4>
  basic_const_super_string<char_type> append    (const T1& val1, 
                                                 const T2& val2,
                                                 const T3& val3,
                                                 const T4& val4) const;

  template<typename T1, typename T2, typename T3, typename T4, typename T5>
  basic_const_super_string<char_type> append    (const T1& val1, 
                                                 const T2& val2,
                                                 const T3& val3,
                                                 const T4& val4,
                                                 const T5& val5) const;
  template<class T>
  basic_const_super_string<char_type> prepend   (const T& value) const;

  template<class T> 
  basic_const_super_string<char_type> insert_at (size_type pos, 
                                                 const T& value) const;

  template<typename T> 
  basic_const_super_string<char_type> append_formatted (const T& value, 
                                                        const base_string_type& fmt) const;
  template<typename T1, typename T2> 
  basic_const_super_string<char_type> append_formatted (const T1& val1, 
                                                        const T2& val2,
                                                        const base_string_type& fmt) const;
  template<typename T1, typename T2, typename T3> 
  basic_const_super_string<char_type> append_formatted (const T1& val1, 
                                                        const T2& val2,
                                                        const T3& val3,
                                                        const base_string_type& fmt) const;
  template<typename T1, typename T2, typename T3, typename T4> 
  basic_const_super_string<char_type> append_formatted (const T1& val1, 
                                                        const T2& val2,
                                                        const T3& val3,
                                                        const T4& val4,
                                                        const base_string_type& fmt) const;
  template<typename T1, typename T2, typename T3, typename T4, typename T5> 
  basic_const_super_string<char_type> append_formatted (const T1& val1, 
                                                        const T2& val2,
                                                        const T3& val3,
                                                        const T4& val4,
                                                        const T5& val5,
                                                        const base_string_type& fmt) const;


private:

};


/** Make a string from the contents of a file.
 *
 *@code
    super_string data;
    data.append_file("data1.txt").append_file(data2.txt);
 *@endcode
 *@return String built from reading in the entire file.
 *@param filepath Path to the file
 *
 *JKG TODO: throw an exception if file not found?
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append_file(const std_string_type& filepath) const
{
  std::ifstream infile(filepath.c_str());
  if (infile) {
    std::istreambuf_iterator<char> itr(infile);
    std::istreambuf_iterator<char> file_end;
    std_string_type data(itr, file_end);
    return base_string_type(this->str() + data);
  }
  return base_string_type();
}


/** Split a string into a string of vectors based on equality to a string
 *
 *@code
    super_string stuff("first-|-second-|-third");
    super_string::string_vector out_vec;
    if (stuff.split("-|-", out_vec)) {
      //iterate thru the vector and process
      //out_vec[0] == first
      //out_vec[1] == second
      //out_vec[2] == third
    }
 *@endcode
 *@return count of splits found
 *@param predicate String used to test against.
 *@param result Returns the each split string or the whole string as the first element
 *              of the vector.
 */
template<class char_type>
inline
unsigned int 
basic_const_super_string<char_type>::split(const base_string_type& predicate, 
                                     string_vector& result) const
{

  namespace alg = boost::algorithm;
  
  alg::iter_split(result, *this, 
                  alg::first_finder(predicate, alg::is_equal()));
  
  //iter_split will return entire string if no matches found
  return result.size()-1; //todo bug here is result not empty
}

/** Split a string into a string of vectors based regex string.
 *
 *@code
    super_string s("These   are   some    \t words--with whitespace");
    super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+|--", out_vec);

    if (count) {
      //iterate thru the vector and process
      //out_vec[0] == These
      //out_vec[4] == with
    }
 *@endcode
 *return count of splits found
 *@param predicate_regex Regular expression used to find string split points.
 *@param result Returns the each split string or the whole string as the first element
 *              of the vector.
 */
template<class char_type>
inline
unsigned int 
basic_const_super_string<char_type>::split_regex(const base_string_type& predicate_regex, 
                                                                   string_vector& result)  const
{

  boost::basic_regex<char_type> re(predicate_regex.begin(),
                                   predicate_regex.end());

  boost::regex_token_iterator<iterator_type> i(this->begin(), 
                                               this->end(), 
                                               re, -1);
  boost::regex_token_iterator<iterator_type> j;
  
  unsigned int count = 0;
  while(i != j) {
    base_string_type s(*i);
    result.push_back(s);
    count++;
    i++;
  }
  return count;
  
}


/** Query function using regular expression
 * 
 *
 @code
    super_string s("hello 2006-02-23");
    s.contains_regex("\\d{4}-\\d{2}-\\d{2}")); //true
    s.contains_regex("[A-Z]")); //false
 @endcode
 *
 *@param predicate_regex regular expression predicate_string string to check against
 *@throw boost::regex_error if predicate_string is not a valid regular expression
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::contains_regex(const base_string_type& predicate_regex) const
{
  boost::regex::basic_regex<char_type> pred(predicate_regex.begin(),
                                            predicate_regex.end());
  return boost::regex_search(this->begin(),
                             this->end(),
                             pred,
                             boost::match_default);
}


/** Replace the all instance of the match_string with the replace_format.

 @code

    super_string s("(abc)3333()(456789) [123] (1) (cde)");
    
    //replace parens around digits with #--the digits--#
    s = s.replace_all_regex("\\(([0-9]+)\\)", "#--$1--#");

    //s == "(abc)3333()#--456789--# [123] #--1--# (cde)"      

  @endcode
 *
 *@throw boost::regex_error if match_regex is not a valid regular expression
 *@param match_regex Regular expression to match against
 *@param replace_format Replacement expresssion
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::replace_all_regex(const base_string_type& match_regex, 
                                                                         const base_string_type& replace_format) const
{
  boost::regex::basic_regex<char_type> pred(match_regex.str());
  return base_string_type(boost::algorithm::replace_all_regex_copy(this->str(), 
                                                                   pred, 
                                                                   replace_format.str()));
}


/** Replace the all instance of the match_string with the replace_string
 * Has no effect on the string if there are no instances of match_string
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_all("foo", "bar", 1);
    //s == "bar bar bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::replace_all(const base_string_type& match_string, 
                                                                   const base_string_type& replace_string) const
{
  return base_string_type(boost::algorithm::replace_all_copy(this->str(), 
                                                             match_string, 
                                                             replace_string));
}


/** Replace the nth instance of the match_string with the replace_string
 * Has no effect on the string if there is no 'nth' version of the match
 * string.
 *@code
    super_string s("foo foo foo");
    s.replace_nth("foo", "bar", 1);
    //s == "foo bar foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 *@param n The instance to replace starting at 0
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::replace_nth(const base_string_type& match_string, 
                                                                   const base_string_type& replace_string,
                                                                   size_type n) const
{
  return base_string_type(boost::algorithm::replace_nth_copy(this->str(), 
                                                             match_string, 
                                                             n,
                                                             replace_string));
}


/** Replace the first instance of the match_string with the replace_string
 * Has no effect on the string if there is  match_string does not appear 
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_first("foo", "bar");
    //s == "bar foo foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::replace_first(const base_string_type& match_string, 
                                                                     const base_string_type& replace_string) const
{
  return base_string_type(boost::algorithm::replace_first_copy(this->str(), 
                                                               match_string, 
                                                               replace_string));
}


/** Replace the last instance of the match_string with the replace_string
 * Has no effect on the string if there is  match_string does not appear 
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_last("foo", "bar");
    //s == "foo foo bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::replace_last(const base_string_type& match_string, 
                                                                    const base_string_type& replace_string) const
{
  return base_string_type(boost::algorithm::replace_last_copy(this->str(), 
                                                              match_string, 
                                                              replace_string));
}

/** Case insensitive replace the all instance of the match_string with the replace_string
 * Has no effect on the string if there are no instances of match_string
 * in the string.
 *@code
    super_string s("foo FOO Foo");
    s.ireplace_all("foo", "bar", 1);
    //s == "bar bar bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::ireplace_all(const base_string_type& match_string, 
                                                                    const base_string_type& replace_string) const
{
  return base_string_type(boost::algorithm::ireplace_all_copy(this->str(), 
                                                              match_string, 
                                                              replace_string));
}


/** Case insensitive replace of the nth instance of the match_string 
 *  with the replace_string. Has no effect on the string if there is 
 *  no 'nth' version of the match string.
 *@code
    super_string s("foo FOO foo");
    s.ireplace_nth("foo", "bar", 1);
    //s == "foo bar foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 *@param n The instance to replace starting at 0
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::ireplace_nth(const base_string_type& match_string, 
                                                                    const base_string_type& replace_string,
                                                                    size_type n) const
{
  return base_string_type(boost::algorithm::ireplace_nth_copy(this->str(), 
                                                              match_string, 
                                                              n, 
                                                              replace_string));
}


/** Case insensitive replace the first instance of the match_string 
 *  with the replace_string.  Has no effect on the string if there 
 *  match_string does not appear in the string.
 *@code
    super_string s("FOO foo foo");
    s.ireplace_first("foo", "bar");
    //s == "bar foo foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::ireplace_first(const base_string_type& match_string, 
                                                                      const base_string_type& replace_string) const
{
  return base_string_type(boost::algorithm::ireplace_first_copy(this->str(), 
                                                                match_string, 
                                                                replace_string));
}


/** Case insensitive replace of the last instance of the match_string 
 *  with the replace_string.  Has no effect on the string if there 
 *  match_string does not appear in the string.
 *@code
    super_string s("foo foo FOO");
    s.ireplace_last("foo", "bar");
    //s == "foo foo bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::ireplace_last(const base_string_type& match_string, 
                                                                     const base_string_type& replace_string) const
{
  return base_string_type(boost::algorithm::ireplace_last_copy(this->str(), 
                                                               match_string, 
                                                               replace_string));
}


/** Query function to see if a string contains given string.
 * 
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::contains(const base_string_type& predicate_string) const
{
  return boost::algorithm::contains(*this, predicate_string);
}

/** Case insensitive query function to see if a string contains
 *  a given string.
 * 
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::icontains(const base_string_type& predicate_string) const
{
  return boost::algorithm::icontains(*this, predicate_string);
}


/** Query function to see if a string or substring ends with a given string.
 * 
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::ends_with(const base_string_type& predicate_string) const
{
  return boost::algorithm::ends_with(*this, predicate_string);
}

/** Case insensitive query function to see if a string or substring ends 
 *  with a given string.
 @code
    super_string s("hELlo");
    s.iends_with("llO"); //true
    s.iends_with("Hi")   //false
 @endcode
 *
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::iends_with(const base_string_type& predicate_string) const
{
  return boost::algorithm::iends_with(*this, predicate_string);
}


/** Query function to see if a string or substring starts with a given string.
 * 
 *@param predicate_string string to check against
 *@param offset point in string to start at - 0 is first position.
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::starts_with(const base_string_type& predicate_string,
                                           size_type offset) const
{
  return boost::algorithm::starts_with(this->substr(offset), predicate_string);
}

/** Case insensitive query function to see if a string or substring starts 
 *  with a given string.
 *@code

    super_string s("hELlo");
    s.istarts_with("el", 1); //returns true

 *@endcode
 *@param predicate_string string to check against
 *@param offset point in string to start at - 0 is first position.
 */
template<class char_type>
inline
bool
basic_const_super_string<char_type>::istarts_with(const base_string_type& predicate_string, 
                                            size_type offset) const
{
  return boost::algorithm::istarts_with(this->substr(offset), predicate_string);
}


/** Generic function to append any type to the string
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    s.append(dbl);
    s += " - "; //std::string method
    //append a date to the string
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s.append(d);
    //s == "1.543 - 2006-Jun-29"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append(const T& value) const
{
  string_stream_type ss;
  ss << value;
  return base_string_type(*this + ss.str());
}


/** Generic function to append 2 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    s.append("double: ", dbl);
    //s == "double: 1.543"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append(const T1& val1, const T2& val2) const
{
  string_stream_type ss;
  ss << val1 << val2;
  return base_string_type(*this + ss.str());
}

/** Generic function to append 3 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    int i = 10;
    s.append("value is: ", dbl, i);
    //s == "double: 1.54310"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append(const T1& val1, 
                                                              const T2& val2,
                                                              const T3& val3) const
{
  string_stream_type ss;
  ss << val1 << val2 << val3;
  return base_string_type(*this + ss.str());
}


/** Generic function to append 4 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    int i = 10;
    s.append("value is: ", dbl, " int: ", i);
    //s == "double: 1.543 int: 10"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append(const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            const T4& val4) const
{
  string_stream_type ss;
  ss << val1 << val2 << val3 << val4;
  return base_string_type(*this + ss.str());
}

/** Generic function to append 5 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    int i = 10;
    s.append("value is: ", dbl, " int: ", i);
    //s == "double: 1.543 int: 10"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4, typename T5>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append(const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            const T4& val4,
                                            const T5& val5) const
{
  string_stream_type ss;
  ss << val1 << val2 << val3 << val4 << val5;
  return base_string_type(*this + ss.str());
}


/** Generic function to append any type to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    s.append_fmt(dbl, "%-7.2f");
    s += " - "; //std::string method
    //s == "1.543 - 2006-Jun-29"

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 *JKG TODO: explain formatting strings and rules
 *JKG TODO: decide how to handle boost fmt exceptions
 */
template<class char_type>
template<typename T>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append_formatted(const T& value, 
                                                      const base_string_type& format) const
{
  boost::format f(format.str());
  string_stream_type ss;
  ss << *this << f % value;
  return base_string_type(ss.str());
}


/** Generic function to append 2 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    s.append_formatted(dbl, "some string", "%-7.2f %s" );
    //s == "1.12  some string"

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 *JKG TODO: explain formatting strings and rules
 */
template<class char_type>
template<typename T1, typename T2>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append_formatted(const T1& val1,
                                                      const T2& val2,
                                                      const base_string_type& format) const
{
  boost::format f(format.str());
  string_stream_type ss;
  ss << *this << f % val1 % val2;
  return base_string_type(ss.str());
}

/** Generic function to append 3 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s.append_formatted(dbl, dbl, i , "%-7.2f %-7.2f %-7d");
    //s == "1.23  1.23  1000   "

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 *JKG TODO: explain formatting strings and rules
 */
template<class char_type>
template<typename T1, typename T2, typename T3>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append_formatted(const T1& val1,
                                                      const T2& val2,
                                                      const T3& val3,
                                                      const base_string_type& format) const
{
  boost::format f(format.str());
  string_stream_type ss;
  ss << *this << f % val1 % val2 % val3;
  return base_string_type(ss.str());
}


/** Generic function to append 4 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s.append_formatted(dbl, i , dbl, i, "%-7.2f %-7d %-7.2f %-7d");
    //s == "1.12   1000  1.12   1000   "

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 *JKG TODO: explain formatting strings and rules
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append_formatted(const T1& val1,
                                                      const T2& val2,
                                                      const T3& val3,
                                                      const T4& val4,
                                                      const base_string_type& format) const
{
  boost::format f(format.str());
  string_stream_type ss;
  ss << *this << f % val1 % val2 % val3 % val4;
  return base_string_type(ss.str());
}

/** Generic function to append 5 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s.append_formatted(dbl, i , dbl, i, "a string", "%-7.2f %-7d %-7.2f %-7d %s");
    //s == "1.12   1000  1.12   1000   a string"

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 *JKG TODO: explain formatting strings and rules
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4, typename T5>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::append_formatted(const T1& val1,
                                                      const T2& val2,
                                                      const T3& val3,
                                                      const T4& val4,
                                                      const T5& val5,
                                                      const base_string_type& format) const
{
  boost::format f(format.str());
  string_stream_type ss;
  ss << *this << f % val1 % val2 % val3 % val4 % val5;
  return base_string_type(ss.str());
}


/** Generic function to prepend any type to the string
 *  This function will work with any type that is OutputStreamable.

@code

    super_string s( "Hello There");
    double dbl = 1.543;
    s.prepend(dbl);
    //s == "1.543 Hello There"

@endcode

 *@return Returns self-reference for chained operations
 *
 */
template<class char_type>
template<class T>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::prepend(const T& value) const
{
  string_stream_type ss;
  ss << value;
  return base_string_type(ss.str()+this->str());
}

/** Generic function to insert an OutputStreamable type into the string.
 *  
@code

    super_string s( "Hello  There");
    double dbl = 1.543;
    s.prepend(dbl);
    //s == "Hello 1.543 There"

@endcode
 *@param position Zero-based index of location in string to insert data
 *@param value Value to insert into the string
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<class T>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::insert_at(size_type position, 
                                               const T& value) const
{
  string_stream_type ss;
  ss << this->substr(0, position) << value << this->substr(position);
  
  return base_string_type(ss.str());
}



/** Change to upper case using the global locale
 * The global local can be replaced by calling 
 * std::global(locale)
 * 
 *@return Returns modified string for chained operations
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::to_upper() const
{
  //TODO: more hacking here...pure to_upper_copy fails
  std::basic_string<char_type> s(this->str());
  boost::algorithm::to_upper(s);
  return basic_const_super_string<char_type>(s);
}


/** Change to lower case using the global locale
 * The global local can be replaced by calling 
 * std::global(locale)
 * 
 *@return Returns modified string for chained operations
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::to_lower() const
{
  //TODO: more hacking here...pure to_upper_copy fails
  std::basic_string<char_type> s(this->str());
  boost::algorithm::to_lower(s);
  return basic_const_super_string<char_type>(s);
}

/** Trim whitespace from the both sides of the string making a copy.
 * 
 *@return Copy of trimmed string
 *
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::trim() const
{
  return boost::algorithm::trim_copy(*this);
}



/** Trim whitespace from the left side of the string making a copy.
 * 
 *
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::trim_left() const
{
  return boost::algorithm::trim_left_copy(*this);
}


/** Trim whitespace from the right side of the string making a copy.
 * 
 *
 */
template<class char_type>
inline
basic_const_super_string<char_type>
basic_const_super_string<char_type>::trim_right() const
{
  return boost::algorithm::trim_right_copy(*this);
}



typedef basic_const_super_string<char> const_super_string;

typedef basic_const_super_string<wchar_t> wconst_super_string;


#endif
