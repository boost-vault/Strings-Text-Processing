#ifndef _BASIC_SUPER_STRING_HPP__
#define _BASIC_SUPER_STRING_HPP__


/* Copyright 2006 CrystalClear Software, Inc.
 * Use, modification and distribution is subject to the 
 * Boost Software License, Version 1.0. (See accompanying
 * file LICENSE-1.0 or http://www.boost.org/LICENSE-1.0)
 *
 * Author:  Jeff Garland 
 * Last Modified: $Date: 2006/07/03 02:43:02 $
 * Created: Sat Jun  29 14:02:41 2006 
 */


#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/regex.hpp>
#include <boost/regex.hpp>
#include <boost/format.hpp>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>

//forward declare collection type
template<typename char_type> class basic_super_string_vector;

/** Souped up string class that includes fancy query, replacement, 
 *  and conversion functions.
 * 
 * Overall, this class is mostly a convience wrapper around functions
 * available in  boost.string_algo and boost.regex. 
 *
*/

template<class char_type >
class basic_super_string : public std::basic_string<char_type> {
public:
  typedef std::basic_string<char_type>                ss_base_string_type;
  typedef std::basic_string<char_type>                base_string_type;
  typedef typename base_string_type::const_iterator   iterator_type;
  typedef typename base_string_type::size_type        size_type;
  typedef std::basic_ostringstream<char_type>         string_stream_type;
  typedef std::vector<basic_super_string<char_type> > string_vector;
  
  /** @name Construction 
      Various constructors
   */
  //@{ 
  /** Default constructor. */
  basic_super_string() 
  {}

  /** Construct from a char pointer */
  basic_super_string(const char_type* const s) :
    base_string_type(s)
  {}

  /** Construct from std::basic_string type */
  basic_super_string(const base_string_type& s) :
    base_string_type(s)
  {}

  /** Construct from iterators */
  basic_super_string(iterator_type beg, iterator_type end) :
    base_string_type(beg, end)
  {}
  //@}

  /** @name Basic Queries 
      Content checking query functions to check for substrings.
   */
  //@{ 
  bool contains       (const base_string_type& s) const;
  bool contains_regex (const base_string_type& s) const;
  bool starts_with    (const base_string_type& s, size_type offset=0) const;
  bool ends_with      (const base_string_type& s) const;
  //@}

  /** @name Case Insentitive Queries 
      Case Insensitive content checking query functions to check for substrings.
   */
  //@{ 
  bool icontains   (const base_string_type& s) const;
  bool istarts_with(const base_string_type& s, size_type offset=0) const;
  bool iends_with  (const base_string_type& s) const;
  //@}

  /** @name Split Functions
      Split the string based on the predicate string
   */
  //@{ 

  unsigned int split(const base_string_type& predicate, 
                     string_vector& result)             const;

  unsigned int split_regex(const base_string_type& predicate_regex, 
                           string_vector& result)             const;
  //@}
  

  /** @name Acquire File Content
     Append contents of a file to the string
   */
  //@{ 
  basic_super_string& append_file(const base_string_type& filepath);

  //@}


  /** @name Replace Functions
      Enhanced replace functions
   */
  //@{ 

  basic_super_string& replace_all_regex  (const base_string_type& match_regex, 
                                          const base_string_type& replace_regex);

  basic_super_string& replace_first(const base_string_type& match_string, 
                                    const base_string_type& replace_string);
  basic_super_string& replace_last (const base_string_type& match_string, 
                                    const base_string_type& replace_string);
  basic_super_string& replace_nth  (const base_string_type& match_string, 
                                    const base_string_type& replace_string, 
                                    size_type n);
  basic_super_string& replace_all  (const base_string_type& match_string, 
                                    const base_string_type& replace_string);
  //@}

  /** @name Replace Functions - case insensitve
     Case insensitive enhanced replace functions
   */
  //@{ 
  basic_super_string& ireplace_first(const base_string_type& match_string, 
                                     const base_string_type& replace_string);
  basic_super_string& ireplace_last (const base_string_type& match_string, 
                                     const base_string_type& replace_string);
  basic_super_string& ireplace_nth  (const base_string_type& match_string, 
                                     const base_string_type& replace_string, 
                                     size_type n);
  basic_super_string& ireplace_all  (const base_string_type& match_string, 
                                     const base_string_type& replace_string);
  
  //@}

  /** @name Trim Functions
     White space trimming functions
   */
  //@{ 
  basic_super_string& trim();
  basic_super_string& trim_left();
  basic_super_string& trim_right();
  //@}
  

  /** @name Case Conversion Functions
     Convert the string case using the global locale.
   */
  //@{ 
  basic_super_string& to_upper();
  basic_super_string& to_lower();
  //@}


  template<typename T>
  basic_super_string<char_type>& append    (const T& value);

  template<typename T1, typename T2>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2);

  template<typename T1, typename T2, typename T3>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2,
                                            const T3& val3);

  
  template<typename T1, typename T2, typename T3, typename T4>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            const T4& val4);


  /** @name Basic Type Conversion
     Convert and append, prepend, and insert a streamable type to the
     the string.
   */
  //@{ 
  template<typename T1, typename T2, typename T3, typename T4, typename T5>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            const T4& val4,
                                            const T5& val5);
  template<class T>
  basic_super_string<char_type>& prepend   (const T& value);

  template<class T> 
  basic_super_string<char_type>& insert_at (size_type pos, const T& value);
  //@}


  template<typename T>
  basic_super_string<char_type>& append    (const T& value,
                                            string_stream_type& ss); 

  template<typename T1, typename T2>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2, 
                                            string_stream_type& ss);

  template<typename T1, typename T2, typename T3>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            string_stream_type& ss);

  template<typename T1, typename T2, typename T3, typename T4>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            const T4& val4,
                                            string_stream_type& ss);

  /** @name Basic Type Conversion with supplied Stringstream
     Convert and append a streamable type to the string.
   */
  //@{ 

  template<typename T1, typename T2, typename T3, typename T4, typename T5>
  basic_super_string<char_type>& append    (const T1& val1, 
                                            const T2& val2,
                                            const T3& val3,
                                            const T4& val4,
                                            const T5& val5,
                                            string_stream_type& ss);
  //@}


  template<typename T> 
  basic_super_string<char_type>& append_formatted (const T& value, 
                                                   const base_string_type& fmt);

  template<typename T1, typename T2> 
  basic_super_string<char_type>& append_formatted (const T1& val1, 
                                                   const T2& val2,
                                                   const base_string_type& fmt);
  template<typename T1, typename T2, typename T3> 
  basic_super_string<char_type>& append_formatted (const T1& val1, 
                                                   const T2& val2,
                                                   const T3& val3,
                                                   const base_string_type& fmt);
  template<typename T1, typename T2, typename T3, typename T4> 
  basic_super_string<char_type>& append_formatted (const T1& val1, 
                                                   const T2& val2,
                                                   const T3& val3,
                                                   const T4& val4,
                                                   const base_string_type& fmt);

  /** @name Formatted Type Conversion
      Use formatting strings to append arbitrary types to string.
   */
  //@{ 

  template<typename T1, typename T2, typename T3, typename T4, typename T5> 
  basic_super_string<char_type>& append_formatted (const T1& val1, 
                                                   const T2& val2,
                                                   const T3& val3,
                                                   const T4& val4,
                                                   const T5& val5,
                                                   const base_string_type& fmt);

  //@}


private:

};


/** Make a string from the contents of a file.
 *
  @code

    super_string data;
    data.append_file("data1.txt").append_file(data2.txt);

  @endcode
  @return String built from reading in the entire file.
  @param filepath Path to the file
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::append_file(const base_string_type& filepath)
{
  std::ifstream infile(filepath.c_str());
  if (infile) {
    std::istreambuf_iterator<char> itr(infile);
    std::istreambuf_iterator<char> file_end;
    base_string_type data(itr, file_end);
    this->append(data);
  }
  return *this;
}


/** Split a string into a string of vectors based on equality to a string
 *
 *@code
    super_string stuff("first-|-second-|-third");
    super_string::string_vector out_vec;
    if (stuff.split("-|-", out_vec)) {
      //iterate thru the vector and process
      //out_vec[0] == first
      //out_vec[1] == second
      //out_vec[2] == third
    }
  @endcode
 *@return count of splits found
 *@param predicate String used to test against.
 *@param result Returns the each split string or the whole string as the first element
 *              of the vector.
 */
template<class char_type>
inline
unsigned int 
basic_super_string<char_type>::split(const base_string_type& predicate, 
                                     string_vector& result) const
{

  namespace alg = boost::algorithm;
  
  alg::iter_split(result, *this, 
                  alg::first_finder(predicate, alg::is_equal()));
  
  //iter_split will return entire string if no matches found
  return result.size()-1; //todo bug here is result not empty
}

/** Split a string into a string of vectors based regex string.
 *
  @note Requires the liking of boost.regex library.
  @code
    super_string s("These   are   some    \t words--with whitespace");
    super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+|--", out_vec);

    if (count) {
      //iterate thru the vector and process
      //out_vec[0] == These
      //out_vec[4] == with
    }
  @endcode
  @return count of splits found
  @param predicate_regex Regular expression used to find string split points.
  @param result Returns the each split string or the whole string as the first element
                of the vector.
 */
template<class char_type>
inline
unsigned int 
basic_super_string<char_type>::split_regex(const base_string_type& predicate_regex, 
                                           string_vector& result)  const
{

  boost::basic_regex<char_type> re(predicate_regex);
  boost::regex_token_iterator<iterator_type> i(this->begin(), this->end(), re, -1);
  boost::regex_token_iterator<iterator_type> j;
  
  unsigned int count = 0;
  while(i != j) {
    base_string_type s(*i);
    result.push_back(s);
    count++;
    i++;
  }
  return count;
  
}


/** Query function using regular expression
 * This is meant to function much like the 
 * perl =~ operator.

 @note Requires the liking of boost.regex library.
 
 @code
    super_string s("hello 2006-02-23");
    s.contains_regex("\\d{4}-\\d{2}-\\d{2}")); //true
    s.contains_regex("[A-Z]")); //false
 @endcode
 
 @param predicate_regex regular expression predicate_string string to check against
 @throw boost::regex_error if predicate_string is not a valid regular expression
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::contains_regex(const base_string_type& predicate_regex) const
{
  boost::regex::basic_regex<char_type> pred(predicate_regex.begin(),
                                            predicate_regex.end());
  return boost::regex_search(this->begin(),
                             this->end(),
                             pred,
                             boost::match_default);
}


/** Replace the all instance of the match_string with the replace_format.
 @note Requires the liking of boost.regex library.
 @code

    super_string s("(abc)3333()(456789) [123] (1) (cde)");
    
    //replace parens around digits with #--the digits--#
    s.replace_all_regex("\\(([0-9]+)\\)", "#--$1--#");

    //s == "(abc)3333()#--456789--# [123] #--1--# (cde)"      

  @endcode
  @throw boost::regex_error if match_regex is not a valid regular expression
  @param match_regex Regular expression to match against
  @param replace_format Replacement expresssion
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::replace_all_regex(const base_string_type& match_regex, 
                                                 const base_string_type& replace_format) 
{
  boost::regex::basic_regex<char_type> pred(match_regex);
  boost::algorithm::replace_all_regex(*this, pred, replace_format);
  return *this;
}


/** Replace the all instance of the match_string with the replace_string
 * Has no effect on the string if there are no instances of match_string
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_all("foo", "bar", 1);
    //s == "bar bar bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::replace_all(const base_string_type& match_string, 
                                           const base_string_type& replace_string) 
{
  boost::algorithm::replace_all(*this, match_string, replace_string);
  return *this;
}


/** Replace the nth instance of the match_string with the replace_string
 * Has no effect on the string if there is no 'nth' version of the match
 * string.
 *@code
    super_string s("foo foo foo");
    s.replace_nth("foo", "bar", 1);
    //s == "foo bar foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 *@param n The instance to replace starting at 0
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::replace_nth(const base_string_type& match_string, 
                                           const base_string_type& replace_string,
                                           size_type n) 
{
  boost::algorithm::replace_nth(*this, match_string, n, replace_string);
  return *this;
}


/** Replace the first instance of the match_string with the replace_string
 * Has no effect on the string if there is  match_string does not appear 
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_first("foo", "bar");
    //s == "bar foo foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::replace_first(const base_string_type& match_string, 
                                             const base_string_type& replace_string) 
{
  this->replace_nth(match_string, replace_string, 0);
  return *this;
}


/** Replace the last instance of the match_string with the replace_string
 * Has no effect on the string if there is  match_string does not appear 
 * in the string.
 *@code
    super_string s("foo foo foo");
    s.replace_last("foo", "bar");
    //s == "foo foo bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::replace_last(const base_string_type& match_string, 
                                            const base_string_type& replace_string) 
{
  boost::algorithm::replace_last(*this, match_string, replace_string);
  return *this;
}

/** Case insensitive replace the all instance of the match_string with the replace_string
 * Has no effect on the string if there are no instances of match_string
 * in the string.
 *@code
    super_string s("foo FOO Foo");
    s.ireplace_all("foo", "bar", 1);
    //s == "bar bar bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::ireplace_all(const base_string_type& match_string, 
                                           const base_string_type& replace_string) 
{
  boost::algorithm::ireplace_all(*this, match_string, replace_string);
  return *this;
}


/** Case insensitive replace of the nth instance of the match_string 
 *  with the replace_string. Has no effect on the string if there is 
 *  no 'nth' version of the match string.
 *@code
    super_string s("foo FOO foo");
    s.ireplace_nth("foo", "bar", 1);
    //s == "foo bar foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 *@param n The instance to replace starting at 0
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::ireplace_nth(const base_string_type& match_string, 
                                            const base_string_type& replace_string,
                                            size_type n) 
{
  boost::algorithm::ireplace_nth(*this, match_string, n, replace_string);
  return *this;
}


/** Case insensitive replace the first instance of the match_string 
 *  with the replace_string.  Has no effect on the string if there 
 *  match_string does not appear in the string.
 *@code
    super_string s("FOO foo foo");
    s.ireplace_first("foo", "bar");
    //s == "bar foo foo"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::ireplace_first(const base_string_type& match_string, 
                                             const base_string_type& replace_string) 
{
  this->ireplace_nth(match_string, replace_string, 0);
  return *this;
}


/** Case insensitive replace of the last instance of the match_string 
 *  with the replace_string.  Has no effect on the string if there 
 *  match_string does not appear in the string.
  @code
    super_string s("foo foo FOO");
    s.ireplace_last("foo", "bar");
    //s == "foo foo bar"
  @endcode
 *@param match_string String to find and replace against
 *@param replace_string String to use in replacement
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::ireplace_last(const base_string_type& match_string, 
                                             const base_string_type& replace_string) 
{
  boost::algorithm::ireplace_last(*this, match_string, replace_string);
  return *this;
}


/** Query function to see if a string contains given string.
 @code
    super_string s("hello");
    s.contains("lo"); //true
    s.contains("hi"); //false
 @endcode 

 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::contains(const base_string_type& predicate_string) const
{
  return boost::algorithm::contains(*this, predicate_string);
}

/** Case insensitive query function to see if a string contains
 *  a given string.
 @code
    super_string s("hELlo");
    s.icontains("llO"); //true
    s.icontains("Hi");  //false
 @endcode 

 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::icontains(const base_string_type& predicate_string) const
{
  return boost::algorithm::icontains(*this, predicate_string);
}


/** Query function to see if a string or substring ends with a given string.
 @code 
    super_string s("hello");
    s.ends_with("lo"); //true
    s.ends_with("hi"); //false
 @endcode

 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::ends_with(const base_string_type& predicate_string) const
{
  return boost::algorithm::ends_with(*this, predicate_string);
}

/** Case insensitive query function to see if a string or substring ends 
 *  with a given string.
 @code
    super_string s("hELlo");
    s.iends_with("llO"); //true
    s.iends_with("Hi")   //false
 @endcode
 *
 *@param predicate_string string to check against
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::iends_with(const base_string_type& predicate_string) const
{
  return boost::algorithm::iends_with(*this, predicate_string);
}


/** Query function to see if a string or substring starts with a given string.
 * 
 *@param predicate_string string to check against
 *@param offset point in string to start at - 0 is first position.
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::starts_with(const base_string_type& predicate_string,
                                           size_type offset) const
{
  return boost::algorithm::starts_with(this->substr(offset), predicate_string);
}

/** Case insensitive query function to see if a string or substring starts 
 *  with a given string.
 *@code

    super_string s("hELlo");
    s.istarts_with("el", 1); //returns true

  @endcode
 *@param predicate_string string to check against
 *@param offset point in string to start at - 0 is first position.
 */
template<class char_type>
inline
bool
basic_super_string<char_type>::istarts_with(const base_string_type& predicate_string, 
                                            size_type offset) const
{
  return boost::algorithm::istarts_with(this->substr(offset), predicate_string);
}


/*  Generic function to append any type to the string
 *  This function will work with any type that is OutputStreamable.
 *
 @code

    super_string s;
    double dbl = 1.543;
    s.append(dbl);
    s += " - "; //std::string method
    //append a date to the string
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s.append(d);
    //s == "1.543 - 2006-Jun-29"

 @endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T& value)
{
  string_stream_type ss;
  ss << value;
  *this += ss.str();
  return *this;
}

/*  Generic function to append any type to the string
 *  This is a faster version of the convert and append function.
 *  Use this version if doing a large number of conversions.  This
 *  version of the function also allows the user to control format 
 *  settings on the conversion by applying changes to the stringstream
 *  used to do the conversion.
 *  This function will work with any type that is OutputStreamable.
 *  
 *
 @code

    std::ostringstream ss;
    s.setprecision(
    super_string s;
    ss << std::setprecision(3);
    double dbl = 1.987654321;
    s.append(dbl, ss);
    //s == "1.99 - 2006-Jun-29"
    //ss -- has been modified

 @endcode
 *@param value Value to be appended to the string.
 *@param ss A stream to use in the conversion -- all data will be reset.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T& value,
                                      string_stream_type& ss)
{
  ss.str("");
  ss << value;
  *this += ss.str();
  return *this;
}



/*  Generic function to append 2 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    s.append("double: ", dbl);
    //s == "double: 1.543"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, const T2& val2)
{
  string_stream_type ss;
  ss << val1 << val2;
  *this += ss.str();
  return *this;
}


/*  Generic function to append any type to the string
 *  This is a faster version of the convert and append function.
 *  Use this version if doing a large number of conversions.  This
 *  version of the function also allows the user to control format 
 *  settings on the conversion by applying changes to the stringstream
 *  used to do the conversion.
 *  This function will work with any type that is OutputStreamable.
 *  
 *
 @code

    std::ostringstream ss;
    s.setprecision(
    super_string s;
    ss << std::setprecision(3);
    double dbl = 1.987654321;
    s.append(dbl, ss);
    //s == "1.99 - 2006-Jun-29"
    //ss -- has been modified

 @endcode
 *@param val1 First value to be appended to the string.
 *@param val2 Second value to be appended to the string.
 *@param ss A stream to use in the conversion -- all data will be reset.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      string_stream_type& ss)
{
  ss.str("");
  ss << val1 << val2;
  *this += ss.str();
  return *this;
}

/*  Generic function to append 3 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    int i = 10;
    s.append("value is: ", dbl, i);
    //s == "double: 1.54310"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      const T3& val3)
{
  string_stream_type ss;
  ss << val1 << val2 << val3;
  *this += ss.str();
  return *this;
}


/*  Generic function to append any type to the string
 *  This is a faster version of the convert and append function.
 *  Use this version if doing a large number of conversions.  This
 *  version of the function also allows the user to control format 
 *  settings on the conversion by applying changes to the stringstream
 *  used to do the conversion.
 *  This function will work with any type that is OutputStreamable.
 *  
 *
 @code

    std::ostringstream ss;
    super_string s;
    ss << std::setprecision(3);
    double dbl = 1.987654321;
    int i = 1000;
    s.append(dbl, i, " stuff", ss);
    //s == "1.99 1000 stuff"
    //ss -- has been modified

 @endcode
 *@param val1 First value to be appended to the string.
 *@param val2 Second value to be appended to the string.
 *@param val3 Third value to be appended to the string.
 *@param ss A stream to use in the conversion -- all data will be reset.
 *@return Returns self-reference for chained operations
 */

template<class char_type>
template<typename T1, typename T2, typename T3>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      const T3& val3,
                                      string_stream_type& ss)
{
  ss.str("");
  ss << val1 << val2 << val3;
  *this += ss.str();
  return *this;
}


/*  Generic function to append 4 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    int i = 10;
    s.append("value is: ", dbl, " int: ", i);
    //s == "double: 1.543 int: 10"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      const T3& val3,
                                      const T4& val4)
{
  string_stream_type ss;
  ss << val1 << val2 << val3 << val4;
  *this += ss.str();
  return *this;
}


/*  Generic function to append any type to the string
 *  This is a faster version of the convert and append function.
 *  Use this version if doing a large number of conversions.  This
 *  version of the function also allows the user to control format 
 *  settings on the conversion by applying changes to the stringstream
 *  used to do the conversion.
 *  This function will work with any type that is OutputStreamable.
 *  
 *
 @code

    std::ostringstream ss;
    s.setprecision(
    super_string s;
    ss << std::setprecision(3);
    double dbl = 1.987654321;
    int i = 1000;
    s.append(dbl, i, i, " stuff", ss);
    //s == "1.99 1000 1000 stuff"
    //ss -- has been modified

 @endcode
 *@param val1 First value to be appended to the string.
 *@param val2 Second value to be appended to the string.
 *@param val3 Third value to be appended to the string.
 *@param val4 Fourth value to be appended to the string.
 *@param ss A stream to use in the conversion -- all data will be reset.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      const T3& val3,
                                      const T4& val4,
                                      string_stream_type& ss)
{
  ss.str("");
  ss << val1 << val2 << val3 << val4;
  *this += ss.str();
  return *this;
}


/** Generic function to append 5 values
 *  This function will work with any type that is OutputStreamable.
 *
@code

    super_string s;
    double dbl = 1.543;
    int i = 10;
    s.append("value is: ", dbl, " int: ", i);
    //s == "double: 1.543 int: 10"

@endcode
 *@param value Value to be appended to the string.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4, typename T5>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      const T3& val3,
                                      const T4& val4,
                                      const T5& val5)
{
  string_stream_type ss;
  ss << val1 << val2 << val3 << val4 << val5;
  *this += ss.str();
  return *this;
}


/** Generic function to append any type to the string
 *  This is a faster version of the convert and append function.
 *  Use this version if doing a large number of conversions.  This
 *  version of the function also allows the user to control format 
 *  settings on the conversion by applying changes to the stringstream
 *  used to do the conversion.
 *  This function will work with any type that is OutputStreamable.
 *  
 *
 @code

    std::ostringstream ss;
    s.setprecision(
    super_string s;
    ss << std::setprecision(3);
    double dbl = 1.987654321;
    int i = 1000;
    s.append(dbl, i, i, " stuff", dbl, ss);
    //s == "1.99 1000 1000 1.99 stuff"
    //ss -- has been modified

 @endcode
 *@param val1 First value to be appended to the string.
 *@param val2 Second value to be appended to the string.
 *@param val3 Third value to be appended to the string.
 *@param val4 Fourth value to be appended to the string.
 *@param ss A stream to use in the conversion -- all data will be reset.
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4, typename T5>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::append(const T1& val1, 
                                      const T2& val2,
                                      const T3& val3,
                                      const T4& val4,
                                      const T5& val5,
                                      string_stream_type& ss)
{
  ss.str("");
  ss << val1 << val2 << val3 << val4 << val5;
  *this += ss.str();
  return *this;
}


/* Generic function to append any type to the string including formatting
 * See: 
 <a href="http://www.boost.org/libs/format/doc/format.html#printf_directives">Boost Format specification syntax</a> 
   for details on the formmatting strings.

@code

    super_string s;
    double dbl = 1.123456789;
    s.append_fmt(dbl, "%-7.2f");
    s += " - "; //std::string method
    //s == "1.543 - 2006-Jun-29"

@endcode

  @value - The value to append to the end of the string.
  @format - Formatting string for the value.
  @return Returns self-reference for chained operations
 
  @throw Boost format exceptions: see <a href="http://www.boost.org/libs/format/doc/format.html#exceptions">Boost Format Exceptions.</a> for details.

 */
template<class char_type>
template<typename T>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::append_formatted(const T& value, 
                                                const base_string_type& format)
{
  boost::format f(format);
  string_stream_type ss;
  ss << f % value;
  *this += ss.str();
  return *this;
}


/* Generic function to append 2 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    s.append_formatted(dbl, "some string", "%-7.2f %s" );
    //s == "1.12  some string"

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 */
template<class char_type>
template<typename T1, typename T2>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::append_formatted(const T1& val1,
                                                const T2& val2,
                                                const base_string_type& format)
{
  boost::format f(format);
  string_stream_type ss;
  ss << f % val1 % val2;
  *this += ss.str();
  return *this;
}

/* Generic function to append 3 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s.append_formatted(dbl, dbl, i , "%-7.2f %-7.2f %-7d");
    //s == "1.23  1.23  1000   "

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 *JKG TODO: explain formatting strings and rules
 */
template<class char_type>
template<typename T1, typename T2, typename T3>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::append_formatted(const T1& val1,
                                                const T2& val2,
                                                const T3& val3,
                                                const base_string_type& format)
{
  boost::format f(format);
  string_stream_type ss;
  ss << f % val1 % val2 % val3;
  *this += ss.str();
  return *this;
}


/* Generic function to append 4 values of any to the string including formatting
 *
@code

    super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s.append_formatted(dbl, i , dbl, i, "%-7.2f %-7d %-7.2f %-7d");
    //s == "1.12   1000  1.12   1000   "

@endcode
 *
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
 *
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::append_formatted(const T1& val1,
                                                const T2& val2,
                                                const T3& val3,
                                                const T4& val4,
                                                const base_string_type& format)
{
  boost::format f(format);
  string_stream_type ss;
  ss << f % val1 % val2 % val3 % val4;
  *this += ss.str();
  return *this;
}

/** Generic function to append 5 values of any to the string including formatting
 * Users can append up to 5 values at once.  
 * See: 
 <a href="http://www.boost.org/libs/format/doc/format.html#printf_directives">Boost Format specification syntax</a> 
   for details on the formmatting strings.
 
@code

    super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s.append_formatted(dbl, i , dbl, i, "a string", "%-7.2f %-7d %-7.2f %-7d %s");
    //s == "1.12   1000  1.12   1000   a string"
    
    //other overloadings available with less parameters
    super_string s1;
    s1.append_formatted(dbl, "This is the value: %-7.2f");
    //s1 == "This is the value: 1.12"
    
@endcode
 
 *@value - The value to append to the end of the string.
 *@format - Formatting string for the value.
 *@return Returns self-reference for chained operations
  @throw Boost format exceptions: see <a href="http://www.boost.org/libs/format/doc/format.html#exceptions">Boost Format Exceptions.</a> for details.
 */
template<class char_type>
template<typename T1, typename T2, typename T3, typename T4, typename T5>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::append_formatted(const T1& val1,
                                                const T2& val2,
                                                const T3& val3,
                                                const T4& val4,
                                                const T5& val5,
                                                const base_string_type& format)
{
  boost::format f(format);
  string_stream_type ss;
  ss << f % val1 % val2 % val3 % val4 % val5;
  *this += ss.str();
  return *this;
}


/** Generic function to prepend any type to the string
 *  This function will work with any type that is OutputStreamable.

@code

    super_string s( "Hello There");
    double dbl = 1.543;
    s.prepend(dbl);
    //s == "1.543 Hello There"

@endcode

 *@return Returns self-reference for chained operations
 *
 */
template<class char_type>
template<class T>
inline
basic_super_string<char_type>&  
basic_super_string<char_type>::prepend(const T& value)
{
  string_stream_type ss;
  ss << value;
  this->insert(0, ss.str());
  return *this;
}

/** Generic function to insert an OutputStreamable type into the string.
 *  
 @code

    super_string s( "Hello  There");
    double dbl = 1.543;
    s.insert_at(6, dbl);
    //s == "Hello 1.543 There"

 @endcode
 *@param position Zero-based index of location in string to insert data
 *@param value Value to insert into the string
 *@return Returns self-reference for chained operations
 */
template<class char_type>
template<class T>
inline
basic_super_string<char_type>& 
basic_super_string<char_type>::insert_at(size_type position, const T& value)
{
  string_stream_type ss;
  ss << value;
  this->insert(position, ss.str());
  return *this;
}



/** Trim in-place whitespace from the both sides of the string.
 * 
 @code

    super_string s( " \t  hello world  ");
    s.trim();
    //s == "hello world"

 @endcode
 *
 *@return Returns self-reference for chained operations
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::trim()
{
  boost::algorithm::trim(*this);
  return *this;
}




/** Trim in-place whitespace from the left side of the string.
 * 
 *@return Returns self-reference for chained operations
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::trim_left()
{
  boost::algorithm::trim_left(*this);
  return *this;
}



/** Trim in-place whitespace from the right side of the string.
 * 
 *
 *@return Returns self-reference for chained operations
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::trim_right()
{
  boost::algorithm::trim_right(*this);
  return *this;
}



/** Change to upper case using the global locale
 * The global local can be replaced by calling 
 * std::global(locale)
 * 
 @code

    super_string s("lower");
    s.to_upper();
    check("to upper test", s == std::string("LOWER"));

 @endcode

 *@return Returns self-reference for chained operations
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::to_upper()
{
  boost::algorithm::to_upper(*this);
  return *this;
}


/** Change to lower case using the global locale
 * The global local can be replaced by calling 
 * std::global(locale)
 *
 @code 
    super_string s("UPPsdf sdf sdf E sdf d 123&88))");
    s.to_lower();
    //s == "uppsdf sdf sdf e sdf d 123&88

 @endcode
 *@return Returns self-reference for chained operations
 */
template<class char_type>
inline
basic_super_string<char_type>&
basic_super_string<char_type>::to_lower()
{
  boost::algorithm::to_lower(*this);
  return *this;
}


/** Narrow character variation of super super string */
typedef basic_super_string<char>    super_string;

/** Wide character variation of super super string */
typedef basic_super_string<wchar_t> wsuper_string;


#endif
