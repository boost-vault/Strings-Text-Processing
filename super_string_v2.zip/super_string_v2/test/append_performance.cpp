

#include "super_string/super_string.hpp"
#include "datetime_timer.hpp"
#include <iostream>

const int iterations = 100000*8;
const int trials = 10;
std::string es_result;
std::string es_result_2_parms;
std::string tmp_result;
std::string tmp_result_2_parms;

void do_append_test_external_stream()
{

  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "external append test: " << j;

    
    super_string s("A string to append to the end of:  ");
    s.reserve(17600100);
    
    double d = 1.1234567;
    const char* const as = " another string";
    std::ostringstream ss;

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      s.append(d, ss).append(as,ss);
    }
    mt.pause();
//    std::cout << " len: " << s.length() << std::endl;
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
    es_result = s;
  }
  std::cout << "external stream append test --> " 
            << iterations*trials << " iterations " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_append_test_temp_stream()
{

  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "temp stream append test: " << j;

    
    super_string s("A string to append to the end of:  ");
    s.reserve(17600100);
    
    double d = 1.1234567;
    const char* const as = " another string";

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      s.append(d).append(as);
    }
    mt.pause();
//     std::cout << " len: " << s.length() << std::endl;
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
    tmp_result = s;
  }
  std::cout << "temp stream append test --> " 
            << iterations*trials << " iterations " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;


}

void do_append_test_external_stream_2_parms()
{

  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "external stream 2 parms append test: " << j;

    
    super_string s("A string to append to the end of:  ");
    s.reserve(17600100);
    
    double d = 1.1234567;
    const char* const as = " another string";
    std::ostringstream ss;

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      s.append(d, as, ss);
    }
    mt.pause();
//    std::cout << " len: " << s.length() << std::endl;
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
    es_result_2_parms = s;
  }
  std::cout << "external stream 2 parms append test --> " 
            << iterations*trials << " iterations " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_append_test_temp_stream_2_parms()
{

  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "temp stream 2 parms append test: " << j;

    
    super_string s("A string to append to the end of:  ");
    s.reserve(17600100);
    
    double d = 1.1234567;
    const char* const as = " another string";

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      s.append(d,as);
    }
    mt.pause();
//     std::cout << " len: " << s.length() << std::endl;
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
    tmp_result_2_parms = s;
  }
  std::cout << "temp stream 2 parms append test --> " 
            << iterations*trials << " iterations " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;


}


int
main()
{

  do_append_test_external_stream();
  do_append_test_external_stream_2_parms();
  do_append_test_temp_stream();
  do_append_test_temp_stream_2_parms();
  
  if (!(es_result == tmp_result)) {
    exit(1);
  }
  
  return 0;
}
