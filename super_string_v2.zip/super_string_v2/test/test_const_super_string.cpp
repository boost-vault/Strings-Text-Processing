

#include <iostream>
#include "super_string/const_super_string.hpp"
#include "boost/date_time/gregorian/gregorian.hpp"
#include "unit_test/testfrmwk.hpp"
//#include "boost/format.hpp"





using std::string;
using std::cout;
using std::endl;
using boost::format;

void test_convert(std::string s)
{
  check("test convert", true);
  std::cout << s << std::endl;
}
 

int
main()
{

  {
    boost::const_string<char> cs("hello world");
    const_super_string css(cs);
    check("const string conversion", css == "hello world");      
    std::string ss("hello world again");
    const_super_string css2(ss);
    check("const string conversion", css2 == "hello world again");      

    boost::const_string<char> bcs2 
      = boost::const_string<char>("this is a string that is assigned");
    check("const string conversion", 
          bcs2 == "this is a string that is assigned");      

    const_super_string css3 = const_super_string("assign test");
    
    cout << cs << std::endl;

  }

  {
    const_super_string s1, s2;
    s1 = s1.append_file("test1.txt").append("\n").append_file("test2.txt");
    s2 = s2.append_file("test3.txt");
    
    std::cout << "***************************************" << std::endl;
    std::cout << s1 << std::endl;
    std::cout << "***************************************" << std::endl;
    std::cout << s2 << std::endl;
    std::cout << "***************************************" << std::endl;
    check("load from file", s1 == s2);      

  }
  //*************************************************************
  //Formmatted append using boost.format
  {
    int i = 100;
    format f("%=7d");
    std::cout << "|" << f % i << "|" << std::endl;

    double d = 1.123456789;
    format f1("%-7.2f");
    std::cout << "|" << f1 % d << "|" << std::endl;
    
    int j = 255;
    format f2("%-3x");
    std::cout << "|" << f2 % j << "|" << std::endl;
    
    const_super_string s("**");
    s = s.append_formatted(d, "%=7.2f").append("**").append_formatted(j, "%_4x").append("**").to_upper();
    std::cout << s << std::endl;

    const_super_string s2;
    s2 = s2.append_formatted(d, j, "%=6.2f -**- %_3x").to_upper();
    check("append formatted 2 parms",s2 == std::string(" 1.12  -**-  FF"));
    std::cout << s2 << std::endl; 

    const_super_string s3;
    s3 = s3.append_formatted("hello there", "--- %s ---");
    check("append formatted 2 parms",s3 == std::string("--- hello there ---"));
//     std::cout << s3 << std::endl; 

  }
  { //3 parm overload
    const_super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s = s.append_formatted(dbl, dbl, i , "|%-7.2f| %-7.2f| %-7d|");
    check("append formatted 3 parms", 
          s == std::string("|1.12   | 1.12   | 1000   |"));
  }

  { //4 parm overload
    const_super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s = s.append_formatted(dbl, i, dbl, i , "|%-7.2f|%-7d|%-7.2f|%-7d|\n");
    s = s.append_formatted(i, dbl, i, dbl , "|%=7d|%=7.4f|%=7d|%=7.4f|\n");
    std::cout << s << std::endl; 
    check("append formatted 4 parms",
          s == std::string("|1.12   |1000   |1.12   |1000   |\n"
                           "|  1000 | 1.1235|  1000 | 1.1235|\n"));
  }
  { //5 parm overload
    const_super_string s;
    double dbl = 1.123456789;
    int i = 1000;
    s = s.append_formatted(dbl, i, dbl, i , "stuff", 
                           "|%-7.2f|%-7d|%-7.2f|%-7d|%=10s|\n");
    s = s.append_formatted(i, dbl, i, dbl , 
                           "stuff", "|%=7d|%=7.4f|%=7d|%=7.4f|%=10S|\n");
    std::cout << s << std::endl; 
    check("append formatted 5 parms", 
          s == std::string("|1.12   |1000   |1.12   |1000   |   stuff  |\n"
                           "|  1000 | 1.1235|  1000 | 1.1235|   stuff  |\n"));
  }
  {
    const_super_string s("(abc)3333()(456789) [123] (1) (cde)");
    
    //replace parens around digits with #--the digits--#
    s = s.replace_all_regex("\\(([0-9]+)\\)", "#--$1--#");

    check("replace_all_regex",
          s == std::string("(abc)3333()#--456789--# [123] #--1--# (cde)") );      
 
 }
  //*************************************************************
  //Split tests
  {

    const_super_string s("These   are   some    \t words--with whitespace");
    const_super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+|--", out_vec);
  
    check("split_regex succeeded", out_vec.size() == 6);      
    check("split_regex succeeded", out_vec[0] == "These");      
    check("split_regex succeeded", out_vec[4] == "with");      
    
    std::cout << "There were " << count << " tokens found." << std::endl;
  }

  {

    const_super_string s1("2006-10-01");
    const_super_string s2("2006/10/01");
    const_super_string s3("2006.10.01");

    const_super_string::string_vector out_vec;
    std::string re("[-/.]"); //split on - or / or .
    unsigned int count = s1.split_regex(re, out_vec);
    check("split_regex succeeded", out_vec.size() == 3);      
    check("split_regex succeeded", out_vec[0] == "2006");      
    check("split_regex succeeded", out_vec[1] == "10");      
    check("split_regex succeeded", out_vec[2] == "01");      

    out_vec.clear();
    count = s2.split_regex(re, out_vec);
    check("split_regex succeeded", out_vec.size() == 3);      
    check("split_regex succeeded", out_vec[0] == "2006");      
    check("split_regex succeeded", out_vec[1] == "10");      
    check("split_regex succeeded", out_vec[2] == "01");      

    out_vec.clear();
    count = s3.split_regex(re, out_vec);
    check("split_regex succeeded", out_vec.size() == 3);      
    check("split_regex succeeded", out_vec[0] == "2006");      
    check("split_regex succeeded", out_vec[1] == "10");      
    check("split_regex succeeded", out_vec[2] == "01");      

    std::cout << "There were " << count << " tokens found." << std::endl;
      
  }


  {
    const_super_string stuff("first-|-second-|-third");
    const_super_string::string_vector out_vec;
    if (stuff.split("-|-", out_vec)) {
      check("split succeeded", out_vec.size() == 3);      
      check("split succeeded", out_vec[0] == "first");      
      check("split succeeded", out_vec[1] == "second");      
      check("split succeeded", out_vec[2] == "third");      
    }
    else {
      check("split -- none found", false);
    }
  }
  //*************************************************************
  //Case insensitive replace
  {
    const_super_string s("foo Foo FOO");
    s = s.ireplace_all("foo", "bar");
    check("replace all", s == "bar bar bar" );
  }
  {
    const_super_string s("FOO foo foo");
    s = s.ireplace_first("foo", "bar");
    check("replace first", s == "bar foo foo" );
  }
  {
    const_super_string s("foo foo FOO");
    s = s.ireplace_last("foo", "bar");
    check("replace last", s == "foo foo bar" );
  }
  {
    const_super_string s("FOO foo FoO foo");
    s = s.ireplace_nth("foo", "bar", 2);
    check("replace nth", s == "FOO foo bar foo" );
  }
  //*************************************************************
  //Replace
  {
    const_super_string s("foo foo foo");
    s = s.replace_all("foo", "bar");
    check("replace all", s == "bar bar bar" );
  }
  {
    const_super_string s("foo foo foo");
    s = s.replace_first("foo", "bar");
    check("replace first", s == "bar foo foo" );
  }
  {
    const_super_string s("foo foo foo");
    s = s.replace_last("foo", "bar");
    check("replace last", s == "foo foo bar" );
  }
  {
    const_super_string s("foo of the foo of the foo of the foo");
    s = s.replace_nth("foo", "bar", 2);
    std::cout << s << std::endl;
    check("replace nth", s == "foo of the foo of the bar of the foo" );
  }
  //*************************************************************
  //Contains
  {
    const_super_string s("hello 2006-02-23");
    check("regex contains", s.contains_regex("\\d{4}-\\d{2}-\\d{2}"));
    check("regex contains", !s.contains_regex("[A-Z]"));
    check("regex contains", s.contains_regex("[a-z]"));
  } 
  {
    const_super_string s("hello");
    check("contains", s.contains("lo"));
    check("!contains ", !s.contains("hi"));
  }
  {
    const_super_string s("hELlo");
    check("icontains ", s.icontains("llO"));
    check("!icontains", !s.icontains("Hi"));
  }

  {
    const_super_string s("hello");
    check("ends with", s.ends_with("lo"));
    check("!ends with", !s.ends_with("hi"));
  }
  {
    const_super_string s("hELlo");
    check("iends with", s.iends_with("llO"));
    check("!iends with", !s.iends_with("Hi"));
  }

  {
    const_super_string s("hello");
    check("starts with", s.starts_with("hel"));
    check("!starts with", !s.starts_with("hi"));
    check("starts with", s.starts_with("ll", 2));
  }
  {
    const_super_string s("hELlo");
    check("istarts with", s.istarts_with("hel"));
    check("!istarts with", !s.istarts_with("Hi"));
    check("istarts with", s.istarts_with("ll", 2));
  }
  //*************************************************************
  //append, prepend, insert_at
  {
    //2 parameter variant
    const_super_string s;
    double dbl = 1.543;
    s = s.append("double: ", dbl);
    check("append string and double", s == std::string("double: 1.543"));
  }
  {
    //3 parameter variant
    const_super_string s;
    double dbl = 1.543;
    s = s.append("double: ", dbl, " blah, blah");
    check("append string and double", 
          s == std::string("double: 1.543 blah, blah"));
  }
  {
    //4 parameter variant
    const_super_string s;
    double dbl = 1.543;
    int i = 1000;
    s= s.append("double: ", dbl, " int: ", i);
    check("append string and double", 
          s == std::string("double: 1.543 int: 1000"));
  }
  {
    //5 parameter variant
    const_super_string s;
    double dbl = 1.543;
    int i = 1000;
    s = s.append("double: ", dbl, " int: ", i, " done");
    check("append string and double", 
          s == std::string("double: 1.543 int: 1000 done"));
  }
  {
    const_super_string s;
    double dbl = 1.543;
    s = s.append(dbl);
    check("append double", s == std::string("1.543"));
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s = s.append(" - "); //std::string method
    s = s.append(d);
    check("append date", s == std::string("1.543 - 2006-Jun-29"));
    
  }
  {
    const_super_string s("hello world");
    double dbl = 1.543;
    s = s.prepend(dbl);
    std::cout << s << std::endl;
    check("prepend double", s == std::string("1.543hello world"));
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s = s.prepend(d);
    check("prepend date", s == std::string("2006-Jun-291.543hello world"));
    
  }
  { 
    const_super_string s("hello  world");
    double dbl = 1.543;
    s = s.insert_at(6, dbl);
    std::cout << s << std::endl;
    check("insert_at double", s == std::string("hello 1.543 world"));
    boost::gregorian::date d(2006, boost::gregorian::Jun, 29);
    s = s.insert_at(1, d);
    check("insert_at date", s == std::string("h2006-Jun-29ello 1.543 world"));
    
  }

  //*************************************************************
  //trim

  {
    const_super_string s("   hello world ");
    //csuper_string s2("   hello world ");
    const_super_string s2 = s.trim();
    cout << s2 << endl;
    check("trim  copy", s == std::string("   hello world "));
    check("trim", s2 == std::string("hello world"));
  }

  {
    const_super_string s("   hello world ");
    const_super_string s2 = s.trim_left();
    check("trim left copy", s == std::string("   hello world "));
    check("trim left", s2 == std::string("hello world "));
  }
  {
    const_super_string s("   hello world   ");
    const_super_string s2 = s.trim_right();
    check("trim right copy", s == std::string("   hello world   "));
    check("trim right", s2 == std::string("   hello world"));
  }

//   {
//     super_string s("convert test, dude");
//     test_convert(s);
//   }

  //*************************************************************
  //case conversion

  {
    const_super_string s("lower");
    const_super_string s2 = s.to_upper();
    check("to upper copy test", s2 == std::string("LOWER"));
  }
  {
    const_super_string s("UPPsdf sdf sdf E sdf d 123&88))");
    const_super_string s2 = s.to_lower();
    check("to lower test", 
          s2 == std::string("uppsdf sdf sdf e sdf d 123&88))"));
  }
  

  //*************************************************************
  //wide string tests
  {
    wconst_super_string s(L"   hello world ");
    s = s.trim_left();
    check("trim left", s == std::wstring(L"hello world "));
  }


  return printTestStats();
}
