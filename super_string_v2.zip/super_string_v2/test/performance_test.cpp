

#include "super_string/const_super_string.hpp"
#include "super_string/super_string.hpp"
#include "datetime_timer.hpp"
#include <iostream>

const int iterations = 100000;
const int trials = 10;

void do_split_regex_test_mutable()
{
  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "mutable split regex test: " << j;

    super_string s("These   are   some    \t words--with whitespace");

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      super_string::string_vector out_vec;
      unsigned int count = s.split_regex("\\s+|--", out_vec);
    }
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "mutable split regex test --> " 
            << trials << " trials "
            << iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_split_regex_test_const()
{

  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "const split regex test: " << j;

    const_super_string s("These   are   some    \t words--with whitespace");

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      const_super_string::string_vector out_vec;
      unsigned int count = s.split_regex("\\s+|--", out_vec);
    }
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "const split regex test --> " 
            << trials << " trials "
            << iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}


void do_contains_regex_test_mutable()
{
  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "mutable contains regex test: " << j;

    super_string s1("asd fsd s df sd s 2006-02-23 sad sdf"
                    "hello adf sf    fasdfsdfsdfs");
    super_string s2("asd fsd s df sd s adf sf    sad sdf"
                    "hello no digits in this one");
    
    bool contains1 =  false;
    bool contains2 =  true;

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      contains1 =  s1.contains_regex("\\d{4}-\\d{2}-\\d{2}");
      contains2 =  s2.contains_regex("\\d{4}-\\d{2}-\\d{2}");
    }
//     std::cout << " c1 " << contains1 
//               << " c2 " << contains2 
//               << std::endl;
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "mutable contains regex test --> " 
            << trials << " trials "
            << iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_contains_regex_test_const()
{

  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << iterations 
              << " iterations of "
              << "const contains regex test: " << j;

    const_super_string s1("asd fsd s df sd s 2006-02-23 sad sdf"
                          "hello adf sf    fasdfsdfsdfs");
    const_super_string s2("asd fsd s df sd s adf sf    sad sdf"
                    "hello no digits in this one");

    bool contains1 =  false;
    bool contains2 =  true;

    micro_timer mt;
    for (int i=0; i < iterations; ++i) {
      contains1 =  s1.contains_regex("\\d{4}-\\d{2}-\\d{2}");
      contains2 =  s2.contains_regex("\\d{4}-\\d{2}-\\d{2}");
    }
//     std::cout << " c1 " << contains1 
//               << " c2 " << contains2 
//               << std::endl;
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "const contains regex test --> " 
            << trials << " trials "
            << iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_trim_test_mutable()
{

  int adjusted_iterations = iterations*10;
  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << adjusted_iterations 
              << " iterations of "
              << "mutable trim  test: " << j;

    std::vector<super_string> ssv1;
    std::vector<super_string> ssv2;
    for (int i=0; i < adjusted_iterations; ++i) {
      super_string s1("    A string with some whitespace to trim      ");
      ssv1.push_back(s1);
      super_string s2("A string with no whitespace to trim");
      ssv2.push_back(s2);

    }
//     std::cout << "\n" << ssv1[1] << "\n" << ssv2[1] << std::endl;

    micro_timer mt;
    for (int i=0; i < adjusted_iterations; ++i) {
      ssv1[i].trim_right();
      ssv1[i].trim_left();
      ssv2[i].trim_right();
      ssv2[i].trim_left();
    }
//     std::cout << ssv1[1] << "\n" << ssv2[1] << std::endl;
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "mutable trim test --> " 
            << trials << " trials "
            << adjusted_iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_trim_test_const()
{

  int adjusted_iterations = iterations*10;
  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << adjusted_iterations
              << " iterations of "
              << "const trim test: " << j;

    std::vector<const_super_string> ssv1;
    std::vector<const_super_string> ssv2;
    for (int i=0; i < adjusted_iterations; ++i) {
      const_super_string s1("    A string with some whitespace to trim      ");
      ssv1.push_back(s1);
      const_super_string s2("A string with no whitespace to trim");
      ssv2.push_back(s2);

    }
//     std::cout << "\n" << ssv1[1] << "\n" << ssv2[1] << std::endl;

    micro_timer mt;
    for (int i=0; i < adjusted_iterations; ++i) {
      ssv1[i] = ssv1[i].trim_right();
      ssv1[i] = ssv1[i].trim_left();
      ssv2[i] = ssv2[i].trim_right();
      ssv2[i] = ssv2[i].trim_left();
    }
//     std::cout << ssv1[1] << "\n" << ssv2[1] << std::endl;
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "const trim test --> " 
            << trials << " trials "
            << adjusted_iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;


}


void do_append_test_mutable()
{

  int adjusted_iterations = 5*iterations;
  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << adjusted_iterations 
              << " iterations of "
              << "mutable append test: " << j;

    std::vector<super_string> ssv1;
    std::vector<super_string> ssv2;
    std::vector<super_string> ssv3;
    for (int i=0; i < adjusted_iterations; ++i) {
      super_string s("A string to append to the end of:  ");
      ssv1.push_back(s);
      ssv2.push_back(s);
      ssv3.push_back(s);
    }
//     std::cout << "\n" << ssv1[1] << "\n" << ssv2[1] << std::endl;
    
    double d = 1.1234567;
    const char* const s = " another string";
    
    micro_timer mt;
    for (int i=0; i < adjusted_iterations; ++i) {
      ssv1[i].append(d);
      ssv2[i].append(i);
      ssv3[i].append(s);
    }
//     std::cout << ssv1[1] << "\n" 
//               << ssv2[1] << "\n" 
//               << ssv3[1] << std::endl;
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "mutable append test --> " 
            << trials << " trials "
            << adjusted_iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;

}

void do_append_test_const()
{

  int adjusted_iterations = 5*iterations;
  time_duration total_elapsed(0,0,0);
  for (int j=0; j<trials; ++j) {
    std::cout << adjusted_iterations 
              << " iterations of "
              << "const append test: " << j;

    std::vector<const_super_string> ssv1;
    std::vector<const_super_string> ssv2;
    std::vector<const_super_string> ssv3;
    for (int i=0; i < adjusted_iterations; ++i) {
      const_super_string s("A string to append to the end of:  ");
      ssv1.push_back(s);
      ssv2.push_back(s);
      ssv3.push_back(s);
    }
//     std::cout << "\n" << ssv1[1] << "\n" << ssv2[1] << std::endl;
    
    double d = 1.1234567;
    const char* const s = " another string";
    
    micro_timer mt;
    for (int i=0; i < adjusted_iterations; ++i) {
      ssv1[i] = ssv1[i].append(d);
      ssv2[i] = ssv2[i].append(i);
      ssv3[i] = ssv3[i].append(s);
    } 
//     std::cout << ssv1[1] << "\n" 
//               << ssv2[1] << "\n" 
//               << ssv3[1] << std::endl;
    mt.pause();
    std::cout << " --> " << mt.elapsed() << std::endl;
    total_elapsed += mt.elapsed();
  }
  std::cout << "const append test --> " 
            << trials << " trials "
            << adjusted_iterations << " iterations/trial " 
            << " total elapsed: " 
            << total_elapsed
            << std::endl;


}


int
main()
{

  do_append_test_const();
  do_append_test_mutable();
  do_trim_test_const();
  do_trim_test_mutable();
  do_contains_regex_test_const();
  do_contains_regex_test_mutable();
  do_split_regex_test_const();
  do_split_regex_test_mutable();
  
  
  return 0;
}
