/* Expected ouptput:
    (456789) [123]  2006-10-01    ABCDEF   
(456789) [123]  2006-10-01    ABCDEF
(456789) [123]  2006-10-01    ABCDEF1.23456
__[456789]__ [123]  2006-10-01    ABCDEF1.23456
0  __[456789]__
1  [123]
2  2006-10-01
3  ABCDEF1.23456
   hello world 
*/

#include "super_string/const_super_string.hpp"
#include <iostream>
 
using std::string;
using std::cout;
using std::wcout;
using std::endl;


int
main()
{

  //const_super_string is immutable
  const_super_string s("    (456789) [123]  2006-10-01    abcdef   ");
  s = s.to_upper(); //"    (456789) [123]  2006-10-01    ABCDEF   "
  cout << s << endl;
  
  s = s.trim();  //"(456789) [123]  2006-10-01    ABCDEF"
  cout << s << endl;
  
  double dbl = 1.23456;
  s = s.append(dbl);  //"(456789) [123]  2006-10-01    ABCDEF1.23456"
  cout << s << endl;
  
  //find the yyyy-mm-dd date format
  if (s.contains_regex("\\d{4}-\\d{2}-\\d{2}")) {
    //replace parens around digits with square brackets [the digits]
    s = s.replace_all_regex("\\(([0-9]+)\\)", "__[$1]__");
    cout << s << endl;
    
    
    //split the string on white space to process parts
    const_super_string::string_vector out_vec;
    unsigned int count = s.split_regex("\\s+", out_vec);
    if (count) {
      for(int i=0; i < out_vec.size(); ++i) {
        out_vec[i].replace_first("__","");  //get rid of first __ in string
        cout << i << "  " << out_vec[i] << endl;
      }
    }
  }
  
  //wide strings too...
  wconst_super_string ws(L"   hello world ");
  ws.trim_left();
  wcout << ws << endl;
  
  return 0;

}
