//Purpose:
//  prototype of calculation of grammar lookahead sets (e.g. first, follow).
//Status:2006-12-09
//  Not working.  Can't figure how to pass empty graph to first calculations.
//  Also, empty graph not calculated completely yet.
#include <boost/mpl/at.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/transform.hpp>
#include <boost/mpl/range_c.hpp>
#include <boost/mpl/arg.hpp>
#include <boost/mpl/back_inserter.hpp>
#include <boost/mpl/map.hpp>
#include <boost/mpl/is_sequence.hpp>
#include <boost/mpl/equal.hpp>
#include <boost/type_traits/is_same.hpp>
            
#include "boost/grammar_pipeline/grammar_n_ary_expr_gen.hpp"

//{alg_exprs<alg_empty>

//{arity=0
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
      struct
alg_exprs
  < alg_empty
  >
::
    arity
      < 0//Arity
      >
    {
          enum
        numerals
        { unknown_empty
        , out_empty
        , allknown_empty
        };
          template
          < numerals Ar0Num
          >
          struct
        arity0_map
        ;

    };
    
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
          template
          <// numerals Ar0Num
          >
          struct
alg_exprs
  < alg_empty
  >
::
    arity
      < 0//Arity
      >
    ::
        arity0_map
          < alg_exprs
              < alg_empty
              >
            ::
            arity
              < 0
              >
            ::
            unknown_empty
          >
        {
              struct
            expr
            {
                  template
                  < class OutEmptySeq
                  >
                  struct
                apply
                {
                        typedef
                      expr
                    type
                    ;
                };
                    typedef
                  expr
                value_empty
                ;
            };
        };
    
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
          template
          <// numerals Ar0Num
          >
          struct
alg_exprs
  < alg_empty
  >
::
    arity
      < 0//Arity
      >
    ::
        arity0_map
          < alg_exprs
              < alg_empty
              >
            ::
            arity
              < 0
              >
            ::
            out_empty
          >
        {
              template
              < class OutputEnum
              >
              struct
            arity0_kind
            {
                    typedef
                  typename OutputEnum::numerals 
                numerals
                ;
                  template
                  < numerals Oper
                  >
                  struct
                expr
                {
                      template
                      < class OutEmptySeq
                      >
                      struct
                    apply
                    : boost::mpl::at_c<OutEmptySeq,Oper>
                    {
                    };
                    
                        typedef typename
                        alg_exprs<alg_empty>
                      ::arity<0>
                      ::arity0_map
                        <   alg_exprs<alg_empty>
                          ::arity<0>
                          ::unknown_empty
                        >
                      ::expr
                    value_empty
                    ;
                };
            };
        };
    
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
          template
          <// numerals Ar0Num
          >
          struct
alg_exprs
  < alg_empty
  >
::
    arity
      < 0//Arity
      >
    ::
        arity0_map
          < alg_exprs
              < alg_empty
              >
            ::
            arity
              < 0
              >
            ::
            allknown_empty
          >
        {
                typedef
              bool
            numerals
            ;
              template
              < numerals Oper
              >
              struct
            expr
            {
                  template
                  < class OutEmptySeq
                  >
                  struct
                apply
                {
                        typedef
                      expr<Oper>
                    type
                    ;
                };
                    typedef
                  expr<Oper>
                value_empty
                ;
            };
                
        };
    
//}arity=0
//{arity=2
  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
      struct
alg_exprs
  < alg_empty
  >
::
    arity
      < 2//Arity
      >
    {
          enum
        numerals
        { empty_all //morph from gram_seq
        , empty_any //morph from gram_alt
        };
        
            typedef
          alg_exprs<alg_empty>
          ::
          arity<0>
          ::
          arity0_map
          < alg_exprs<alg_empty>
            ::
            arity<0>
            ::
            unknown_empty
          >
          ::expr
        default_value_empty
        ;
          template
          < numerals Oper
          , class ValueEmpty0
          , class ValueEmpty1
          >
          struct
        reduce
        {
                typedef
              default_value_empty
            type
            ;
        };
          template
          < numerals Oper
          , class Expr0
          , class Expr1
          , class ValueEmpty=default_value_empty
          >
          struct
        expr
        {
              template
              < class OutEmptySeq
              >
              struct
            apply
            {
                    typedef
                  typename Expr0::template apply<OutEmptySeq>::type
                applied_0
                ;
                    typedef
                  typename Expr1::template apply<OutEmptySeq>::type
                applied_1
                ;
                    typedef typename
                  reduce
                  < Oper
                  , typename applied_0::value_empty
                  , typename applied_1::value_empty
                  >::type
                value_empty
                ;
                    typedef
                  expr
                  < Oper
                  , applied_0
                  , applied_1
                  , value_empty
                  >
                type
                ;
            };
                typedef
              ValueEmpty
            value_empty
            ;
        };
    };

  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
          template
          <//numerals Oper
            ::alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::numerals 
            KnownEmpty0
          , ::alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::numerals 
            KnownEmpty1
          >
          struct //reduce
alg_exprs
  < alg_empty
  >
::
    arity
      < 2//Arity
      >
    ::
        reduce
          <   alg_exprs<alg_empty>
            ::arity<2>
            ::empty_all
          ,   alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              <   alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::expr
              < KnownEmpty0
              >
          ,   alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              <   alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::expr
              < KnownEmpty1
              >
          >
        {
               typedef
                alg_exprs<alg_empty>
              ::arity<0>
              ::arity0_map
                <   alg_exprs<alg_empty>
                  ::arity<0>
                  ::allknown_empty
                >
              ::expr
                <  KnownEmpty0 
                && KnownEmpty1
                >
                //gram_seq derives empty string if each element derives empty string.
            type
            ;
              
        };
        
  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
          template
          <//numerals Oper
            ::alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::numerals 
            KnownEmpty0
          , ::alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::numerals 
            KnownEmpty1
          >
          struct //reduce
alg_exprs
  < alg_empty
  >
::
    arity
      < 2//Arity
      >
    ::
        reduce
          <   alg_exprs<alg_empty>
            ::arity<2>
            ::empty_any
          ,   alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              <   alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::expr
              < KnownEmpty0
              >
          ,   alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              <   alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::expr
              < KnownEmpty1
              >
          >
        {
               typedef
                alg_exprs<alg_empty>
              ::arity<0>
              ::arity0_map
                <   alg_exprs<alg_empty>
                  ::arity<0>
                  ::allknown_empty
                >
              ::expr
                <  KnownEmpty0 
                || KnownEmpty1
                >
                //gram_alt derives empty string if any element derives empty string.
            type
            ;
              
        };
        
//}arity=2

//}alg_exprs<alg_empty>

//{morph_empty
//{morph_empty-primitives
  template
  < class TargDeduceHelper
  >
  struct
morph_prim_empty
;
  template
  < class Enumeration
  >
  struct
morph_prim_empty
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
      <   alg_exprs<alg_grammar>
        ::arity<0>
        ::special
      , Enumeration
      , Enumeration::epsilon
      >
  >
{
        typedef typename
        alg_exprs<alg_empty>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_empty>
          ::arity<0>
          ::allknown_empty
        >
      ::expr<true> //epsilon only derives empty string.
    type
    ;
};

  template
  < class Enumeration
  , typename Enumeration::numerals Number
  >
  struct
morph_prim_empty
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
    <   alg_exprs<alg_grammar>
      ::arity<0>
      ::action
    , Enumeration
    , Number
    >
  >
{
        typedef typename
        alg_exprs<alg_empty>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_empty>
          ::arity<0>
          ::allknown_empty
        >
      ::expr<true> //any action  symbol derives empty string
    type
    ;
};

  template
  < class Enumeration
  , typename Enumeration::numerals Number
  >
  struct
morph_prim_empty
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
    <   alg_exprs<alg_grammar>
      ::arity<0>
      ::input
    , Enumeration
    , Number
    >
  >
{
        typedef typename
        alg_exprs<alg_empty>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_empty>
          ::arity<0>
          ::allknown_empty
        >
      ::expr<false> //any input symbol cannot derive empty string
    type
    ;
};

  template
  < class Enumeration
  , typename Enumeration::numerals Number
  >
  struct
morph_prim_empty
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
    <   alg_exprs<alg_grammar>
      ::arity<0>
      ::output
    , Enumeration
    , Number
    >
  >
{
        typedef typename
        alg_exprs<alg_empty>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_empty>
          ::arity<0>
          ::out_empty
        >
      ::arity0_kind
        < Enumeration
        >
      ::template expr<Number>
    type
    ;
};

  template
  < class GramExpr
  >
  struct
morph_empty
  : morph_prim_empty
    < typename GramExpr::our_targ_deduce
    >
{};

//}morph_empty-primitives

//{morph_empty-composites
  template
  < class Expr0
  , class Expr1
  >
  struct
morph_empty
  < alg_exprs
      < alg_grammar
      >
    ::
    arity
      < 2
      >
    ::
    expr
      < alg_exprs
          < alg_grammar
          >
        ::
        arity
          < 2
          >
        ::gram_seq
      , Expr0
      , Expr1
      >

  >
{
        typedef
      alg_exprs
        < alg_empty
        >
      ::
      arity
        < 2
        >
      ::
      expr
        < alg_exprs
            < alg_empty
            >
          ::
          arity
            < 2
            >
          ::
          empty_all
        , typename morph_empty
          < Expr0
          >::type
        , typename morph_empty
          < Expr1
          >::type
        >
    type
    ;
};

//}morph_empty-composites
//}morph_empty

//{alg_exprs<alg_first>

//{arity=0
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
      struct
alg_exprs
  < alg_first
  >
::
    arity
      < 0//Arity
      >
    {
          enum
        numerals
        { unknown_first
        , out_first
        , allknown_first
        };
          template
          < numerals Ar0Num
          >
          struct
        arity0_map
        ;

    };
    
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
          template
          <// numerals Ar0Num
          >
          struct
alg_exprs
  < alg_first
  >
::
    arity
      < 0//Arity
      >
    ::
        arity0_map
          < alg_exprs
              < alg_first
              >
            ::
            arity
              < 0
              >
            ::
            unknown_first
          >
        {
              template
              < class ValueEmpty
              >
              struct
            expr
            {
                    typedef
                  ValueEmpty
                value_empty
                ;
                  template
                  < class OutEmptySeq
                  >
                  struct
                apply
                {
                        typedef
                      expr
                    type
                    ;
                };
                    typedef
                  expr
                value_first
                ;
            };
        };
    
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
          template
          <// numerals Ar0Num
          >
          struct
alg_exprs
  < alg_first
  >
::
    arity
      < 0//Arity
      >
    ::
        arity0_map
          < alg_exprs
              < alg_first
              >
            ::
            arity
              < 0
              >
            ::
            out_first
          >
        {
              template
              < class OutputEnum
              >
              struct
            arity0_kind
            {
                    typedef
                  typename OutputEnum::numerals 
                numerals
                ;
                  template
                  < numerals Oper
                  , class ValueEmpty
                  >
                  struct
                expr
                {
                      template
                      < class OutFirstSeq
                      >
                      struct
                    apply
                    : boost::mpl::at_c<OutFirstSeq,Oper>
                    {
                    };
                        typedef
                      ValueEmpty
                    value_empty
                    ;
                        typedef typename
                        alg_exprs<alg_first>
                      ::arity<0>
                      ::arity0_map
                        <   alg_exprs<alg_first>
                          ::arity<0>
                          ::unknown_first
                        >
                      ::expr
                        < ValueEmpty
                        >
                    value_first
                    ;
                };
            };
        };
    
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
          template
          <// numerals Ar0Num
          >
          struct
alg_exprs
  < alg_first
  >
::
    arity
      < 0//Arity
      >
    ::
        arity0_map
          < alg_exprs
              < alg_first
              >
            ::
            arity
              < 0
              >
            ::
            allknown_first
          >
        {
              template
              < class InputSet //set of numerals
              , class ValueEmpty
              >
              struct
            expr
            : InputSet
            {
                    typedef
                  ValueEmpty
                value_empty
                ;
                  template
                  < class OutFirstSeq
                  >
                  struct
                apply
                {
                        typedef
                      expr
                    type
                    ;
                };
                    typedef
                  expr
                value_first
                ;
            };

        };
    
//}arity=0
//{arity=2
  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
      struct
alg_exprs
  < alg_first
  >
::
    arity
      < 2//Arity
      >
    {
          enum
        numerals
        { first_non_empty //morph from empty_all
          //first of gram_seq is first of first non-empty element
          //unioned with first of all preceding elements.
        , first_union     //morph from empty_any
          //first of gram_alt is union of first of all elements.
        };
            typedef
          alg_exprs<alg_first>
          ::
          arity<0>
          ::
          arity0_map
          < alg_exprs<alg_first>
            ::
            arity<0>
            ::
            unknown_first
          >
          ::expr
          <   alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
            <   alg_exprs<alg_empty>
              ::arity<0>
              ::allknown_empty
            >
            ::expr
            < true
            >
          >
        default_value_first
        ;
          template
          < numerals Oper
          , class ValueFirst0
          , class ValueFirst1
          >
          struct
        reduce
        ;
          template
          < numerals Oper
          , class Expr0
          , class Expr1
          , class ValueEmpty
          , class ValueFirst
          >
          struct
        expr
        {
                typedef
              ValueFirst
            value_first
            ;
                typedef
              expr
            self_type
            ;
              template
              < class OutFirstSeq
              >
              struct
            apply
            {
                    typedef
                  typename Expr0::template apply<OutFirstSeq>::type
                applied_0
                ;
                    typedef
                  typename Expr1::template apply<OutFirstSeq>::type
                applied_1
                ;
                    typedef
                  reduce
                  < Oper
                  , typename applied_0::value_first
                  , typename applied_1::value_first
                  >
                value_first
                ;
                    typedef
                  expr
                  < Oper
                  , applied_0
                  , applied_1
                  , ValueEmpty
                  , value_first
                  >
                type
                ;
            };
        };
    };

#if 0
  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
          template
          <//numerals Oper
            ::alg_exprs<alg_empty>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_empty>
                ::arity<0>
                ::allknown_empty
              >
            ::numerals KnownEmpty0
            ::alg_exprs<alg_first>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_first>
                ::arity<0>
                ::allknown_first
              >
            ::??? KnownFirst0
          , ::alg_exprs<alg_first>
            ::arity<0>
            ::arity0_map
              < ::alg_exprs<alg_first>
                ::arity<0>
                ::allknown_first
              >
            ::numerals KnownEmpty1
          >
          struct //reduce
alg_exprs
  < alg_first
  >
::
    arity
      < 2//Arity
      >
    ::
        reduce
          <   alg_exprs<alg_first>
            ::arity<2>
            ::first_non_empty
          ,   alg_exprs<alg_first>
            ::arity<0>
            ::arity0_map
              <   alg_exprs<alg_first>
                ::arity<0>
                ::allknown_first
              >
            ::arity0_kind
            ::expr<FirstKnown0>
          ,   alg_exprs<alg_first>
            ::arity<0>
            ::arity0_map
              <   alg_exprs<alg_first>
                ::arity<0>
                ::allknown_first
              >
            ::arity0_kind
            ::expr<FirstKnown1>
          >
        {
                typedef
                 alg_exprs<alg_first>
               ::arity<0>
               ::arity0_map
                 <   alg_exprs<alg_first>
                   ::arity<0>
                   ::allknown_first
                 >
               ::arity0_kind
               ::expr
                 <  FirstKnown0 
                 ?? FirstKnown1
                 >
             type
            ;
        };
        
#endif
//}arity=2
//}alg_exprs<alg_first>

#if 0
//{morph_first.
//{morph_first-primitives
#include <boost/mpl/set.hpp>
  template
  < class TargDeduceHelper
  >
  struct
morph_prim_first
;
  template
  < class Enumeration
  >
  struct
morph_prim_first
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
      <   alg_exprs<alg_grammar>
        ::arity<0>
        ::special
      , Enumeration
      , Enumeration::epsilon
      >
  >
{
        typedef typename
        alg_exprs<alg_first>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_first>
          ::arity<0>
          ::allknown_first
        >
      ::arity0_kind<InputEnum>
      ::template expr
        < boost::mpl::set<>
        >
    type
    ;
};

  template
  < class Enumeration
  , typename Enumeration::numerals Number
  >
  struct
morph_prim_first
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
    <   alg_exprs<alg_grammar>
      ::arity<0>
      ::input
    , Enumeration
    , Number
    >
  >
{
        typedef typename
        alg_exprs<alg_first>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_first>
          ::arity<0>
          ::allknown_first
        >
      ::arity0_kind
      ::expr
        < boost::mpl::set
          < boost::mpl::integral_c
            < typename Enumeration::numerals
            , Number
            >
          >
        > //first of any input symbol is singleton set containing only that input symbol.
    type
    ;
};

  template
  < class Numerals
  , typename Enumeration::numerals Number
  >
  struct
morph_prim_first
  <   alg_exprs<alg_grammar>
    ::arity<0>
    ::targ_deduce_helper
    <   alg_exprs<alg_grammar>
      ::arity<0>
      ::output
    , Enumeration
    , Number
    >
  >
{
        typedef typename
        alg_exprs<alg_first>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_first>
          ::arity<0>
          ::out_first
        >
      ::arity0_kind
        < Enumeration
        >
      ::template expr<Number>
    type
    ;
};

  template
  < class GramExpr
  >
  struct
morph_first
  : morph_prim_first
    < typename GramExpr::our_targ_deduce
    >
{};

//}morph_first-primitives

//{morph_first-composites
  template
  < class Expr0
  , class Expr1
  >
  struct
morph_first
  < alg_exprs
      < alg_grammar
      >
    ::
    arity
      < 2
      >
    ::
    expr
      < alg_exprs
          < alg_grammar
          >
        ::
        arity
          < 2
          >
        ::gram_seq
      , Expr0
      , Expr1
      >

  >
{
        typedef
      alg_exprs
        < alg_first
        >
      ::
      arity
        < 2
        >
      ::
      expr
        < alg_exprs
            < alg_first
            >
          ::
          arity
            < 2
            >
          ::
          empty_all
        , typename morph_first
          < Expr0
          >::type
        , typename morph_first
          < Expr1
          >::type
        >
    type
    ;
};

//}morph_first-composites
//}morph_first.
#endif

  template
  < algebra_numerals AlgNum
  , class Equations
  >
  struct
alg_equations
;

namespace detail
{
      template
      < unsigned SizeMap
      , unsigned SizeOutputs
      >
      struct
    map_size_must_be_outputs_size
    /**@brief
     *  Cause BOOST_MPL_ASSERT to generate more meaningful error message.
     */
    : boost::mpl::bool_<SizeMap==SizeOutputs>
    {};
    
      template
      < class MapDefining
      , class Outputs
      >
      struct
    map_defines_all_outputs
    {
          void
        constraints(void)
        {
           unsigned const size_map=boost::mpl::size<MapDefining>::type::value;
           unsigned const size_outputs=Outputs::size;
           BOOST_MPL_ASSERT((map_size_must_be_outputs_size<size_map,size_outputs>));
        }
        
    };
}  
  template
  < class EquationsMap
  >
  struct
alg_equations
  < alg_grammar
  , EquationsMap
  >
: EquationsMap
/**@brief
 *  Convert map form of grammar productions into vector form.
 */
{
        typedef 
      typename EquationsMap::equations
    grammar_eqs_map
    ;
        typedef
      typename EquationsMap::on
    out_type
    ;
    BOOST_CLASS_REQUIRE2(grammar_eqs_map,out_type,detail, map_defines_all_outputs);
    
        typedef
      typename out_type::numerals
    out_numerals
    ;
        typedef
      typename boost::mpl::range_c
      < out_numerals
      , out_numerals(0)
      , out_numerals(out_type::size)
      >::type
    range_out_numerals
    ;
      template
      < class MapKey
      >
      struct
    rhs
    /**@brief
     *  Return rhs of production whos lhs index==MapKey::value.
     */
    : boost::mpl::at
      < grammar_eqs_map
      , typename EquationsMap::template o<MapKey::value>
      >
    {
    };

        typedef
      typename boost::mpl::transform
      < range_out_numerals
      , rhs< boost::mpl::arg<1> >
      , boost::mpl::back_inserter<boost::mpl::vector<> > 
      >::type
    equations
    /**@brief
     *  Transform the grammar_eqs_map into vector, where
     *  i-th element is the rhs for the lhs==EquationsMap::o<i>.
     */
    ;
};
  
//{tests
  struct
inp0
{
      enum
    numerals
    { inp_0
    , inp_1
    };
};            
  struct
out0
{
      enum
    numerals
    { out_0
    , out_1
    };
        static
      long const
    size=out_1+1
    ;
};            
namespace boost
{
namespace mpl
{
namespace aux
{

template<> struct integral_rank<out0::numerals>         : int_<6> {};

}}}//exit boost::mpl::aux
  struct
act0
{
      enum
    numerals
    { act_0
    , act_1
    };
};
  void
alg_exprs_arity0_test(void)
{
    typedef alg_exprs<alg_grammar>::arity<0> ar0_type;
    BOOST_MPL_ASSERT_RELATION(0,==,ar0_type::input);
    BOOST_MPL_ASSERT_RELATION(1,==,ar0_type::output);
}
  void
grammar_alias_test(void)
{
    typedef alg_exprs<alg_grammar>::arity<0> ar0_type;
    typedef ar0_type::arity0_map<inp0,out0,act0> sym_map_type;
    
    typedef grammar_expr0_alias<sym_map_type,grammar_expr0_kinds::special> alias_s;
    typedef alias_s::s<alias_s::sn::end_input> end_input; 
    BOOST_MPL_ASSERT_RELATION(end_input::our_oper,==,special_default::end_input);
    typedef grammar_expr0_alias<sym_map_type,grammar_expr0_kinds::input> alias_i;
    typedef alias_i::i<alias_i::in::inp_0> inp_0; 
    BOOST_MPL_ASSERT_RELATION(inp_0::our_oper,==,inp0::inp_0);
}    
  void
grammar_0_ary_expr_gen_test(void)
{
    typedef alg_exprs<alg_grammar>::arity<0> ar0_type;
    typedef ar0_type::arity0_map<inp0,out0,act0> sym_map_type;

    typedef grammar_0_ary_expr_gen<sym_map_type> gram_sym_type;
    typedef gram_sym_type::s<gram_sym_type::sn::end_input> end_input; 
    BOOST_MPL_ASSERT_RELATION(end_input::our_oper,==,special_default::end_input);
}
  struct
gram_eqs0
: grammar_n_ary_expr_gen
  < inp0
  , out0
  , act0
  >
/**@brief
 *  Just test whether friend operator's will compile.
 */
{
        typedef
      s<sn::end_input>
    end_input_type
    ;
        typedef
      typeof
      ( end_input_type::_
      | end_input_type::_
      )
    end_input_alt_end_input
    ;
        typedef
      typeof
      ( end_input_type::_
      >>end_input_type::_
      )
    end_input_seq_end_input
    ;
        typedef
      typeof
      ( o<on::out_0>::_
      = o<on::out_0>::_
      )
    out_0_eq_out_0
    ;
    BOOST_MPL_ASSERT((boost::is_same<out_0_eq_out_0, o<on::out_0>const>));
    
        typedef
      typeof
      ( o<on::out_0>::_
      = o<on::out_0>::_
      >>o<on::out_1>::_
      )
    out_0_eq_out_0_seq_out_1
    ;
    BOOST_MPL_ASSERT_NOT((boost::is_same<out_0_eq_out_0_seq_out_1, o<on::out_0>const>));
    
        typedef
      boost::mpl::map
      < typeof
        ( o<on::out_0>::_
          = o<on::out_1>::_
        )
      , typeof
        ( o<on::out_1>::_
          = o<on::out_0>::_
          >> a<an::act_0>::_
        )
      >
    equations
    ;
};

  struct
arith_expr_inp
{
      enum
    numerals
    { variable //e.g. x
    , value    //e.g. 99
    , lpar     //i.e. (
    , rpar     //i.e. )
    , add_op   //i.e. +
    , mult_op  //i.e. *
    };
};            
  struct
arith_expr_out
{
      enum
    numerals
    { aexpr
    , factor
    , term
    };
        static
      long const
    size=term+1
    ;
}; 

namespace boost
{
namespace mpl
{
namespace aux
{

template<> struct integral_rank<arith_expr_out::numerals>         : int_<6> {};

}}}//exit boost::mpl::aux
  struct
arith_expr_act
{
      enum
    numerals
    { act_0
    , act_1
    };
};
  struct
gram_arith_expr
: grammar_n_ary_expr_gen
  < arith_expr_inp
  , arith_expr_out
  , arith_expr_act
  >
{
        typedef
      boost::mpl::map
      < typeof(
        o<on::factor>::_=
          i<variable>::_ 
        | i<in::value>::_ 
        |    i<in::lpar>::_
          >> o<aexpr>::_
          >> i<in::rpar>::_
        )
      , typeof(
        o<on::term>::_=
          o<on::factor>::_
        |    i<in::mult_op>::_ 
          >> o<on::term>::_
        )
      , typeof(
        o<on::aexpr>::_=
          o<on::term>::_
        |    i<in::add_op>::_ 
          >> o<on::aexpr>::_
        )
      >
    equations
    ;   
};
  template
  < class EquationsMap
  >
  struct
alg_equations
  < alg_empty
  , alg_equations
    < alg_grammar
    , EquationsMap
    >
  >
/**@brief
 *  Convert vector of productions into vector of empty equations.
 */
{
        typedef
      typename alg_equations
      < alg_grammar
      , EquationsMap
      >::equations
    gram_vec
    ;
        typedef
      typename boost::mpl::transform
      < gram_vec
      , morph_empty<boost::mpl::arg<1> >
      , boost::mpl::back_inserter<boost::mpl::vector<> >
      >::type
    equations
    ;
};


  void
empty_epsilon_test(void)
{
        typedef
      gram_eqs0::s
      < gram_eqs0::sn::epsilon
      >
    gram_expr;
        typedef
      morph_empty
      < gram_expr
      >::type
    actual_type;
        typedef
        alg_exprs<alg_empty>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_empty>
          ::arity<0>
          ::allknown_empty
        >
      ::expr<true>
    expected_type;      
    BOOST_MPL_ASSERT((boost::is_same<actual_type,expected_type>));
}

  void
empty_input_test(void)
{
        typedef
      gram_eqs0::i
      < gram_eqs0::in::inp_0
      >
    gram_expr;  
        typedef
      morph_empty
      < gram_expr
      >::type
    actual_type;
        typedef
        alg_exprs<alg_empty>
      ::arity<0>
      ::arity0_map
        <   alg_exprs<alg_empty>
          ::arity<0>
          ::allknown_empty
        >
      ::expr<false>
    expected_type;      
    BOOST_MPL_ASSERT((boost::is_same<actual_type,expected_type>));
}

  void
alg_gram_equations_test(void)
{

    {
        typedef gram_eqs0 gram_eqs;
        typedef alg_equations<alg_grammar,gram_eqs> target_eqs;
        BOOST_MPL_ASSERT((boost::mpl::is_sequence<gram_eqs::equations>));
        BOOST_MPL_ASSERT((boost::mpl::is_sequence<target_eqs::equations>));
        {
                typedef
              boost::mpl::size<target_eqs::equations>::type
            actual_type
            ;
                typedef
              boost::mpl::size<gram_eqs::equations>::type
            expected_type
            ;
            BOOST_MPL_ASSERT((boost::is_same<actual_type,expected_type>));
        }
        {
               gram_eqs::on::numerals const
             out_i=gram_eqs::on::out_0;
                typedef
              boost::mpl::at_c<target_eqs::equations,out_i>
            actual_type;
                typedef
              boost::mpl::at<gram_eqs::equations,gram_eqs::o<out_i> >
            expected_type;
            BOOST_MPL_ASSERT((boost::mpl::equal<actual_type,expected_type>));
        }
        {
               gram_eqs::on::numerals const
             out_i=gram_eqs::on::out_1;
                typedef
              boost::mpl::at_c<target_eqs::equations,out_i>
            actual_type;
                typedef
              boost::mpl::at<gram_eqs::equations,gram_eqs::o<out_i> >
            expected_type;
            BOOST_MPL_ASSERT((boost::mpl::equal<actual_type,expected_type>));
        }
    }
}

  void
alg_empty_equations_test(void)
{

    {
        typedef gram_eqs0 gram_eqs;
        typedef alg_equations<alg_grammar,gram_eqs> target_gram_eqs;
        typedef alg_equations<alg_empty,target_gram_eqs> target_eqs;
        BOOST_MPL_ASSERT((boost::mpl::is_sequence<target_eqs::equations>));
        {
                typedef
              boost::mpl::size<target_eqs::equations>::type
            actual_type
            ;
                typedef
              boost::mpl::size<gram_eqs::equations>::type
            expected_type
            ;
            BOOST_MPL_ASSERT((boost::is_same<actual_type,expected_type>));
        }
    }
}    
//}tests
