#ifndef BOOST_GRAMMAR_PIPELINE_GRAMMER_N_ARY_EXPR_GEN_HPP
#define BOOST_GRAMMAR_PIPELINE_GRAMMER_N_ARY_EXPR_GEN_HPP
#include "alg_exprs_alg_grammar.hpp"
#include <boost/mpl/pair.hpp>
#include <boost/mpl/integral_c.hpp>

//{syntactic sugar
//
    typedef
  alg_exprs
  < alg_grammar
  >
  ::
  arity
  < 0
  >
grammar_expr0_kinds
/**@brief
 *  Convenience template providing shorthand for
 *  nested numerals (an enumeration) type.
 */
;

  template
  < class GrammarEnumMap
  , grammar_expr0_kinds::numerals  KindNum
  >
  struct
grammar_expr0_alias
/**@brief
 * Specializations provide shorter names or
 * aliases for arity0 grammar expressions.
 *
 * The general form for these specializations is:
 *
//{------------------------------cut here -------------------------------------
  template
  < class GrammarEnumMap
  >
  struct
grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::%NUMERALS%
  >
: GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::%KIND%>
{
        typedef
      typename GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::%KIND%>
    %C%n
    ;
      template
      < typename %C%n::numerals Oper
      >
      struct
    %C%
    : public %C%n::template expr<Oper>
    {
            static
          %C%<Oper>
        _
        ;
    };
};
//}------------------------------cut here -------------------------------------
 *
 *  Where %C% and %KIND% are "form parameters".  The following
 *  table lists the possible pairs of form parameters.
 *
 *   %C%    %KIND%
 *  ====================
 *   s      special
 *   i      input
 *   o      output
 *   a      action
 *
 *  When all these specializations are inherited by a class, then, within the 
 *  body of that class, arity=0 expressions are conveniently expressed as,
 *  for example:
 *
 *    s<epsilon>::_
 *
 *  to represent the epsilon grammar expression, or:
 *
 *    o<expr>::_
 *
 *  to represent the nonterminal expression named, expr, where, of course
 *  expr is some numeral in
 *
 *  GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::output>::numerals.
 *
 *  Note, the specialization for o is a little more special than the other
 *  specializations because it has a specialization for operator=.
 *  
 */ 
;

  template
  < class GrammarEnumMap
  >
  struct
grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::special
  >
: GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::special>
{
        typedef
      typename GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::special>
    sn
    ;
      template
      < typename sn::numerals Oper
      >
      struct
    s
    : public sn::template expr<Oper>
    {
            static
          s<Oper>
        _
        ;
    };
};
  template
  < class GrammarEnumMap
  >
  struct
grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::action
  >
: GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::action>
{
        typedef
      typename GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::action>
    an
    ;
      template
      < typename an::numerals Oper
      >
      struct
    a
    : public an::template expr<Oper>
    {
            static
          a<Oper>
        _
        ;
    };
};

  template
  < class GrammarEnumMap
  >
  struct
grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::input
  >
: GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::input>
{
        typedef
      typename GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::input>
    in
    ;
      template
      < typename in::numerals Oper
      >
      struct
    i
    : public in::template expr<Oper>
    {
            static
          i<Oper>
        _
        ;
    };
};

  template
  < class GrammarEnumMap
  >
  struct
grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::output
  >
: GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::output>
{
        typedef
      typename GrammarEnumMap::template arity0_kind<grammar_expr0_kinds::output>
    on
    ;
      template
      < typename on::numerals Oper
      >
      struct
    o
    : public on::template expr<Oper>
    {
            static
          o<Oper>
        _
        ;
            typedef
          o<Oper>
        self_type
        ;
          template
          < class Definition
          /**@brief
           *  Some type produced by type generators
           *  of grammar_n_ary_expr_gen (see below).
           *  However, must not be o<Oper> for
           *  reasons explained in operator=(self_type const&)
           *  below.
           */
          >
          struct
        define_as
        /**@brief
         *  Associate nonterminal, i.e. o<Oper>, with
         *  its Defintion.  IOW, the nested type
         *  represents a production in a grammar.
         */
        {
                typedef
              boost::mpl::
              pair
              < self_type
              , Definition
              >
            type
            ;
        };
          template
          < class Definition
          >
          typename define_as<Definition>::type
        operator=(Definition)const
        ;
          self_type const& //Don't self-associate because
                           //this would represent a production
                           //where the nonterminal's
                           //rhs was that same nonterminal, which
                           //makes no sense.
        operator=(self_type const&)
        ;
    };
};

  template
  < class GrammarEnumMap
  >
  struct
grammar_0_ary_expr_gen
/**@brief
 *  Generators for all 0 ary expression, i.e. expressions
 *  which have no subexpressions.
 *
 *  Actually, since each 0 ary expression contains no
 *  subexpressions, there's only on instance of each; hence,
 *  generation, in this case of 0 ary expressions, simply
 *  means static declaration of each of the single instances
 *  of those expressions.  For example, for each
 *  terminal in the grammar, there's a static declaration
 *  of the single instance.
 */
: grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::special
  >
, grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::input
  >
, grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::output
  >
, grammar_expr0_alias
  < GrammarEnumMap
  , grammar_expr0_kinds::action
  >
{
};
  template
  < class Inputs
  , class Outputs
  , class Actions
  , class Specials=special_default
  >
  struct
grammar_n_ary_expr_gen
/**@brief
 *  Contains all generators for n ary expression, for n>=0.
 *
 *  The generators for n==0 are inherited.
 *  The generators for n>0 are just friend operatorX declarations
 *  for some operator symbol, X (e.g. X==| or X==>> )..
 */
: grammar_0_ary_expr_gen
  < alg_exprs
      < alg_grammar
      >
    ::
    arity
      < 0
      >
    ::arity0_map
      < Inputs
      , Outputs
      , Actions
      , Specials
      >
  >
{
      template
      < class Expr0
      , class Expr1
      >
        friend
      alg_exprs
      < alg_grammar
      >::arity
      < 2
      >::expr
      < alg_exprs
        < alg_grammar
        >::arity
        < 2
        >::gram_alt
      , Expr0
      , Expr1
      >
    operator|
    ( Expr0
    , Expr1
    )
    ;
      template
      < class Expr0
      , class Expr1
      >
        friend
      alg_exprs
      < alg_grammar
      >::arity
      < 2
      >::expr
      < alg_exprs
        < alg_grammar
        >::arity
        < 2
        >::gram_seq
      , Expr0
      , Expr1
      >
    operator>>
    ( Expr0
    , Expr1
    )
    ;
    
};

//}syntactic sugar

#endif
