#ifndef ALG_EXPRS_ALG_GRAMMAR_HPP
#define ALG_EXPRS_ALG_GRAMMAR_HPP
#include <boost/mpl/vector.hpp>
#include <boost/mpl/size.hpp>
#include <boost/concept_check.hpp>
#include <boost/mpl/assert.hpp>
namespace detail
{
      template
      < class Indices
      , class MplVector
      >
      struct
    is_size_indices_vector_same
    {
          void
        constraints(void)
        {
           unsigned const size_indices=Indices::size;
           unsigned const size_vector=boost::mpl::size<MplVector>::type::value;
           BOOST_MPL_ASSERT_RELATION(size_indices,==,size_vector);
        }
        
    };
}//exit detail namespace

  template
  < class Indices  //Indices::numerals are mnemonic
  , class Sequence //indices into Sequence.
  >
  struct
map_indexed
  : Indices
/**@brief
 *  Nested template, at_c, allows accessing Sequence
 *  with mnemonic indices.
 */  
{
        typedef
      typename Indices::numerals
    indices
    ;
        typedef
      Sequence
    sequence
    ;
    BOOST_CLASS_REQUIRE2(Indices,Sequence,detail,is_size_indices_vector_same);
      template
      < indices Index
      >
      struct
    at_c
    #if 0
      //MAINTENANCE NOTE: 2006-09-23.0653
      //  Using this instead of the 'typedef ... type;' below, although saving some
      //  typing, results in compile-time error with g++.
      : mpl::at_c<Sequence,long(index)>
    #endif
    {
            static
          long int const
        index=Index
        ;
            typedef
          typename boost::mpl::at_c<Sequence,index>::type
        type
        ;
    };
      
};

  struct
special_default
{
      enum
    numerals
    { epsilon
    , end_input
    };
};

#include "alg_exprs.hpp"

//{alg_exprs<alg_grammar>

//{arity=0
  template
  <// algebra_numerals AlgNum
  >
      template
      <// unsigned Arity
      >
      struct
alg_exprs
  < alg_grammar
  >
::
    arity
      < 0//Arity
      >
    {
          enum
        numerals
        /**@brief
         *  Indices to Indices.
         */
        { input   //grammar input, or terminal, indices.
        , output  //grammar output, or nonterminal, indices.
        , action  //semantic action indices.
        , special //special indices.
        };
            static
          long const
        size=special+1
        ;
        
          template
          < numerals ArityNum
          , class Enumeration
          , typename Enumeration::numerals Number
          >
          struct
        targ_deduce_helper
        /**@brief
         *  Template Argument Deduction Helper:
         *    When used in typedef inside template class
         *    nested within this arity<0> class (see below),
         *    helps template arg deduction in subsequent
         *    templates (e.g. morph_empty below).
         */
        {};
        
          template
          < class InputEnum
          , class OutputEnum
          , class ActionEnum
          , class SpecialEnum=special_default
          >
          struct
        arity0_map
        : map_indexed
          < arity<0>
          , boost::mpl::vector
            < InputEnum
            , OutputEnum
            , ActionEnum
            , SpecialEnum
            >
          >
        {
                typedef        
              map_indexed
              < arity<0>
              , boost::mpl::vector
                < InputEnum
                , OutputEnum
                , ActionEnum
                , SpecialEnum
                >
              >
            numerals_map_type
            ;
            
              template
              < numerals Ar0Num
              >
              struct
            arity0_kind
            : numerals_map_type::template at_c<Ar0Num>::type
            {
                    typedef typename
                  numerals_map_type::template at_c<Ar0Num>::type
                enumeration_type
                ;
                    typedef typename
                  enumeration_type::numerals
                numerals
                ;
                  template
                  < numerals Oper
                  >
                  struct
                expr
                /**@brief
                 *  Expression with arity=0 of type Ar0Num.
                 *  The particular instance of this arity 0 type is Oper
                 *  (meaning OPERator).  For example: 
                 *
                 *    arity0_kind<input>::expr<lpar> 
                 *
                 *  would be a terminal expression.  where lpar,
                 *  is some terminal in, for example, in a grammar, AEXPR,
                 *  of arithmetic expressions, OTOH:
                 *
                 *    arity0_kind<output>::expr<expr>
                 * 
                 *  would be a nonterminal expression, where expr is
                 *  a nonterminal in AEXPR>
                 */
                {
                        typedef
                      targ_deduce_helper
                      < Ar0Num
                      , enumeration_type
                      , Oper
                      >
                    our_targ_deduce
                    ;
                        static
                      numerals const
                    our_oper=Oper
                    ;
                };
                
            };
        };
    };
    
//}arity=0
//{arity=1
  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
      struct
alg_exprs
  < alg_grammar
  >
::
    arity
      < 1//Arity
      >
    {
          enum
        numerals
        { repeat_ge0  //0 or more of subexpression, Expr0
        , repeat_ge1  //1 or more of subexpression, Expr9
        };
          template
          < numerals Oper
          , class Expr0
          >
          struct
        expr
        ;
    };
//}arity=1
//{arity=2
  template
  <// algebra_numerals AlgNum
  >
      template
      <//unsigned Arity
      >
      struct
alg_exprs
  < alg_grammar
  >
::
    arity
      < 2//Arity
      >
    {
          enum
        numerals
        { gram_seq //Expr0 followed by Expr1
        , gram_alt //either Expr0 or Expr1
        };
          template
          < numerals Oper
          , class Expr0
          , class Expr1
          >
          struct
        expr
        {};
    };
//}arity=2

//}alg_exprs<alg_grammar>

#endif
