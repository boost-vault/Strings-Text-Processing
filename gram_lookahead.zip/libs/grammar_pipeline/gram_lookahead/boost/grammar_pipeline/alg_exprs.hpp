#ifndef BOOST_GRAMMAR_PIPELINE_ALG_EXPRS_HPP
#define BOOST_GRAMMAR_PIPELINE_ALG_EXPRS_HPP
  enum
algebra_numerals
{ alg_grammar 
  //Above for grammar expression "algebra" and the source of all morphisms.
, alg_empty   
  //Above for empty expression algebra. 
  //Value of empty expr morphed from gram expr, e_g,
  //indicates whether e_g can derive empty string.
, alg_first
  //For first expression algebra.
  //Value of first expr morphed from gram expr, e_g,
  //contains set of terminal symbols which can
  //start a string derived from e_g.
};

  template
  < algebra_numerals AlgNum
  >
  struct
alg_exprs
/**@brief
 *   Algebra Expressions.
 */
{
      template
      < unsigned Arity
      >
      struct
    arity
    //Specializations define expressions with arity=Arity.
    //Arity means the number of subexpressions which
    //the expression has.
    ;
    
};
#endif
