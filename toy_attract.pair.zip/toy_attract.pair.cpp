///////////////////////////////////////////////////////////////////////////////
// toy_attract.pair.cpp
//
//  Copyright 2006 Eric Niebler. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
//ChangeLog:
//  2008-02-08.0634
//    WHAT:
//      cp'ed from ./toy_attract.cpp
//    WHY:
//      to modify to use binary proto transforms instead of
//      fusion::cons and thereby (hopefully) enable
//      further transforms to, for example, calculate
//      attributes.
//

#include <vector>
#include <iostream>
#include <utility>
#include <boost/variant.hpp>
#include <boost/fusion/support/pair.hpp>

#include <boost/version.hpp>
#include <boost/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/utility/result_of.hpp>
#include <boost/type_traits/is_same.hpp>

#include <boost/proto/proto.hpp>
#include <boost/proto/transform.hpp>

#include <boost/mpl/integral_c.hpp>
#include <boost/test/unit_test.hpp>

#define TOY_ATTRACT_DEBUG
#ifdef  TOY_ATTRACT_DEBUG
#include <boost/utility/type_name_print.hpp>
#include <boost/utility/trace_scope.hpp>
#define UTILITY_OBJECT_TRACKED_TRACE_MODE
#include <boost/utility/object_tracked.hpp>
#endif

namespace boost 
{ 
namespace spirit2
{
    
    template<typename Lhs, typename Rhs>
    struct production_def
    {
        explicit production_def(Lhs const &a_lhs, Rhs const& a_rhs)
          : lhs(a_lhs)
          , rhs(a_rhs)
        {}
        Lhs lhs;
        Rhs rhs;
    };

    ///////////////////////////////////////////////////////////////////////////////
    /// Begin Spirit grammar here
    ///////////////////////////////////////////////////////////////////////////////
    namespace grammar
    {
        using namespace proto;
        using namespace fusion;
        using namespace transform;

        struct semantic_attribute
        /**@brief
         *  Super class of all semantic attributes.
         */
        {
        };
        template<class Attr>
        struct symbol_attribute
          : semantic_attribute
        {
        };
        
        enum VisitorIndex
        { gram  //Only used in templates with proto::terminal<?> super classes.
        , parse //Used to disambiguate parse function operator()(...)
        , attr  //Used for attributes of parse.
        };
        template<VisitorIndex>
        struct gvisitor
        {};
        
        // A grammar terminal symbol
        enum TerminalIndex
        { ident   //identifier
        , op_plus //plus operator
        , op_mult //multiply operator
        , op_lpar //left  parenthesis
        , op_rpar //right parenthesis
        };
        template<TerminalIndex IndexValue>
        struct tag_term{};
        
        template<class TagTerm,class Gvisitor>
        struct SpiritTermSymbol
        ;
        template<TerminalIndex IndexValue>
        struct SpiritTermSymbol
          <tag_term<IndexValue>,gvisitor<gram> >
          : terminal<tag_term<IndexValue> >
        {
        };
        template<TerminalIndex IndexValue>
        struct SpiritTermSymbol
          <tag_term<IndexValue>,gvisitor<parse> >
        {
        };
        template<TerminalIndex IndexValue>
        struct SpiritTermSymbol
          <tag_term<IndexValue>,gvisitor<attr> >
        {
        };
        struct SpiritTermGram
          : or_
            < when
              < SpiritTermSymbol<tag_term<ident  > , gvisitor<gram>  >
              , SpiritTermSymbol<_arg              , _visitor        >()
              >
            , when
              < SpiritTermSymbol<tag_term<op_plus> , gvisitor<gram>  >
              , SpiritTermSymbol<_arg              , _visitor        >()
              >
            , when
              < SpiritTermSymbol<tag_term<op_mult> , gvisitor<gram>  >
              , SpiritTermSymbol<_arg              , _visitor        >()
              >
            , when
              < SpiritTermSymbol<tag_term<op_lpar> , gvisitor<gram>  >
              , SpiritTermSymbol<_arg              , _visitor        >()
              >
            , when
              < SpiritTermSymbol<tag_term<op_rpar> , gvisitor<gram>  >
              , SpiritTermSymbol<_arg              , _visitor        >()
              >
            >
        {};
        
        // A grammar non-terminal symbol
        enum NonTrmIndex
        { factor
        , term
        , arithexpr
        };
        template<NonTrmIndex IndexValue>
        struct tag_nontrm
        {
        };
        template<class TagNon, class Gvisitor>
        struct SpiritNonTrmSymbol
        ;
        template<NonTrmIndex IndexValue,class Gvisitor>
        struct SpiritNonTrmSymbol
          < tag_nontrm<IndexValue>, Gvisitor>
          : terminal<tag_nontrm<IndexValue> >
        {
        };
        struct SpiritNonTrmGram
          : or_
            < when
              < SpiritNonTrmSymbol<tag_nontrm<factor>    , gvisitor<gram> >
              , SpiritNonTrmSymbol<_arg                  , _visitor       >()
              >
            , when
              < SpiritNonTrmSymbol<tag_nontrm<factor>    , gvisitor<gram> >
              , SpiritNonTrmSymbol<_arg                  , _visitor       >()
              >
            , when
              < SpiritNonTrmSymbol<tag_nontrm<arithexpr> , gvisitor<gram> >
              , SpiritNonTrmSymbol<_arg                  , _visitor       >()
              >
            >
        {};

        template<class Tag, class Gvisitor, class Arg0, class Arg1>
        struct SpiritBinGram
        ;
        
        template<class Tag,                 class Arg0, class Arg1>
        struct SpiritBinGram
                <Tag      , gvisitor<parse>, Arg0, Arg1>
          : std::pair<Arg0,Arg1>
        {};
                
        template<                           class Arg0, class Arg1>
        struct SpiritBinGram
                <tag::shift_right, gvisitor<attr >, Arg0, Arg1>
          : std::pair<Arg0,Arg1>
        {};        
        template<                           class Arg0, class Arg1>
        struct SpiritBinGram
                <tag::bitwise_or , gvisitor<attr>, Arg0, Arg1>
          : variant
            < fusion::pair<mpl::int_<0> ,Arg0>
            , fusion::pair<mpl::int_<1> ,Arg1>
            >
        {
                typedef
              variant
              < fusion::pair<mpl::int_<0> ,Arg0>
              , fusion::pair<mpl::int_<1> ,Arg1>
              >
            super_type
            ;
              Arg0&
            inject0(void)
            {
                typedef fusion::pair<mpl::int_<0> ,Arg0> which_type;
                which_type which_valu;
                super_type::operator=(which_valu);
                which_type& result=get<which_type>(*this);
                return result.second;
            }
              Arg1&
            inject1(void)
            {
                typedef fusion::pair<mpl::int_<1> ,Arg1> which_type;
                which_type which_valu;
                super_type::operator=(which_valu);
                which_type& result=get<which_type>(*this);
                return result.second;
            }
        };

        struct SpiritExpr;
      
        // A SpiritExpr either:
        //  a terminal or non-terminal symbol
        //  or a sequence (shift_right)
        //  or an alternate (bitwise_or).
        struct SpiritExpr
          : or_
            < SpiritTermGram
            , SpiritNonTrmGram
            , when
              < binary_expr<_,_,_>
              , SpiritBinGram
                < tag_of<_>
                , _visitor
                , SpiritExpr(_left)
                , SpiritExpr(_right) 
                >()
              >
            >
        {};
      #ifdef TOY_ATTRACT_DEBUG
          template
          < class Attr
          >
          void
        print_attr
          ( Attr const&
          )
        {
            ::utility::type_name_print<Attr>();
        }
        
          template
          < typename Left
          , typename Right
          >
          void
        print_attr
          (   SpiritBinGram
              < tag::bitwise_or
              , gvisitor<attr>
              , Left
              , Right
              >const&
            attr
          )
        {
            marg_ostream&sout=mout();
            sout<<"bitwise_or\n";
            sout<<"{ ";
            ++sout;
            int const which=attr.which();
            sout<<"which="<<which<<"\n";
            --sout;
            sout<<", ";
            ++sout;
            if(which==0)
            {
                typedef fusion::pair<mpl::int_<0> ,Left> which_type;
                which_type const& result=get<which_type>(attr);
                print_attr(result.second);
            }
            else
            {
                typedef fusion::pair<mpl::int_<1> ,Right> which_type;
                which_type const& result=get<which_type>(attr);
                print_attr(result.second);
            }
            --sout;
            sout<<"}\n";
        }
        
          template
          < typename Left
          , typename Right
          >
          void
        print_attr
          (   SpiritBinGram
              < tag::shift_right
              , gvisitor<attr>
              , Left
              , Right
              >const&
            attr
          )
        {
            marg_ostream&sout=mout();
            sout<<"shift_right attr\n";
            sout<<"{ ";
            ++sout;
            print_attr(attr.first);
            --sout;
            sout<<", ";
            ++sout;
            print_attr(attr.second);
            --sout;
            sout<<"}\n";
        }
      #endif
      
      #if 0
        struct SpiritProductionDef
          : when
            < assign<SpiritNonTrmGram, SpiritExpr>
            , production_def<SpiritNonTrmGram, SpiritExpr>(_left,_right)
            >
        {};
        
        struct SpiritProductionList
          : or_
            < when
              < SpiritProductionDef
              , _arg
              >
            , when
              < comma<SpiritProductionList, SpiritProductionDef>
              , reverse_fold
                < _
                , fusion::nil()
                , fusion::cons<SpiritProductionDef, _state>(SpiritProductionDef, _state)
                >
              >
            >
        {};
      #endif
        
    } // namespace grammar

    using namespace grammar;

    ///////////////////////////////////////////////////////////////////////////////
    /// End SpiritExpr
    ///////////////////////////////////////////////////////////////////////////////

    // Parser
    template<typename Iterator>
    struct parser
    #ifdef TOY_ATTRACT_DEBUG
    : public ::utility::object_tracked
    #endif
    {
        mutable Iterator first;
        Iterator second;

        parser(Iterator begin, Iterator end)
          : first(begin)
          , second(end)
        {
          #ifdef TOY_ATTRACT_DEBUG
            mout()<<"parser(begin,end):this->id_get="<<this->id_get()<<"\n";
          #endif
        }

        bool done() const
        {
            return this->first == this->second;
        }
        
          template
          < typename Left
          , typename Right
          , typename Attr
          >
        bool operator ()
          (   SpiritBinGram
              < tag::bitwise_or
              , gvisitor<parse>
              , Left
              , Right
              >const&
            pair_gram 
          , Attr& attr
          ) const
        {
          #ifdef TOY_ATTRACT_DEBUG
            ::utility::trace_scope ts("(alternative)");
            mout()<<":this->id_get()="<<this->id_get()<<"\n";
            mout()<<":grammar=\n";
            ::utility::type_name_print(pair_gram);
            mout()<<":attr_type=\n";
            ::utility::type_name_print<Attr>();
            mout()<<":cur_tok="<<*this->first<<"\n";
          #endif
            bool result=this->operator()
              ( pair_gram.first
              , attr.inject0()
              );
            if(!result)
            {
                result=this->operator()
                ( pair_gram.second
                , attr.inject1()
                );
            }
          #ifdef TOY_ATTRACT_DEBUG
            mout()<<":result="<<result<<":cur_tok="<<*this->first<<"\n";
          #endif
            return result;
        }
        
          template
          < typename Left
          , typename Right
          , typename Attr
          >
        bool operator ()
          (   SpiritBinGram
              < tag::shift_right
              , gvisitor<parse>
              , Left
              , Right
              >const&
            pair_gram
          , Attr& attr
          ) const
        {
          #ifdef TOY_ATTRACT_DEBUG
            ::utility::trace_scope ts("(shift_right_gram)");
            mout()<<":this->id_get()="<<this->id_get()<<"\n";
            mout()<<":grammar=\n";
            ::utility::type_name_print(pair_gram);
            mout()<<":attr_type=\n";
            ::utility::type_name_print<Attr>();
            mout()<<":cur_tok="<<*this->first<<"\n";
          #endif
            bool result=this->operator()
              ( pair_gram.first
              , attr     .first
              );
            if(result)
            {
                result=this->operator()
                  ( pair_gram.second
                  , attr     .second
                  );
            }
            return result;
        }

        template<TerminalIndex IndexValue, typename Attr>
        bool operator ()
          (   SpiritTermSymbol
              < tag_term<IndexValue>
              , gvisitor<parse> 
              > const&
          , Attr&
          ) const
        {
          #ifdef TOY_ATTRACT_DEBUG
            ::utility::trace_scope ts("(terminal)");
            mout()<<":this->id_get()="<<this->id_get()<<"\n";
            mout()<<":grammar=\n";
            mout()<<IndexValue<<"\n";
            mout()<<":cur_tok="<<*this->first<<"\n";
          #endif
            bool result=true;
            if(this->done() || IndexValue != *this->first)
            {
                result=false;
            }
            else
            {
                ++this->first;
            }
          #ifdef TOY_ATTRACT_DEBUG
            mout()<<":cur_tok="<<*this->first<<"\n";
          #endif
            return result;
        }
            

    };
    
  //#define DEBUG_PATTERN_TYPE
        typedef
      SpiritExpr
    pattern_type
    ;
    
  #define ENABLE_MATCHES
    template<typename ExprType, typename Iterator>
  #ifdef ENABLE_MATCHES
    typename enable_if<proto::matches< ExprType, pattern_type >, bool >::type
  #else
    bool
  #endif
    parse_impl
      ( ExprType const& a_expr
      , Iterator begin
      , Iterator end
      )
    {
        using namespace grammar;
        pattern_type pattern_valu;
        typedef ExprType expr_type;
        expr_type const& expr_valu= a_expr;

        typedef void this_type;
        
        typedef mpl::void_ state_type;
        state_type state_valu;
        
        typedef gvisitor<parse> viz_parse_type;
        viz_parse_type viz_parse_valu;
        
            typedef 
            typename
          pattern_type::result<this_type(expr_type,state_type,viz_parse_type)>::type
        expr_parse_type;
        expr_parse_type expr_parse_valu=pattern_valu(expr_valu,state_valu,viz_parse_valu);

        typedef gvisitor<attr> viz_attr_type;
        viz_attr_type viz_attr_valu;
            typedef 
            typename
          pattern_type::result<this_type(expr_type,state_type,viz_attr_type)>::type
        expr_attr_type;
        expr_attr_type expr_attr_valu=pattern_valu(expr_valu,state_valu,viz_attr_valu);

        parser<Iterator> parse_fun(begin, end);
        bool const result=
          parse_fun
          ( expr_parse_valu
          , expr_attr_valu
          );
        #ifdef  TOY_ATTRACT_DEBUG
        {
            ::utility::trace_scope ts("print_attr(expr_attr_valu)");
            print_attr(expr_attr_valu);
        }
        #endif
        return result;
    }

  #ifdef ENABLE_MATCHES
    // 2nd overload provides a short error message for invalid expr_valus
    template<typename ExprType, typename Iterator>
    typename disable_if<proto::matches< ExprType, pattern_type >, bool >::type
    parse_impl(ExprType const &expr_valu, Iterator begin, Iterator end)
    {
        BOOST_MPL_ASSERT((proto::matches<ExprType, pattern_type>));
        return false;
    }
  #endif

    // parse() converts expr_valu literals to proto expressions if necessary
    // and dispatches to parse_impl
    template<typename ExprType, typename Iterator>
    bool parse(ExprType const &expr_valu, Iterator begin, Iterator end)
    {
        return parse_impl(proto::as_expr(expr_valu), begin, end);
    }

}}

using namespace boost::spirit2::grammar;

template<TerminalIndex IndexValue>
    typename 
  SpiritTermSymbol
  < boost::spirit2::grammar::tag_term<IndexValue>
  , boost::spirit2::grammar::gvisitor<gram> 
  >::type 
mk_term(void)
{
        typename 
      SpiritTermSymbol
      < boost::spirit2::grammar::tag_term<IndexValue>
      , boost::spirit2::grammar::gvisitor<gram> 
      >::type 
    t;
    return t;
}
template<NonTrmIndex IndexValue>
    typename 
  SpiritNonTrmSymbol
  < boost::spirit2::grammar::tag_nontrm<IndexValue>
  , boost::spirit2::grammar::gvisitor<gram> 
  >::type 
mk_nontrm(void)
{
        typename 
      SpiritNonTrmSymbol
      < boost::spirit2::grammar::tag_nontrm<IndexValue>
      , boost::spirit2::grammar::gvisitor<gram> 
      >::type 
    t;
    return t;
}
void test_toy_attract()
{
  #if 1
    {
      #ifdef TOY_ATTRACT_DEBUG
        ::utility::trace_scope ts("parse term");
      #endif
        std::vector<TerminalIndex> term_string;
        term_string.push_back(ident);
        BOOST_CHECK
        (   boost::spirit2::parse
            (    mk_term<ident>()
            , term_string.begin()
            , term_string.end()
            )
        
        );
    }
  #endif
  #if 1
    {
      #ifdef TOY_ATTRACT_DEBUG
        ::utility::trace_scope ts("parse seq");
      #endif
        std::vector<TerminalIndex> term_string;
        term_string.push_back(ident);
        term_string.push_back(ident);
        BOOST_CHECK
        (   boost::spirit2::parse
            (    mk_term<ident>()
              >> mk_term<ident>()
            , term_string.begin()
            , term_string.end()
            )
        
        );
    }
  #endif
  #if 1
    {
      #ifdef TOY_ATTRACT_DEBUG
        ::utility::trace_scope ts("parse alt");
      #endif
        std::vector<TerminalIndex> term_string;
        term_string.push_back(ident);
        BOOST_CHECK
        (   boost::spirit2::parse
            (    mk_term<ident>()
              |  mk_term<op_plus>()
            , term_string.begin()
            , term_string.end()
            )
        
        );
    }
  #endif
}

using namespace boost::unit_test;
///////////////////////////////////////////////////////////////////////////////
// init_unit_test_suite
//
test_suite* init_unit_test_suite( int argc, char* argv[] )
{
    test_suite *test = BOOST_TEST_SUITE("test proto, grammars and tree transforms");

    test->add(BOOST_TEST_CASE(&test_toy_attract));

    return test;
}
