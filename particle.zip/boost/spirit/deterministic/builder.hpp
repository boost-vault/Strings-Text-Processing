#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_HPP

#include<boost/spirit/deterministic/builder/primitives.hpp>
#include<boost/spirit/deterministic/builder/alternative.hpp>
#include<boost/spirit/deterministic/builder/sequence.hpp>
#include<boost/spirit/deterministic/builder/kleene_star.hpp>
#include<boost/spirit/deterministic/builder/difference.hpp>
#include<boost/spirit/deterministic/builder/numerics.hpp>
#include<boost/spirit/deterministic/builder/directives.hpp>

/*#include <boost/spirit/deterministic/builder/primitives.hpp>
#include <boost/spirit/deterministic/builder/alternative.hpp>
#include <boost/spirit/deterministic/builder/kleene_star.hpp>
#include <boost/spirit/deterministic/builder/sequence.hpp>
#include <boost/spirit/deterministic/builder/difference.hpp>
#include <boost/spirit/deterministic/builder/optional.hpp>
#include <boost/spirit/deterministic/builder/numerics.hpp>
#include <boost/spirit/deterministic/builder/positive.hpp>
#include <boost/spirit/deterministic/builder/loops.hpp>
*/
#endif