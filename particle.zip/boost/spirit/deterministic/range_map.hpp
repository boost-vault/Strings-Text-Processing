#ifndef BOOST_SPIRIT_DETERMINISTIC_RANGE_MAP_HPP
#define BOOST_SPIRIT_DETERMINISTIC_RANGE_MAP_HPP

#include <map>
#include <vector>
#include <limits>

namespace boost { namespace spirit { namespace deterministic {

template<typename SymbolT>
struct integral_symbol_policy {
    bool has_next_symbol(SymbolT symbol) const {
        return symbol<(std::numeric_limits<SymbolT>::max)();
    }
    SymbolT next_symbol(SymbolT symbol) const {
        return symbol+1;
    }
    SymbolT prior_symbol(SymbolT symbol) const {
        return symbol-1;
    }
    SymbolT symbol_range_end() const {
        return (std::numeric_limits<SymbolT>::max)();
    }
};

template<typename SymbolT,typename ValueT,typename SymbolPolicy=integral_symbol_policy<SymbolT> >
class range_map 
:   public std::map<SymbolT,ValueT>
,   public SymbolPolicy
{
public:
    typedef std::map<SymbolT,ValueT> base_t;
    typedef std::vector<iterator> range_vector;
    typedef std::pair<SymbolT,SymbolT> range_pair;
    void create_range(SymbolT start,SymbolT end,range_vector& ranges)
    {
        //Invalid range
        if(end<start) return;

        iterator iend;
        if(has_next_symbol(end)) {
            iend=insert_symbol(next_symbol(end));
        }
        else {
            iend=this->end();
        }
        iterator istart=insert_symbol(start);
        for(iterator it=istart;it!=iend;++it) {
             ranges.push_back(it);
        }
   }
   void find_range(SymbolT start,SymbolT end,range_vector& ranges)
   {
        //Invalid range
        if(end<start) return;
        iterator istart=find(start);
        iterator iend=find(next_symbol(end));
        if(iend==this->begin()) iend=this->end();
        if(istart==this->end()) return;
        if(iend!=this->end() && iend->first!=next_symbol(end)) {
            ++iend;
        }
        for(iterator it=istart;it!=iend;++it) ranges.push_back(it);
        ranges.push_back(iend);
   }
   void find_range(std::pair<SymbolT,SymbolT>& range,range_vector& ranges)
   {
       find_range(range.first,range.second,ranges);
   }
   iterator insert_symbol(SymbolT symbol) {
      iterator isymbol=find(symbol);
      if(isymbol==end()) return insert(std::make_pair(symbol,ValueT())).first;
      else if(isymbol->first!=symbol) return insert(std::make_pair(symbol,isymbol->second)).first;
      return isymbol;
   }
   std::pair<SymbolT,SymbolT> get_range(const_iterator it) const {
       if(it==end()) return std::make_pair(symbol_range_end(),symbol_range_end());
       else {
           SymbolT istart=it->first;
           SymbolT iend;
           ++it;
           if(it==end()) iend=symbol_range_end();
           else iend=prior_symbol(it->first);
           return std::make_pair(istart,iend);
       }
   }
   size_t range_count(iterator it) {     
      if(it==end()) return 0;
      SymbolT first=it->first;
      ++it;
      SymbolT last;
      if(it==end()) last=symbol_range_end();
      else last=it->first;
      return last-first;
   }
   size_t value_count(ValueT& value){
      size_t count=0;
      for(iterator it=begin();it!=end();++it) {
         if(it->second==value) {
            count+=range_count(it);
         }
      }
      return count;
   }
   size_t value_count(ValueT& value,range_vector& ranges) const{
      size_t count=0;
      for(int i=0;i<ranges.size();++i) {
         if(ranges[i]->second==value) {
            count+=range_count(ranges[i]);
         }
      }
      return count;
   }
   iterator find(SymbolT symbol) {
      //No symbols in range
      if(empty()) return end();
      iterator it=upper_bound(symbol);
      //We are before the first element in the range.
      if(it==begin()) return end();
      //Always decrement to find the actual range we are interested in
      return --it;
   }
   const_iterator find(SymbolT symbol) const{
       //No symbols in range
       if(empty()) return end();
       const_iterator it=upper_bound(symbol);
       //We are before the first element in the range.
       if(it==begin()) return end();
       //Always decrement to find the actual range we are interested in
       return --it;
   }
};

}}}

#endif