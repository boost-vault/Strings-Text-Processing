#ifndef BOOST_SPIRIT_DETERMINISTIC_NODE_SLOTS_HPP
#define BOOST_SPIRIT_DETERMINISTIC_NODE_SLOTS_HPP

#include <boost/intrusive_ptr.hpp>
#include <set>
#include <boost/foreach.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT>
    class node_slots : public std::set<typename RuleT::node_p*> 
    {
    public:
        typedef typename RuleT::node_t node_t;
        typedef typename RuleT::node_p node_p;

        typedef typename node_t::const_range_iterator const_range_iterator;
        typedef typename node_t::range_iterator range_iterator;
        bool has_reference(const_range_iterator& ref) const;
        void insert(const_range_iterator& ref);
        bool has_reference(node_p const& ref) const;
        void insert(node_p const& ref);
        void join(const node_slots<RuleT>& other) {
            if(other.size()==0) return;
            BOOST_FOREACH(node_p* node,other) {
                insert(*node);
            }
        }
        size_t erase(node_p& ref) {
            return std::set<node_p*>::erase(&ref);
        }
        size_t erase(const node_slots<RuleT>& other) {
            if(other.size()==0) return 0;
            size_t count=0;
            BOOST_FOREACH(node_p* node,other) {
                count+=erase(*node);
            }
            return count;
        }
        size_t count(const node_p& ref) const {
            size_t size=0;
            const node_slots<RuleT>& rule=*this;
            BOOST_FOREACH(node_p* node,rule) {
                if(*node==ref) ++size;
            }
            return size;
        }
        node_slots<RuleT>& operator=(const node_p& ref) {
            const node_slots<RuleT>& rule=*this;
            BOOST_FOREACH(node_p* node,rule) {
                *node=ref;
            }
            return *this;
        }
    };

    template<typename RuleT>
    bool node_slots<RuleT>::has_reference(const_range_iterator& ref) const{
        return has_reference(ref->second);
    }

    template<typename RuleT>
    void node_slots<RuleT>::insert(const_range_iterator& ref) {
        insert(ref->second);
    }

    template<typename RuleT>
    void node_slots<RuleT>::insert(node_p const& ref) {
        std::set<node_p*>::insert(const_cast<node_p*>(&ref));
    }

    template<typename RuleT>
    bool node_slots<RuleT>::has_reference(node_p const& ref) const{
        return find(const_cast<node_p*>(&ref))!=end();
    }

}}}

#endif