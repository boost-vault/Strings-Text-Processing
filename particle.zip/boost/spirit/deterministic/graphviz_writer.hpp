#ifndef BOOST_SPIRIT_DETERMINISTIC_GRAPHVIZ_WRITER_HPP
#define BOOST_SPIRIT_DETERMINISTIC_GRAPHVIZ_WRITER_HPP

#include <boost/intrusive_ptr.hpp>
#include<boost/lexical_cast.hpp>

namespace boost {namespace spirit {namespace deterministic {

    template<typename RuleT>
    class graphviz_rule {
    public:
        typedef typename RuleT::node_p node_p;
        typedef typename RuleT::node_t node_t;
        typedef typename RuleT::node_range::const_iterator const_iterator;
        graphviz_rule(std::ostream& stream,RuleT& rule);
        std::string write_node(const node_p& node);
        std::string char_value(char value) {
            if(value>=0 &&  std::isalnum(value) || value=='_') return boost::lexical_cast<std::string>(value);
            switch(value) {
                case '\\': return "\\\\";
                case '\n': return "\\\\n";
                case '\b': return "\\\\b";
                case '\t': return "\\\\t";
                case '\v': return "\\\\v";
                case '\f': return "\\\\f";
                case '\r': return "\\\\r";
                case '\"': return "\\\"";
                case '\'': return "\\\'";
                case ' ': return "space";
                case '/': return "/";
                case '*': return "*";
                case '+': return "+";
                case '-': return "-";
                case '.': return ".";
                case '(': return "(";
                case ')': return ")";
                case '?': return "?";
                default: {
                    unsigned char val(value);
                    return toHex(val>>4) + toHex(val&0xf);
                }
            }
        }
        std::string toHex(unsigned char c) {
            switch(c) {
                case 0: return "0";
                case 1: return "1";
                case 2: return "2";
                case 3: return "3";
                case 4: return "4";
                case 5: return "5";
                case 6: return "6";
                case 7: return "7";
                case 8: return "8";
                case 9: return "9";
                case 10: return "A";
                case 11: return "B";
                case 12: return "C";
                case 13: return "D";
                case 14: return "E";
                case 15: return "F";
                default: return "";
            }            
        }
    private:
        std::map<node_p,std::string> name_map;
        typedef std::map<std::string,std::pair<std::string,std::string> > EdgeMap;
        EdgeMap edgemap;
        RuleT& rule;
        std::ostream& stream;
        int empty_nodes;
    };

    template<typename RuleT>
    graphviz_rule<RuleT>::graphviz_rule(std::ostream& stream_,RuleT& rule_)
        :   rule(rule_)
        ,   stream(stream_)
        ,   empty_nodes(0)
    {
        stream << "digraph rule {" << std::endl;
        stream << "   node [shape=record];" << std::endl; 
        stream << "   edge [color=red,style=dashed];" << std::endl; 
        write_node(rule.get_root());
        /*    for(size_t i=0;i<rule.get_nodes().size();++i) {
        node_p node=rule.get_nodes()[i];
        write_node(node);
        }*/
        for(EdgeMap::iterator iedge=edgemap.begin();iedge!=edgemap.end();++iedge) {
            stream << "   " << iedge->first << " -> " << iedge->second.first;
            stream << " [color = " << iedge->second.second << "]";
            stream << std::endl;
        }
        stream << "}" << std::endl;
    }

    template<typename RuleT>
    std::string graphviz_rule<RuleT>::write_node(const node_p& node)
    {
        if(!node) {
            std::string name="empty" + boost::lexical_cast<std::string>(++empty_nodes);
            stream << "   " << name << "[color = green label=\"empty\"]" << std::endl;
            return name;
        }

        std::string& name=name_map[node];
        bool new_node=name.empty();
        if(!new_node) return name+":node_";
        int end_node_count=rule.get_slots().count(node);
        int node_usage=node.node_count()-1;
        if(name.empty()) name="node"+boost::lexical_cast<std::string>(name_map.size());
        //if(use_rule!=&rule) return name;
        std::string label;
        int range_count=0;
        for(const_iterator irange=node->get_ranges().begin();irange!=node->get_ranges().end();++irange) {
            bool write_edge;
            if(!new_node) write_edge=false;
            //Include ranges with a valid next node
            else if(irange->second) write_edge=true;
            //Include invalid next nodes if they point to an end slot
            else if(rule.get_slots().has_reference(irange->second)) write_edge=true;
            //Otherwise ignore this range.
            else write_edge=false;
            if(!write_edge) continue;

            std::pair<char,char> result=node->get_ranges().get_range(irange);
            std::string local_label;
            std::string range_name="range" + boost::lexical_cast<std::string>(++range_count);
            if(result.first==result.second) {
                local_label=char_value(result.first);          
            }
            else {
                local_label=char_value(result.first) + " - " + char_value(result.second);
            }
            if(!label.empty()) label+=" | ";
            label+= "<" + range_name + "> " + local_label;
            if(write_edge) {
                std::string dest_name=write_node(irange->second);
                std::string color="red";
                //if(end_node) color="green";
                if(rule.get_slots().has_reference(irange)) color="green";
                edgemap[name+":"+range_name]=make_pair(dest_name,color);
            }
        }
        if(!new_node) return name+":node_";
        stream << "   " << name << "[";
        if(node_usage==end_node_count) stream << "color = green ";
        else if(end_node_count>0) stream << "color = blue ";
        std::string node_name="node";
        if(node==rule.get_root()) node_name="start node";
        node_name+=" " + lexical_cast<std::string>(node_usage);
        if(end_node_count>0) {
            node_name+=" " + lexical_cast<std::string>(end_node_count);
        }
        stream << "label=\"{<node_> " + node_name +"| {"+label+"}}\"]" << std::endl;
        return name+":node_";
    }

    template<typename RuleT>
    void write_graphviz_rule(std::ostream& stream,RuleT& rule) {
        graphviz_rule<RuleT>(stream,rule);
    }

}}}

#endif