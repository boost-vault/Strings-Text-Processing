#ifndef BOOST_SPIRIT_DETERMINISTIC_COUNTED_BASE_HPP
#define BOOST_SPIRIT_DETERMINISTIC_COUNTED_BASE_HPP

#include <boost/intrusive_ptr.hpp>

namespace boost {namespace spirit {namespace deterministic {

    //Do not delete
    template<typename DerivedT>
    class counted_base {
    public:
        counted_base() : count(0) {}
        size_t get_count() const {return count;}
        void add_ref() {++count;}
        void release() {--count;}
        DerivedT* derived() {return static_cast<DerivedT*>(this);}
    private:
        size_t count;
    };

    template<typename DerivedT>
    void intrusive_ptr_add_ref(counted_base<DerivedT>* base)
    {
        base->add_ref();
    }

    template<typename DerivedT>
    void intrusive_ptr_release(counted_base<DerivedT>* base)
    {
        base->release();
    }

}}}

#endif