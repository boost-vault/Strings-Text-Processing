#ifndef BOOST_SPIRIT_DETERMINISTIC_SYMBOL_NODE_HPP
#define BOOST_SPIRIT_DETERMINISTIC_SYMBOL_NODE_HPP

#include <set>
#include <boost/spirit/deterministic/range_map.hpp>
#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/spirit/deterministic/counted_base.hpp>
#include <boost/spirit/deterministic/builder/builder.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT>
	class symbol_node {
    public:
		typedef RuleT rule_t;
		typedef typename rule_t::symbol_t symbol_t;

        //Represent the node itself.
        typedef typename RuleT::node_t node_t;
        typedef typename RuleT::node_p node_p;

        //Represent the possible alternatives for the next character.
        typedef typename RuleT::node_range node_range;
        typedef typename node_range::range_vector range_vector;
        typedef typename node_range::iterator range_iterator;
        typedef typename node_range::const_iterator const_range_iterator;
        typedef typename builder<RuleT>::builder_p builder_p;

        symbol_node(RuleT* rule);
        ~symbol_node() {}

        node_p unroll(RuleT* rule,const node_slots<RuleT>& source_back,node_slots<RuleT>& dest_back) const;
        template<typename CallbackT>
        node_p unroll(RuleT* rule,CallbackT& callback) const {
            node_p unrolled_node=rule->add_node();
            unrolled_node->get_ranges()=next;
            const_range_iterator isource=next.begin();
            range_iterator idest=unrolled_node->get_ranges().begin();
            for(;isource!=next.end();++isource,++idest) {
                callback(isource,idest);
            }
            return unrolled_node;
        }
        template<typename CallbackT>
        node_p unroll(CallbackT& callback) const {
            return unroll(parent,callback);
        }
        node_p unroll(node_slots<RuleT>& back) const;
        void copy(node_p& source,node_slots<RuleT>& source_back,node_slots<RuleT>& dest_back);
        node_p& add(symbol_t symbol,node_slots<RuleT>& back);
        void add_range(symbol_t start,symbol_t end,node_slots<RuleT>& back,node_slots<RuleT>& end_slots);

        node_range& get_ranges() {return next;}
        const node_range& get_ranges() const {return next;}
        RuleT* get_parent() const {return parent;}

        bool is_builder() const {return builder!=0;}

        const builder_p& get_builder() const {return builder;}
        builder_p& get_builder() {return builder;}
        void set_builder(const builder_p& in) {builder=in;}
    private:
        
        //Represent the possible alternatives for the next character.
        node_range next;

        //During creation of the rules, we cannot assume that a rule is complete.
        //It is impossible to join an incomplete rule to a node to create a deterministic parse tree.
        //A node builder is created to keep this information until all rules are created
        builder_p builder;
        
        RuleT* parent;
    };

}}}

#include <boost/spirit/deterministic/symbol_node.ipp>

#endif