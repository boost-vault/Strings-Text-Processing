#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_COMMON_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_COMMON_HPP

namespace boost { namespace spirit { namespace deterministic {

template<typename RuleT,typename ParserT,typename SpaceP>
void build_expression(RuleT* rule,ParserT const& p,SpaceP const& space,typename RuleT::node_p& front,typename node_slots<RuleT>& back,typename node_slots<RuleT>& exclude)
{
    build_expression(rule,p,space,front,back);
}

}}}
#endif