#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_IMPRINT_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_IMPRINT_HPP

#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/foreach.hpp>
#include <boost<spirit/deterministic/subtract.hpp>

namespace boost { namespace spirit { namespace deterministic {


    template<typename RuleT>
    void imprint(typename RuleT::node_p& front,typename RuleT::node_p& difference_front,node_slots<RuleT>& back,node_slots<RuleT>& difference_back) {
        //Unroll node if it is used by more than one.
        if(front->get_count()>1) {
            front=front->unroll(back);
        }
        if(difference_back.has_reference(difference_front)) {
            if(back.has_reference(front)) back.erase(front);
        }
        if(!difference_front) return;
        if(difference_front->get_count()>1) {
            difference_front=difference_front->unroll(difference_back);
        }
        for(NodeT::range_iterator it=difference_front->get_ranges().begin();it!=difference_front->get_ranges().end();++it) {
            typedef typename NodeT::node_range::range_pair range_pair;
            //This is the range we want to insert into front.
            range_pair diff_range=difference_front->get_ranges().get_range(it);
            //End nodes represents the nodes we are interested in iterating on.
            node_slots<NodeT> end_nodes;
            if(it->second || difference_back.has_reference(it)) {
                front->add_range(diff_range.first,diff_range.second,back,end_nodes);
                //No more elements to subtract
                BOOST_FOREACH(NodeT** slot,end_nodes) {
                    imprint(*slot,it->second,back,difference_back);
                }
            }
        }
    }

}}}

#endif