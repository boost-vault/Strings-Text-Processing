#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_SERIAL_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_SERIAL_HPP

#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/spirit/deterministic/builder/detail/union.hpp>
#include <boost/foreach.hpp>

namespace boost { namespace spirit { namespace deterministic {
    //This is supposed to be a complete implementation of serial join.
    template<typename RuleT>
    void serial_join(RuleT* rule,node_slots<RuleT>& dest_begin,typename RuleT::node_p& source_begin,node_slots<RuleT>& dest_end,node_slots<RuleT>& source_end,node_slots<RuleT>& exclude)
    {
        detail::boolean_union<RuleT> uniter(rule,dest_end,source_end,true);
        uniter.set_exclude(exclude);
        uniter.join(dest_begin,source_begin);
    }

    template<typename RuleT>
    void serial_join(RuleT* rule,node_slots<RuleT>& dest_begin,typename RuleT::node_p& source_begin,node_slots<RuleT>& dest_end,node_slots<RuleT>& source_end)
    {
        detail::boolean_union<RuleT> uniter(rule,dest_end,source_end,true);
        uniter.join(dest_begin,source_begin);
    }

    template<typename RuleT>
    void serial_join(RuleT* rule,typename RuleT::node_p& dest_begin,typename RuleT::node_p& source_begin,node_slots<RuleT>& dest_end,node_slots<RuleT>& source_end)
    {
        detail::boolean_union<RuleT> uniter(rule,dest_end,source_end,true);
        node_slots<RuleT> dest_slots;
        dest_slots.insert(dest_begin);
        uniter.join(dest_slots,source_begin);
    }

    template<typename RuleT>
    void serial_join(RuleT* rule,node_slots<RuleT>& dest_begin,typename RuleT::node_p& source_begin,node_slots<RuleT>& dest_end) {
        node_slots<RuleT> source_end;
        serial_join(rule,dest_begin,source_begin,dest_end,source_end);
    }

    template<typename RuleT>
    void serial_join(RuleT* rule,typename RuleT::node_p& dest_begin,typename RuleT::node_p& source_begin,node_slots<RuleT>& dest_end)
    {
        node_slots<RuleT> source_end;
        serial_join(rule,dest_begin,source_begin,dest_end,source_end);
    }
}}}

#endif