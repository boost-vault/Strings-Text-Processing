#ifndef BOOST_SPIRIT_DETERMINISTIC_LOOPS_HPP
#define BOOST_SPIRIT_DETERMINISTIC_LOOPS_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/utility/loops.hpp>
#include <boost/spirit/deterministic/builder/kleene_star.hpp>
#include <boost/spirit/deterministic/builder/optional.hpp>
#include <boost/spirit/deterministic/builder/sequence.hpp>
#include <boost/spirit/deterministic/builder/alternative.hpp>
#include <boost/spirit/deterministic/builder/positive.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename ParserT, typename MinT, typename MaxT>
    void build_expression(RuleT* rule,finite_loop<ParserT,MinT,MaxT> const& p,typename RuleT::node_t*& front,typename RuleT::node_slots_t& back)
    {
		typedef typename RuleT::node_slots_t node_slots_t; 
		typedef typename RuleT::node_t node_t; 
        std::vector<node_slots_t> middle;
        std::vector<node_t*> start;
        start.resize(p.get_max());
        middle.resize(p.get_max());
        for(MaxT i=0;i<p.get_max();++i) {
            if(i==0) build_expression(rule,p.subject(),front,middle[i]);
            else build_expression(rule,p.subject(),start[i-1],middle[i]);
        }
        for(MinT i=1;i<p.get_min();++i) {
            node_slots_t ignore;
            serial_join(rule,middle[i-1],start[i-1],ignore);
        }
        for(MinT i=p.get_min();i<=p.get_max();++i) {
            serial_join(rule,middle[i-1],start[i-1],back);
        }
        for(size_t i=0;i<start.size();++i) {
            back.erase(start[i]);
        }
    }

}}}

#endif