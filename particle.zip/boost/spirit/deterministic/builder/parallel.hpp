#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_PARALLEL_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_PARALLEL_HPP

#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/spirit/deterministic/builder/detail/union.hpp>
#include <boost/foreach.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT>
    typename RuleT::node_p& parallel_add(RuleT* rule,typename RuleT::symbol_t symbol,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(!front) front=rule->add_node();
        //Unroll is needed when the requested node is used by more clients than specified in input.
        //When unrolling a loop, more slots are generated and the back slots may need to be updated.
        if(front.node_count()>1) front=front->unroll(back);

        //Adding a symbol inside a range may require the update of back slots, 
        //as more slots are generated.
        return front->add(symbol,back);
    }

    template<typename RuleT>
    void parallel_add_range(RuleT* rule,typename RuleT::symbol_t  start,typename RuleT::symbol_t  end,typename RuleT::node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& end_slots) {
        if(!front) front=rule->add_node();
        
        if(front.node_count()>1) front=front->unroll(back);

        front->add_range(start,end,back,end_slots);
    }

    template<typename RuleT>
    void parallel_join(RuleT* rule,typename RuleT::node_p& node1,typename RuleT::node_p& node2,node_slots<RuleT>& back) 
    {
        node_slots<RuleT> source_end;    
        detail::boolean_union<RuleT> uniter(rule,back,source_end,false);
        node_slots<RuleT> dest_slots;
        dest_slots.insert(node1);
        uniter.join(dest_slots,node2);
    }
    template<typename RuleT>
    void parallel_join(RuleT* rule,typename RuleT::node_p& node1,typename RuleT::node_p& node2,node_slots<RuleT>& dest_end,node_slots<RuleT>& source_end) 
    {
        detail::boolean_union<RuleT> uniter(rule,dest_end,source_end,false);
        node_slots<RuleT> dest_slots;
        dest_slots.insert(node1);
        uniter.join(dest_slots,node2);
    }
/*

        if(back.has_reference(node2)) back.insert(node1);
        //If node1 is empty, replace it with node2.
        if(!node1) {
            node1=node2;
        }
        //Else, merge node1 and node2.
        else if(node2) {
            //We need to unroll node2, use unrolled node as basis.
            if(node2.node_count()>1) {
                //We also need to unroll node1
                if(node1.node_count()>1) {
                    node1=node1->unroll(back);
                }
                node2=unroll_and_join(node2,back,node)
                node2=node2->unroll_and_join(node1,back);
            }
        }
*/
}}}

#endif