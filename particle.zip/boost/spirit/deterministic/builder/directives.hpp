#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_DIRECTIVES_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_DIRECTIVES_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/primitives.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename ParserT,typename SpaceP>
    void build_expression(RuleT* rule,contiguous<ParserT> const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
        build_expression(rule,p.subject(),space,front,back);
    }

}}}

#endif