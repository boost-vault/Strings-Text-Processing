#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_KLEENE_STAR_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_KLEENE_STAR_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/parallel.hpp>
#include <boost/spirit/deterministic/builder/serial.hpp>
#include <boost/spirit/deterministic/builder/common.hpp>
#include <boost/spirit/deterministic/builder/unary_builder.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename A,typename SpaceP>
    void build_expression(RuleT* rule,kleene_star<A> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {		
        //Front and back are empty
		typedef typename RuleT::node_p node_p; 
        //First build a closed loop
        node_slots<RuleT> exclude;
        build_expression(rule,p.subject(),space,front,back,exclude);
        kleene_star_builder<RuleT>::apply(rule,front,back,exclude);
    }

    template<typename RuleT>
    struct kleene_star_builder : public unary_builder<RuleT,kleene_star_builder<RuleT> >{
        typedef unary_builder<RuleT,kleene_star_builder<RuleT> > base_t;
        typedef kleene_star_builder<RuleT> self_t;

        kleene_star_builder(builder_p& subject) : base_t(subject) {}
        virtual ~kleene_star_builder() {}

        //Execute the actual alternative, or create a builder action (postpone until all rule creation is complete)
        static void apply(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& exclude) {
            if(!is_builder(front)) {
                //Then join it with itself
                back.insert(front);
                serial_join(rule,back,front,back,back,exclude);
            }
            else {
                front=create_unary_builder(front,back);
                back.clear();
            }
        }
    };
}}}

#endif