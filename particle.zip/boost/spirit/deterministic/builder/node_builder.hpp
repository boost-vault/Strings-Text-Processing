#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_NODE_BUILDER_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_NODE_BUILDER_HPP

namespace boost { namespace spirit { namespace deterministic {
    template<typename RuleT>
    struct node_builder : public builder<RuleT> {
        node_builder(node_p& front_,node_slots<RuleT>& back_) : front(front_),back(back_)
        {
           if(back.erase(front_)) back.insert(front);
        }
        virtual void expand(RuleT* rule,node_p& front_,node_slots<RuleT>& back_,expand_mode mode) {
            switch(mode) {
                case transfer_mode:
                case readonly_mode:
                    {
                        front_=front;
                        back_=back;
                        if(back_.erase(front)) back_.insert(front_);
                        front=node_p();
                        break;
                    }
                case copy_mode:
                    {
                        treated_node_map treaded_nodes;
                        copy_recursive(rule,front,back,front_,back_,treaded_nodes);
                        break;
                    }
            }
        }
        node_p front;
        node_slots<RuleT> back;
    };
}}}
#endif