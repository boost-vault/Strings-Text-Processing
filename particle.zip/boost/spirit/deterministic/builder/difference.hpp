#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_DIFFERENCE_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_DIFFERENCE_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/detail/boolean.hpp>
#include <boost/spirit/deterministic/builder/binary_builder.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename A,typename B,typename SpaceP>
    void build_expression(RuleT* rule,difference<A,B> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& exclude)
    {
        //Front and back are empty
		typedef typename RuleT::node_p node_p; 
        node_p diff_front;
        node_slots<RuleT> diff_back;
        build_expression(rule,p.left(),space,front,back);
        build_expression(rule,p.right(),space,diff_front,diff_back);
        difference_builder<RuleT>::apply(rule,front,back,diff_front,diff_back,exclude);
    }

    template<typename RuleT,typename A,typename B,typename SpaceP>
    void build_expression(RuleT* rule,difference<A,B> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        node_slots<RuleT> exclude;
        build_expression(rule,p,space,front,back,exclude);
    }

    template<typename RuleT>
    struct difference_builder : public binary_builder<RuleT,difference_builder<RuleT> >{
        typedef binary_builder<RuleT,difference_builder<RuleT> > base_t;
        typedef difference_builder<RuleT> self_t;

        difference_builder(builder_p& left,builder_p& right) : base_t(left,right) {}
        virtual ~difference_builder() {}

        //Execute the actual alternative, or create a builder action (postpone until all rule creation is complete)
        static void apply(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_p& diff_front,node_slots<RuleT>& diff_back,node_slots<RuleT>& exclude) {
            if(!is_builder(front) && !is_builder(diff_front)) {
                detail::boolean_operation<RuleT> subtract(rule,back,diff_back,detail::NONREG_SUBTRACTION);
                subtract.set_exclude(exclude);
                subtract.execute(front,diff_front);
            }
            else {
                front=create_binary_builder(front,back,diff_front,diff_back);
                back.clear();
            }
        }
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,expand_mode mode) {
            node_slots<RuleT> exclude;
            expand(rule,front,back,exclude,mode);
        }
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& exclude,expand_mode mode) {
            node_p diff_front;
            node_slots<RuleT> diff_back;
            left()->expand(rule,front,back,(mode==readonly_mode)?copy_mode:mode);
            right()->expand(rule,diff_front,diff_back,(mode==copy_mode)?readonly_mode:mode);
            apply(rule,front,back,diff_front,diff_back,exclude);
        }
    };

}}}

#endif