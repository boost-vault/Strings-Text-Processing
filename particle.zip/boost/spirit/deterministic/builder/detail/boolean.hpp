#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_DETAIL_BOOLEAN_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_DETAIL_BOOLEAN_HPP

#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/foreach.hpp>
#include <map>



namespace boost { namespace spirit { namespace deterministic { namespace detail {
    enum boolean_type {
        NONREG_UNION,
        UNION,
        NONREG_SUBTRACTION
    };

    //Support for regularised and nonregularised union
    template<typename RuleT>
    class boolean_operation {
    public:
        typedef typename node_slots<RuleT>::node_p node_p;
        typedef typename node_slots<RuleT>::node_t node_t;
        typedef std::pair<typename RuleT::symbol_t,typename RuleT::symbol_t> range_pair;
        typedef typename node_t::range_iterator range_iterator;
        typedef typename node_t::const_range_iterator const_range_iterator;
        template<typename T>
        struct less_ptr : std::binary_function<const T*,const T*,bool> {
            bool operator()(const T* lhs,const T* rhs) const {
                return *lhs<*rhs;
            }
        };
        typedef std::map<node_p*,node_slots<RuleT> > source_dest_map;

        /**
        dest_end:
        Represents the end nodes for dest_begin. 
        If a path in Source start leads to a node in dest_end, ignore this path.
        source_end:
        This is the end nodes for the start. Not necessarily present.
        regularised:
        true corresponds to serial join. Only give unique paths in source a footprint in dest.
        false corresponds to parallel join. Force source to have a footprint in dest.
        */
        boolean_operation(RuleT* owner_,node_slots<RuleT>& dest_end,node_slots<RuleT>& source_end,boolean_type bool_type_);
        /**
        dest_begin: 
        these are the original nodes, which we want to join something to.
        We need to isolate all equal nodes and handle these separately.
        source_begin:
        this is the node that we want to join to the original nodes.
        */
        void execute(node_p& dest_begin,node_p& source_begin);
        void execute(node_slots<RuleT>& dest_begin,node_p& source_begin);
        void execute(source_dest_map& dest_begin);
        void execute(source_dest_map& source_dest,source_dest_map& child_source_dest);
        node_p treat_node(node_p& dest,node_p& source,bool need_new_node,source_dest_map& children);
        size_t single_node_looping_count(node_p& dest_begin,node_p& source_begin);

        void set_exclude(node_slots<RuleT>& exclude_) {
            exclude=&exclude_;
        }
        bool is_excluded(node_p& node) {
            if(!exclude) return false;
            return exclude->has_reference(node);
        }
        bool is_relevant(node_p& dest,node_p& source) const;
        bool is_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const;
        bool children_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const;
        void add_range(node_p& new_dest,node_p& dest,bool need_new_node,range_pair& source_range);
        void operator()(const_range_iterator& old_it,range_iterator& new_it) {
            if(dest_end.has_reference(old_it)) {
                dest_end.insert(new_it);
            }
            if(exclude) {
                if(exclude->has_reference(old_it)) exclude->insert(new_it);
            }
            BOOST_FOREACH(node_slots<RuleT>* slot,slots) {
                if(slot->has_reference(old_it)) slot->insert(new_it);
            }
        }
        void operator()(const node_p& old_it,const node_p& new_it) {
            if(dest_end.has_reference(old_it)) {
                dest_end.insert(new_it);
            }
            if(exclude) {
                if(exclude->has_reference(old_it)) exclude->insert(new_it);
            }
            BOOST_FOREACH(node_slots<RuleT>* slot,slots) {
                if(slot->has_reference(old_it)) slot->insert(new_it);
            }
        }
        void add_slots(node_slots<RuleT>* slot) {slots.insert(slot);}
        void remove_slots(node_slots<RuleT>* slot) {slots.erase(slot);}
        struct register_slot {
            register_slot(boolean_operation<RuleT>* owner_,node_slots<RuleT>& slot_) : owner(owner_),slot(slot_) {
                owner->add_slots(&slot);
            }
            ~register_slot() {
                owner->remove_slots(&slot);
            }
            node_slots<RuleT>& slot;
            boolean_operation<RuleT>* owner;
        };
    private:
        node_slots<RuleT>& dest_end;
        node_slots<RuleT>& source_end;
        node_slots<RuleT>* exclude;
        typedef std::map<std::pair<node_t*,node_t*>,node_p> NodeMap;
        NodeMap treated_nodes;
        RuleT* owner;
        boolean_type bool_type;
        std::set<node_slots<RuleT>*> slots;
    };

    template<typename RuleT>
    boolean_operation<RuleT>::boolean_operation(RuleT* owner_,node_slots<RuleT>& dest_end_,node_slots<RuleT>& source_end_,boolean_type bool_type_)
        :   dest_end(dest_end_)
        ,   source_end(source_end_)
        ,   bool_type(bool_type_)
        ,   exclude(0)
        ,   owner(owner_)
    {
    }

    template<typename RuleT>
    bool boolean_operation<RuleT>::is_relevant(node_p& dest,node_p& source) const
    {
        //Force source to have a footprint in dest.
        if(bool_type==NONREG_UNION) {
            std::set<std::pair<node_t*,node_t*> > traversed;
            return is_relevant(dest,source,traversed);
        }
        else return true;
    }

    template<typename RuleT>
    bool boolean_operation<RuleT>::is_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const
    {
        //If dest represents an end node, source can never be interesting
        if(dest_end.has_reference(dest)) return false;
        else if(!dest) return true;
        else if(!source) return false;
        //No need joining with self
        if(dest==source) return false;
        //If we are looping, don't consider this node.
        if(!traversed.insert(std::make_pair(dest.get(),source.get())).second) return false;
        //Traverse node hierarchical.
        else return children_relevant(dest,source,traversed);
    }

    template<typename RuleT>
    bool boolean_operation<RuleT>::children_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const
    {
        //For all nodes in source, check if a parallel exists in dest.
        range_iterator isource=source->get_ranges().begin();
        while(isource!=source->get_ranges().end()) {
            range_iterator it=isource++;
            //For each child node in source, check if it constitutes a unique path not
            //described by dest.
            node_p& source_child=it->second;
            //If source_child is empty, this path is already excluded.

            //Locate source's range in dest.
            range_pair range=source->get_ranges().get_range(it);
            range_iterator ifirst=dest->get_ranges().find(range.first);
            range_iterator isecond=dest->get_ranges().find(range.second);
            if(ifirst==dest->get_ranges().end() || isecond==dest->get_ranges().end()) return true;
            ++isecond;
            for(range_iterator idest=ifirst;idest!=isecond;++idest) {
                if(is_relevant(idest->second,source_child,traversed)) return true;
            }
        }
        return false;
    }

    template<typename RuleT>
    size_t boolean_operation<RuleT>::single_node_looping_count(node_p& dest_begin,node_p& source_begin)
    {
        size_t count=0;
        if(!dest_begin || !source_begin) return count;
        for(range_iterator isource=source_begin->get_ranges().begin();isource!=source_begin->get_ranges().end();++isource) {
            //Check if we have a looping node in source
            if(isource->second==source_begin) {
                //Identify if we have the same looping in source
                range_iterator idest=dest_begin->get_ranges().find(isource->first);
                if(idest!=dest_begin->get_ranges().end()) {
                    //We have a looping construct. Does it span the same range?
                    if(idest->second==dest_begin) {
                        range_pair dest_range=dest_begin->get_ranges().get_range(idest);
                        range_pair source_range=source_begin->get_ranges().get_range(isource);
                        //Yes. Include the loop in count.
                        if(dest_range==source_range) ++count;
                    }
                }
            }
        }
        return count;
    }

    template<typename RuleT>
    void boolean_operation<RuleT>::execute(source_dest_map& source_dest,source_dest_map& child_source_dest)
    {   
        //Important to recurse one node level at a time, as source may actually be constructed while building dest
        //This happens e.g. when building a looping construct.
        while(source_dest.size()>0) {
            typename source_dest_map::iterator it=source_dest.begin();
            if(!it->first) {
                source_dest.erase(it);
                continue;
            }
            node_p& source_begin=*it->first;
            node_slots<RuleT> dest_begin;
            register_slot slots(this,dest_begin);
            bool is_end_node=false;
            if(bool_type==NONREG_SUBTRACTION) {              
                is_end_node=source_end.has_reference(source_begin);
                if(!source_begin && is_end_node) {
                    dest_begin.join(it->second);
                    source_dest.erase(it);
                }
                else if(!source_begin) {
                    source_dest.erase(it);
                }
                else {
                    while(it!=source_dest.end()) {
                        if(*it->first==source_begin && source_end.has_reference(*it->first)==is_end_node) {
                            dest_begin.join(it->second);
                            source_dest.erase(it++);
                        }
                        else ++it;
                    }
                }
            }
            else {
                //Ignore empty source
                if(!source_begin) {
                    source_dest.erase(&source_begin);
                    continue;
                }
                while(it!=source_dest.end()) {
                    if(*it->first==source_begin) {
                        dest_begin.join(it->second);
                        source_dest.erase(it++);
                    }
                    else ++it;
                }
            }
            //We have now collected all the dest_nodes that are required by source.
            std::set<node_t*> used_nodes;
            BOOST_FOREACH(node_p* node,dest_begin) {
                //Invalid node.
                if(!node) continue;
                if(is_excluded(*node)) continue;
                //If *node is null, use source_begin directly.
                if(!*node) {
                    if(dest_end.has_reference(source_begin)) dest_end.insert(*node);
                    if(bool_type==NONREG_SUBTRACTION) {
                        if(is_end_node) {
                            exclude->insert(*node);
                            dest_end.erase(*node);
                        }
                        if(source_begin) *node=owner->add_node();
                        else continue;
                    }
                    else {
                        *node=source_begin;
                        continue;
                    }
                }                
                //Check if this node has already been processed.
                if(*node && !used_nodes.insert(node->get()).second) continue;
                size_t count=0;
                if(*node && source_begin) count=dest_begin.count(*node);
                //Optimization for single node looping.
                if(*node && source_begin) count+=single_node_looping_count(*node,source_begin);
                //Join children if any are relevant.
                node_p joined_node=treat_node(*node,source_begin,count!=node->node_count(),child_source_dest);
                if(joined_node && joined_node!=*node) {
                    //Replace all occurrences of this node in dest_begin with the copy.
                    node_p original_node=*node;
                    BOOST_FOREACH(node_p* dest_node,dest_begin) {
                        if(*dest_node==original_node) *dest_node=joined_node;
                        if(dest_end.has_reference(joined_node)) dest_end.insert(*dest_node);
                    }
                    //Insert this node in used_nodes.
                    used_nodes.insert(joined_node.get());
                }
                if(bool_type==NONREG_SUBTRACTION && is_end_node) {
                    BOOST_FOREACH(node_p* dest_node,dest_begin) {
                        dest_end.erase(*dest_node);
                    }
                }
            }
        }
    }

    template<typename RuleT>
    void boolean_operation<RuleT>::execute(source_dest_map& source_dest)
    {
        if(bool_type==UNION) dest_end.join(source_end);
        while(source_dest.size()>0) {
            source_dest_map childmap;
            execute(source_dest,childmap);
            std::swap(source_dest,childmap);
        }        
    }

    template<typename RuleT>
    void boolean_operation<RuleT>::execute(node_slots<RuleT>& dest_begin,node_p& source_begin)
    {
        source_dest_map source_dest;
        source_dest[&source_begin]=dest_begin;
        execute(source_dest);
    }

    template<typename RuleT>
    void boolean_operation<RuleT>::execute(node_p& dest_begin,node_p& source_begin)
    {
        source_dest_map source_dest;
        source_dest[&source_begin].insert(dest_begin);
        execute(source_dest);
    }


    template<typename RuleT>
    void boolean_operation<RuleT>::add_range(node_p& new_dest,node_p& dest,bool need_new_node,range_pair& source_range)
    {
        if(!new_dest) {
            if(need_new_node) new_dest=dest->unroll(owner,*this);
            else new_dest=dest;
        }
        node_slots<RuleT> end_slots;
        //Add subset range to new_dest.
        new_dest->add_range(
            source_range.first,
            source_range.second,
            dest_end,
            end_slots
            );
    }

    template<typename RuleT>
    typename RuleT::node_p boolean_operation<RuleT>::treat_node(node_p& dest,node_p& source,bool need_new_node,source_dest_map& source_dest)
    {
        if(!source) {
            if(need_new_node) return dest->unroll(owner,*this);
            else return dest;
        }
        //Check if this node pair has been treated already.
        //This is the general node looping utility. It will only do the trick if dest/source looping is of the same length.
        node_p& new_dest=treated_nodes[make_pair(dest.get(),source.get())];
        if(new_dest) return new_dest;

        if(dest==source) {
            if(need_new_node) new_dest=dest->unroll(owner,*this);
            else new_dest=dest;
            return new_dest;
        }
        if(bool_type==NONREG_SUBTRACTION) {
            if(source_end.has_reference(source)) {
                //Subtract dest from the complete set
                if(dest_end.has_reference(dest)) dest_end.erase(dest);
                //We need special handling of *(anychar_p - "*/");
                //The subtraction will not have full effect until we expand the loop.
                else if(!dest) exclude->insert(dest);
            }
        }
        //For all ranges in source
        range_iterator isource=source->get_ranges().begin();
        while(isource!=source->get_ranges().end()) {
            range_iterator it=isource++;
            node_p& source_child=it->second;
            if(bool_type==NONREG_SUBTRACTION) {
                if(!source_child && !source_end.has_reference(source_child)) continue;
            }

            //Find corresponding ranges in dest, and check if they are relevant.
            range_pair source_range=source->get_ranges().get_range(it);
            range_iterator ifirst=dest->get_ranges().find(source_range.first);
            range_iterator isecond=dest->get_ranges().find(source_range.second);
            //Special handling if inserting something in the front.
            if(ifirst==dest->get_ranges().end() && isecond==dest->get_ranges().end()) {
                add_range(new_dest,dest,need_new_node,source_range);
                //Postpone creation of the next layer of nodes, may save some node creation.
                range_iterator it=new_dest->get_ranges().find(source_range.first);
                if(dest_end.has_reference(source_child) && !is_excluded(it->second)) dest_end.insert(it);
                source_dest[&source_child].insert(it);
                continue;
            }
            else if(ifirst==dest->get_ranges().end()) {
                range_pair below_range(
                    source_range.first,
                    dest->get_ranges().begin()->first
                    );
                add_range(new_dest,dest,need_new_node,below_range);
                //Postpone creation of the next layer of nodes, may save some node creation.
                range_iterator it=new_dest->get_ranges().find(below_range.first);
                if(dest_end.has_reference(source_child) && !is_excluded(it->second)) dest_end.insert(it);
                source_dest[&source_child].insert(it);
                //Prepare next range
                ifirst=dest->get_ranges().begin();
            }
            ++isecond;
            range_iterator idest=ifirst;
            while(idest!=isecond) {
                range_iterator it=idest++;
                node_p& dest_child=it->second;
                //If source_child represents a unique path in dest_child, add this range.
                if(is_relevant(dest_child,source_child)) {
                    //Find the subset between source and dest that is of interest.
                    //Handle single node recursion.
                    range_pair dest_range=dest->get_ranges().get_range(it);
                    range_pair new_range(
                        std::max(source_range.first,dest_range.first),
                        std::min(source_range.second,dest_range.second)
                        );
                    add_range(new_dest,dest,need_new_node,new_range);
                    //Postpone creation of the next layer of nodes, may save some node creation.
                    range_iterator it=new_dest->get_ranges().find(new_range.first);
                    if(dest_end.has_reference(source_child) && !is_excluded(it->second)) dest_end.insert(it);
                    //Handle special case of node looping. If the looping is just one node deep, this should do.
                    if(source_child==source && dest_child==dest && source_range==dest_range) {
                        //We also need to rehook the loop node if new dest has been copied from dest.
                        if(need_new_node) it->second=new_dest;
                    }
                    else {
                        source_dest[&source_child].insert(it);
                    }
                }
            }
        }
        return new_dest;
    }
}}}}

#endif