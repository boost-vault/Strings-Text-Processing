#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_IMPRINT_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_IMPRINT_HPP

#include <boost/spirit/deterministic/node_slots.hpp>

namespace boost { namespace spirit { namespace deterministic { namespace detail {

    template<typename RuleT>
    class boolean_subtract {
    public:
        typedef typename RuleT::node_p node_p;
        typedef typename RuleT::node_t node_t;
        typedef std::pair<typename RuleT::symbol_t,typename RuleT::symbol_t> range_pair;
        typedef typename node_t::range_iterator range_iterator;

        boolean_subtract(RuleT* rule_,node_slots<RuleT>& back_,node_slots<RuleT>& difference_back_,node_slots<RuleT>& exclude_);
        void imprint(node_p& front,node_p& difference_front);
        void add_range(node_p& new_dest,node_p& dest,bool need_new_node,range_pair& source_range);
        void set_builder(node_slots<RuleT>& end_nodes_,node_slots<RuleT>& connect_nodes_) {
            end_nodes=&end_nodes_;
            connect_nodes=&connect_nodes_;
        }
    private:
        node_slots<RuleT>& back;
        node_slots<RuleT>& difference_back;
        node_slots<RuleT>& exclude;
        node_slots<RuleT>* connect_nodes;
        node_slots<RuleT>* end_nodes;
        std::set<node_t*> difference_traversed;
        RuleT* rule;
    };

    template<typename RuleT>
    boolean_subtract<RuleT>::boolean_subtract(RuleT* rule_,node_slots<RuleT>& back_,node_slots<RuleT>& difference_back_,node_slots<RuleT>& exclude_)
        :   back(back_)
        ,   difference_back(difference_back_)
        ,   exclude(exclude_)
        ,   rule(rule_)
        ,   connect_nodes(0)
        ,   end_nodes(0)
    {}

    template<typename RuleT>
    void boolean_subtract<RuleT>::add_range(node_p& new_dest,node_p& dest,bool need_new_node,range_pair& source_range)
    {
        if(!new_dest) {
            if(need_new_node) new_dest=dest->unroll(back);
            else new_dest=dest;
        }
        node_slots<RuleT> end_slots;
        //Add subset range to new_dest.
        new_dest->add_range(
            source_range.first,
            source_range.second,
            back,
            end_slots
            );
    }

    template<typename RuleT>
    void boolean_subtract<RuleT>::imprint(node_p& dest,node_p& source)
    {
        //Prevent infinite recursion.
        if(source.get() && difference_traversed.insert(source.get()).second==false) return;

        //Unroll node if it is used by more than one.
        if(dest.node_count()>1) {
            dest=dest->unroll(back);
        }
        //Check if source is at the end.
        if(difference_back.has_reference(source)) {
            //Subtract dest from the complete set
            if(back.has_reference(dest)) back.erase(dest);
            //We need special handling of *(anychar_p - "*/");
            //The subtraction will not have full effect until we expand the loop.
            else if(!dest) exclude.insert(dest);
        }
        //We're at the end of the difference_line.
        if(!source) return;
        //If dest is exhausted, we need to add more nodes to it.
        if(!dest) dest=rule->add_node();
        bool need_new_node=dest.node_count()>1;
        node_p new_dest;
        //For all ranges in source
        range_iterator isource=source->get_ranges().begin();
        while(isource!=source->get_ranges().end()) {
            range_iterator it=isource++;
            node_p& source_child=it->second;
            if(!source_child && !difference_back.has_reference(source_child)) continue;

            //Find corresponding ranges in dest, and check if they are relevant.
            range_pair source_range=source->get_ranges().get_range(it);
            range_iterator ifirst=dest->get_ranges().find(source_range.first);
            range_iterator isecond=dest->get_ranges().find(source_range.second);
            //Special handling if inserting something in the front.
            if(ifirst==dest->get_ranges().end() && isecond==dest->get_ranges().end()) {
                add_range(new_dest,dest,need_new_node,source_range);
                //Immediate subtraction
                node_p& dest_child=new_dest->get_ranges().find(source_range.first)->second;
                imprint(dest_child,source_child);
                continue;
            }
            else if(ifirst==dest->get_ranges().end()) {
                ifirst=source->get_ranges().begin();
                range_pair below_range(
                    source_range.first,
                    source->get_ranges().prior_symbol(source->get_ranges().begin()->first)
                    );
                add_range(new_dest,dest,need_new_node,below_range);
                //Immediate subtraction
                node_p& dest_child=new_dest->get_ranges().find(source_range.first)->second;
                imprint(dest_child,source_child);
            }
            ++isecond;
            range_iterator idest=ifirst;
            while(idest!=isecond) {
                range_iterator it=idest++;
                //Find the subset between source and dest that is of interest.
                range_pair dest_range=dest->get_ranges().get_range(it);
                range_pair new_range(
                    std::max(source_range.first,dest_range.first),
                    std::min(source_range.second,dest_range.second)
                    );
                add_range(new_dest,dest,need_new_node,new_range);
                //Immediate subtraction
                node_p& dest_child=new_dest->get_ranges().find(source_range.first)->second;
                imprint(dest_child,source_child);
            }
        }
    }

}}}}

#endif