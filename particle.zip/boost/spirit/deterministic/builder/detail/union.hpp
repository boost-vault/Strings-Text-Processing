#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_DETAIL_UNION_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_DETAIL_UNION_HPP

#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/foreach.hpp>
#include <map>



namespace boost { namespace spirit { namespace deterministic { namespace detail {

    //Support for regularised and nonregularised union
    template<typename RuleT>
    class boolean_union {
    public:
        typedef typename node_slots<RuleT>::node_p node_p;
        typedef typename node_slots<RuleT>::node_t node_t;
        typedef std::pair<typename RuleT::symbol_t,typename RuleT::symbol_t> range_pair;
        typedef typename node_t::range_iterator range_iterator;
        typedef typename node_t::const_range_iterator const_range_iterator;
        template<typename T>
        struct less_ptr : std::binary_function<const T*,const T*,bool> {
            bool operator()(const T* lhs,const T* rhs) const {
                return *lhs<*rhs;
            }
        };
        typedef std::map<node_p*,node_slots<RuleT> > source_dest_map;

        /**
        dest_end:
            Represents the end nodes for dest_begin. 
            If a path in Source start leads to a node in dest_end, ignore this path.
        source_end:
            This is the end nodes for the start. Not necessarily present.
        regularised:
            true corresponds to serial join. Only give unique paths in source a footprint in dest.
            false corresponds to parallel join. Force source to have a footprint in dest.
        */
        boolean_union(RuleT* owner_,node_slots<RuleT>& dest_end,node_slots<RuleT>& source_end,bool regularised);
        /**
        dest_begin: 
            these are the original nodes, which we want to join something to.
            We need to isolate all equal nodes and handle these separately.
        source_begin:
            this is the node that we want to join to the original nodes.
        */
        void join(node_slots<RuleT>& dest_begin,node_p& source_begin,bool force_no_copy=false);
        void join(source_dest_map& dest_begin,bool force_no_copy=false);
        void join(source_dest_map& source_dest,source_dest_map& child_source_dest,bool force_no_copy=false);
        node_p join_node(node_p& dest,node_p& source,bool need_new_node,source_dest_map& children);
        size_t single_node_looping_count(node_p& dest_begin,node_p& source_begin);
        
        void set_exclude(node_slots<RuleT>& exclude_) {
            exclude=&exclude_;
        }
        bool is_excluded(node_p& node) {
            if(!exclude) return false;
            return exclude->has_reference(node);
        }
        bool is_relevant(node_p& dest,node_p& source) const;
        bool is_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const;
        bool children_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const;
        void add_range(node_p& new_dest,node_p& dest,bool need_new_node,range_pair& source_range);
        void operator()(const_range_iterator& old_it,range_iterator& new_it) {
            if(dest_end.has_reference(old_it)) {
                dest_end.insert(new_it);
            }
            if(exclude) {
                if(exclude->has_reference(old_it)) exclude->insert(new_it);
            }
            BOOST_FOREACH(node_slots<RuleT>* slot,slots) {
                if(slot->has_reference(old_it)) slot->insert(new_it);
            }
        }
        void operator()(const node_p& old_it,const node_p& new_it) {
            if(dest_end.has_reference(old_it)) {
                dest_end.insert(new_it);
            }
            if(exclude) {
                if(exclude->has_reference(old_it)) exclude->insert(new_it);
            }
            BOOST_FOREACH(node_slots<RuleT>* slot,slots) {
                if(slot->has_reference(old_it)) slot->insert(new_it);
            }
        }
        void add_slots(node_slots<RuleT>* slot) {slots.insert(slot);}
        void remove_slots(node_slots<RuleT>* slot) {slots.erase(slot);}
        struct register_slot {
            register_slot(boolean_union<RuleT>* owner_,node_slots<RuleT>& slot_) : owner(owner_),slot(slot_) {
                owner->add_slots(&slot);
            }
            ~register_slot() {
                owner->remove_slots(&slot);
            }
            node_slots<RuleT>& slot;
            boolean_union<RuleT>* owner;
        };
    private:
        node_slots<RuleT>& dest_end;
        node_slots<RuleT>& source_end;
        node_slots<RuleT>* exclude;
        typedef std::map<std::pair<node_t*,node_t*>,node_p> NodeMap;
        NodeMap treated_nodes;
        RuleT* owner;
        bool m_regularised;
        std::set<node_slots<RuleT>*> slots;
    };

    template<typename RuleT>
    boolean_union<RuleT>::boolean_union(RuleT* owner_,node_slots<RuleT>& dest_end_,node_slots<RuleT>& source_end_,bool regularised)
        :   dest_end(dest_end_)
        ,   source_end(source_end_)
        ,   m_regularised(regularised)
        ,   exclude(0)
        ,   owner(owner_)
    {
    }

    template<typename RuleT>
    bool boolean_union<RuleT>::is_relevant(node_p& dest,node_p& source) const
    {
        //Force source to have a footprint in dest.
        if(!m_regularised) return true;
        std::set<std::pair<node_t*,node_t*> > traversed;
        return is_relevant(dest,source,traversed);
    }

    template<typename RuleT>
    bool boolean_union<RuleT>::is_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const
    {
        //If dest represents an end node, source can never be interesting
        if(dest_end.has_reference(dest)) return false;
        else if(!dest) return true;
        else if(!source) return false;
        //No need joining with self
        if(dest==source) return false;
        //If we are looping, don't consider this node.
        if(!traversed.insert(std::make_pair(dest.get(),source.get())).second) return false;
        //Traverse node hierarchical.
        else return children_relevant(dest,source,traversed);
    }

    template<typename RuleT>
    bool boolean_union<RuleT>::children_relevant(node_p& dest,node_p& source,std::set<std::pair<node_t*,node_t*> >& traversed) const
    {
        //For all nodes in source, check if a parallel exists in dest.
        range_iterator isource=source->get_ranges().begin();
        while(isource!=source->get_ranges().end()) {
            range_iterator it=isource++;
            //For each child node in source, check if it constitutes a unique path not
            //described by dest.
            node_p& source_child=it->second;
            //If source_child is empty, this path is already excluded.

            //Locate source's range in dest.
            range_pair range=source->get_ranges().get_range(it);
            range_iterator ifirst=dest->get_ranges().find(range.first);
            range_iterator isecond=dest->get_ranges().find(range.second);
            if(ifirst==dest->get_ranges().end() || isecond==dest->get_ranges().end()) return true;
            ++isecond;
            for(range_iterator idest=ifirst;idest!=isecond;++idest) {
                if(is_relevant(idest->second,source_child,traversed)) return true;
            }
        }
        return false;
    }

    template<typename RuleT>
    size_t boolean_union<RuleT>::single_node_looping_count(node_p& dest_begin,node_p& source_begin)
    {
        size_t count=0;
        if(!dest_begin || !source_begin) return count;
        for(range_iterator isource=source_begin->get_ranges().begin();isource!=source_begin->get_ranges().end();++isource) {
            //Check if we have a looping node in source
            if(isource->second==source_begin) {
                //Identify if we have the same looping in source
                range_iterator idest=dest_begin->get_ranges().find(isource->first);
                if(idest!=dest_begin->get_ranges().end()) {
                    //We have a looping construct. Does it span the same range?
                    if(idest->second==dest_begin) {
                        range_pair dest_range=dest_begin->get_ranges().get_range(idest);
                        range_pair source_range=source_begin->get_ranges().get_range(isource);
                        //Yes. Include the loop in count.
                        if(dest_range==source_range) ++count;
                    }
                }
            }
        }
        return count;
    }

    template<typename RuleT>
    void boolean_union<RuleT>::join(source_dest_map& source_dest,source_dest_map& child_source_dest,bool force_no_copy)
    {   
        node_p empty_source;
        //Important to recurse one node level at a time, as source may actually be constructed while building dest
        //This happens e.g. when building a looping construct.
        while(source_dest.size()>0) {
            typename source_dest_map::iterator it=source_dest.begin();            
            node_p& source_begin=(it->first)?*it->first:empty_source;
            //Ignore empty source when we are not expanding a builder
            if(!source_begin) {
                source_dest.erase(&source_begin);
                continue;
            }
            node_slots<RuleT> dest_begin;
            register_slot slots(this,dest_begin);
            while(it!=source_dest.end()) {
                if(!it->first && empty_source==source_begin) {
                    dest_begin.join(it->second);
                    source_dest.erase(it++);
                }
                else if(it->first && *it->first==source_begin) {
                    dest_begin.join(it->second);
                    source_dest.erase(it++);
                }
                else ++it;
            }
            //We have now collected all the dest_nodes that are required by source.
            std::set<node_t*> used_nodes;
            BOOST_FOREACH(node_p* node,dest_begin) {
                //Invalid node.
                if(!node) continue;
                if(is_excluded(*node)) continue;
                //If *node is null, use source_begin directly.
                if(!*node) {
                    *node=source_begin;
                    if(dest_end.has_reference(source_begin)) dest_end.insert(*node);
                    continue;
                }                
                //Check if this node has already been processed.
                if(!used_nodes.insert(node->get()).second) continue;
                size_t count=dest_begin.count(*node);
                //Optimization for single node looping.
                count+=single_node_looping_count(*node,source_begin);
                //Join children if any are relevant.
                if(force_no_copy) count=node->node_count();
                node_p joined_node=join_node(*node,source_begin,count!=node->node_count(),child_source_dest);
                if(joined_node && joined_node!=*node) {
                    //Replace all occurrences of this node in dest_begin with the copy.
                    node_p original_node=*node;
                    BOOST_FOREACH(node_p* dest_node,dest_begin) {
                        if(*dest_node==original_node) *dest_node=joined_node;
                        if(dest_end.has_reference(joined_node)) dest_end.insert(*dest_node);
                    }
                    //Insert this node in used_nodes.
                    used_nodes.insert(joined_node.get());
                }
            }
        }
    }

    template<typename RuleT>
    void boolean_union<RuleT>::join(source_dest_map& source_dest,bool force_no_copy)
    {
        if(!m_regularised) dest_end.join(source_end);
        while(source_dest.size()>0) {
            source_dest_map childmap;
            join(source_dest,childmap,force_no_copy);
            std::swap(source_dest,childmap);
        }        
    }

    template<typename RuleT>
    void boolean_union<RuleT>::join(node_slots<RuleT>& dest_begin,node_p& source_begin,bool force_no_copy)
    {
        source_dest_map source_dest;
        source_dest[&source_begin]=dest_begin;
        join(source_dest,force_no_copy);
    }

    template<typename RuleT>
    void boolean_union<RuleT>::add_range(node_p& new_dest,node_p& dest,bool need_new_node,range_pair& source_range)
    {
        if(!new_dest) {
            if(need_new_node) new_dest=dest->unroll(owner,*this);
            else new_dest=dest;
        }
        node_slots<RuleT> end_slots;
        //Add subset range to new_dest.
        new_dest->add_range(
            source_range.first,
            source_range.second,
            dest_end,
            end_slots
        );
    }

    template<typename RuleT>
    typename RuleT::node_p boolean_union<RuleT>::join_node(node_p& dest,node_p& source,bool need_new_node,source_dest_map& source_dest)
    {
        //Check if this node pair has been treated already.
        //This is the general node looping utility. It will only do the trick if dest/source looping is of the same length.
        node_p& new_dest=treated_nodes[make_pair(dest.get(),source.get())];
        if(new_dest) return new_dest;

        if(dest==source) {
            if(need_new_node) new_dest=dest->unroll(owner,*this);
            else new_dest=dest;
            return new_dest;
        }

        //For all ranges in source
        range_iterator isource=source->get_ranges().begin();
        while(isource!=source->get_ranges().end()) {
            range_iterator it=isource++;
            node_p& source_child=it->second;

            //Find corresponding ranges in dest, and check if they are relevant.
            range_pair source_range=source->get_ranges().get_range(it);
            range_iterator ifirst=dest->get_ranges().find(source_range.first);
            range_iterator isecond=dest->get_ranges().find(source_range.second);
            //Special handling if inserting something in the front.
            if(ifirst==dest->get_ranges().end() && isecond==dest->get_ranges().end()) {
                add_range(new_dest,dest,need_new_node,source_range);
                //Postpone creation of the next layer of nodes, may save some node creation.
                range_iterator it=new_dest->get_ranges().find(source_range.first);
                if(dest_end.has_reference(source_child) && !is_excluded(it->second)) dest_end.insert(it);
                else if(!m_regularised && source_end.has_reference(source_child)) dest_end.insert(it);
                source_dest[&source_child].insert(it);
                continue;
            }
            else if(ifirst==dest->get_ranges().end()) {
                range_pair below_range(
                    source_range.first,
                    dest->get_ranges().begin()->first
                );
                add_range(new_dest,dest,need_new_node,below_range);
                //Postpone creation of the next layer of nodes, may save some node creation.
                range_iterator it=new_dest->get_ranges().find(below_range.first);
                if(dest_end.has_reference(source_child) && !is_excluded(it->second)) dest_end.insert(it);
                source_dest[&source_child].insert(it);
                //Prepare next range
                ifirst=dest->get_ranges().begin();
            }
            ++isecond;
            range_iterator idest=ifirst;
            while(idest!=isecond) {
                range_iterator it=idest++;
                node_p& dest_child=it->second;
                //If source_child represents a unique path in dest_child, add this range.
                if(is_relevant(dest_child,source_child)) {
                    //Find the subset between source and dest that is of interest.
                    //Handle single node recursion.
                    range_pair dest_range=dest->get_ranges().get_range(it);
                    range_pair new_range(
                        std::max(source_range.first,dest_range.first),
                        std::min(source_range.second,dest_range.second)
                        );
                    add_range(new_dest,dest,need_new_node,new_range);
                    //Postpone creation of the next layer of nodes, may save some node creation.
                    range_iterator it=new_dest->get_ranges().find(new_range.first);
                    if(dest_end.has_reference(source_child) && !is_excluded(it->second)) dest_end.insert(it);
                    //Handle special case of node looping. If the looping is just one node deep, this should do.
                    if(source_child==source && dest_child==dest && source_range==dest_range) {
                        //We also need to rehook the loop node if new dest has been copied from dest.
                        if(need_new_node) it->second=new_dest;
                    }
                    else {
                        source_dest[&source_child].insert(it);
                    }
                }
            }
        }
        return new_dest;
    }
}}}}

#endif