#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_PRIMITIVES_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_PRIMITIVES_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/parallel.hpp>
#include <boost/spirit/deterministic/builder/kleene_star.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename ParserT,typename SpaceP>
    bool build_primitive_space(RuleT* rule,const ParserT& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        build_expression(rule,*space>>p,epsilon_p,front,back);
        return true;
    }
    template<typename RuleT,typename ParserT>
    bool build_primitive_space(RuleT* rule,const ParserT& p,const epsilon_parser& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        return false;
    }

    template<typename RuleT,typename IteratorT,typename SpaceP>
	void build_expression(RuleT* rule,strlit<IteratorT> const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
        //Empty sequence not allowed
        if(p.seq.first==p.seq.last) return;
        IteratorT ch=p.seq.first;
        IteratorT last=p.seq.last;
        typename RuleT::node_p* inode=&front;
        for(IteratorT ch=p.seq.first;ch!=p.seq.last;++ch) {
            inode=&parallel_add(rule,*ch,*inode,back);
        }
        back.insert(*inode);        
    }

    template<typename RuleT,typename CharT,typename SpaceP>
    void build_expression(RuleT* rule,chlit<CharT> const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
        back.insert(parallel_add(rule,p.ch,front,back));
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,alpha_parser const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        parallel_add_range(rule,'a','z',front,back,back);
        parallel_add_range(rule,'A','Z',front,back,back);
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,digit_parser const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        parallel_add_range(rule,'0','9',front,back,back);
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,xdigit_parser const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        parallel_add_range(rule,'0','9',front,back,back);
        parallel_add_range(rule,'a','f',front,back,back);
        parallel_add_range(rule,'A','F',front,back,back);
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,alnum_parser const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        parallel_add_range(rule,'a','z',front,back,back);
        parallel_add_range(rule,'A','Z',front,back,back);
        parallel_add_range(rule,'0','9',front,back,back);
    }

    template<typename RuleT,typename CharT,typename SpaceP>
    void build_expression(RuleT* rule,range<CharT> const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        parallel_add_range(rule,p.first,p.last,front,back,back);
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,space_parser const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        back.insert(parallel_add(rule,' ',front,back));
        parallel_add_range(rule,'\t','\r',front,back,back);
        //back.insert(parallel_add(rule,'\t',front,back));//0x09
        //back.insert(parallel_add(rule,'\n',front,back));//0x10
        //back.insert(parallel_add(rule,'\v',front,back));//0x11
        //back.insert(parallel_add(rule,'\f',front,back));//0x12
        //back.insert(parallel_add(rule,'\r',front,back));//0x13
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,anychar_parser const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        parallel_add_range(rule,-128,127,front,back,back);
    }

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,eol_parser const& p,typename SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back) {
        if(build_primitive_space(rule,p,space,front,back)) return;
        build_expression(rule,str_p("\r\n") | '\r' | '\n',space,front,back);
    }

}}}

#endif