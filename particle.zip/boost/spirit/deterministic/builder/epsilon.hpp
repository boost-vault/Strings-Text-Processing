#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_EPSILON_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_EPSILON_HPP

#include <boost/spirit/core.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,epsilon_parser const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        back.insert(front);
    }

}}}

#endif