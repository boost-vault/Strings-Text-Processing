#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_OPTIONAL_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_OPTIONAL_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/parallel.hpp>
#include <boost/spirit/deterministic/builder/serial.hpp>
#include <boost/spirit/deterministic/builder/unary_builder.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename A,typename SpaceP>
    void build_expression(RuleT* rule,optional<A> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        node_slots<RuleT> exclude;
        build_expression(rule,p.subject(),space,front,back);
        optional_builder<RuleT>::apply(rule,front,back,exclude);
    }

    template<typename RuleT>
    struct optional_builder : public unary_builder<RuleT,optional_builder<RuleT> >{
        typedef unary_builder<RuleT,optional_builder<RuleT> > base_t;
        typedef optional_builder<RuleT> self_t;

        optional_builder(builder_p& subject) : base_t(subject) {}
        virtual ~optional_builder() {}

        //Execute the actual alternative, or create a builder action (postpone until all rule creation is complete)
        static void apply(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& exclude) {
            if(!is_builder(front)) {
                //Then join it with itself
                back.insert(front);
            }
            else {
                front=create_unary_builder(front,back);
                back.clear();
            }
        }
    };
}}}

#endif