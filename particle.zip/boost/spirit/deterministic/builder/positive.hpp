#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_POSITIVE_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_POSITIVE_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/parallel.hpp>
#include <boost/spirit/deterministic/builder/kleene_star.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename A,typename SpaceP>
    void build_expression(RuleT* rule,positive<A> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        typedef typename RuleT::node_p node_p; 
        //First build a closed loop
        node_slots<RuleT> exclude;
        build_expression(rule,p.subject(),space,front,back,exclude);
        positive_builder<RuleT>::apply(rule,front,back,exclude);
    }
    template<typename RuleT>
    struct positive_builder : public unary_builder<RuleT,positive_builder<RuleT> >{
        typedef unary_builder<RuleT,positive_builder<RuleT> > base_t;
        typedef positive_builder<RuleT> self_t;

        positive_builder(builder_p& subject) : base_t(subject) {}
        virtual ~positive_builder() {}

        //Execute the actual alternative, or create a builder action (postpone until all rule creation is complete)
        static void apply(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& exclude) {
            if(!is_builder(front)) {
                //Need to add an extra node to serve as the first node.
                node_p new_front=front->unroll(back);

                //Temporary object. Remove before exiting function
                back.insert(front);
                serial_join(rule,back,front,back,back,exclude);

                //Removing temporary object
                front=new_front;
                back.erase(front);
            }
            else {
                front=create_unary_builder(front,back);
                back.clear();
            }
        }
    };
}}}

#endif