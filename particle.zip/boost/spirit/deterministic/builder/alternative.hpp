#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_ALTERNATIVE_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_ALTERNATIVE_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/node_slots.hpp>
#include <boost/spirit/deterministic/builder/binary_builder.hpp>

namespace boost { namespace spirit { namespace deterministic {
    template<typename RuleT,typename A,typename B,typename SpaceP>
    void build_expression(RuleT* rule,alternative<A,B> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        typename RuleT::node_p other_front;
        node_slots<RuleT> other_back;
        build_expression(rule,p.left(),space,front,back);
        build_expression(rule,p.right(),space,other_front,other_back);
        //Do the actual joining of the two parsers, taking care of the case where one or both are builders.
        alternative_builder<RuleT>::apply(rule,front,back,other_front,other_back);
    }

    template<typename RuleT>
    struct alternative_builder : public binary_builder<RuleT,alternative_builder<RuleT> >{
        typedef binary_builder<RuleT,alternative_builder<RuleT> > base_t;
        typedef alternative_builder<RuleT> self_t;
        
        alternative_builder(builder_p& left,builder_p& right) : base_t(left,right) {}
        virtual ~alternative_builder() {}

        //Execute the actual alternative, or create a builder action (postpone until all rule creation is complete)
        static void apply(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_p& other_front,node_slots<RuleT>& other_back) {
            if(!is_builder(front) && !is_builder(other_front)) {
                parallel_join(rule,front,other_front,back,other_back);
                back.erase(other_front);
            }
            else {
                front=create_binary_builder(front,back,other_front,other_back);
                back.clear();
            }
        }
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,expand_mode mode) {
            node_p other_front;
            node_slots<RuleT> other_back;
            left()->expand(rule,front,back,(mode==readonly_mode)?copy_mode:mode);
            right()->expand(rule,other_front,other_back,(mode==readonly_mode)?copy_mode:mode);
            apply(rule,front,back,other_front,other_back);
        }
    };
}}}

#endif