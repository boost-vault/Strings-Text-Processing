#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_UNARY_BUILDER_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_UNARY_BUILDER_HPP

#include <boost/spirit/deterministic/builder/builder.hpp>
#include <boost/spirit/deterministic/builder/node_builder.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename Derived>
    struct unary_builder : public builder<RuleT> {
        unary_builder(builder_p& subject) : subject_(subject) {}
        virtual ~unary_builder() {}
        static node_p& create_unary_builder(node_p& front,node_slots<RuleT>& back) {
            front->set_builder(builder_p(new Derived(front->get_builder())));
            return front;
        }
        builder_p subject() {return subject_;}
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,expand_mode mode) {
            node_slots<RuleT> exclude;
            subject()->expand(rule,front,back,exclude,(mode==readonly_mode)?copy_mode:mode);
            Derived::apply(rule,front,back,exclude);
        }
    private:
        builder_p subject_;
    };

}}}
#endif