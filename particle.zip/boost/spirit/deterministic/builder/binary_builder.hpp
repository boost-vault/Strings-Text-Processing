#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_BINARY_BUILDER_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_BINARY_BUILDER_HPP

#include <boost/spirit/deterministic/builder/builder.hpp>
#include <boost/spirit/deterministic/builder/node_builder.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT,typename Derived>
    struct binary_builder : public builder<RuleT> {
        binary_builder(builder_p& left,builder_p& right) : left_(left),right_(right) {}
        static node_p& create_binary_builder(node_p& front1,node_slots<RuleT>& back1,node_p& front2,node_slots<RuleT>& back2) {
            //Ensure that both front and other_front are converted to builders.
            node_p* new_front=0;
            builder_p builder1=front1->get_builder();
            builder_p builder2=front2->get_builder();
            front1->set_builder(builder_p());
            front2->set_builder(builder_p());
            if(!builder1) {
                new_front=&front2;
                builder1=builder_p(new node_builder<RuleT>(front1,back1));
            }
            else if(!builder2) {
                new_front=&front1;
                builder2=builder_p(new node_builder<RuleT>(front2,back2));
            }
            else new_front=&front1;
            (*new_front)->set_builder(builder_p(new Derived(builder1,builder2)));
            return *new_front;
        }
        builder_p left() {return left_;}
        builder_p right() {return right_;}
    private:
        builder_p left_;
        builder_p right_;
    };

}}}
#endif