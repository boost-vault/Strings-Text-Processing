#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_SEQUENCE_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_SEQUENCE_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/serial.hpp>

namespace boost { namespace spirit { namespace deterministic {
    //algoritms
    template<typename RuleT,typename A,typename B,typename SpaceP>
    void build_expression(RuleT* rule,sequence<A,B> const& p,const SpaceP& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        //Temporary front and back
        typename RuleT::node_p front_right;
        node_slots<RuleT> back_left;

        //This is the parser a>>b. 
        //First build a. front is the start node of both the a parser and the sequence parser
        build_expression(rule,p.left(),space,front,back_left);
        //Then build b. back is the end nodes of both the b parser and the sequence parser
        build_expression(rule,p.right(),space,front_right,back);
        sequence_builder<RuleT>::apply(rule,front,back_left,front_right,back);
    }

    template<typename RuleT>
    struct sequence_builder : public binary_builder<RuleT,sequence_builder<RuleT> >{
        typedef binary_builder<RuleT,sequence_builder<RuleT> > base_t;
        typedef sequence_builder<RuleT> self_t;

        sequence_builder(builder_p& left,builder_p& right) : base_t(left,right) {}
        virtual ~sequence_builder() {}

        //Execute the actual alternative, or create a builder action (postpone until all rule creation is complete)
        static void apply(RuleT* rule,node_p& front,node_slots<RuleT>& back_left,node_p& front_right,node_slots<RuleT>& back) {
            if(!is_builder(front) && !is_builder(front_right)) {
                //Handle the case where b is a looping node (front_right is a legal end node of back)
                if(back.has_reference(front_right)) back.join(back_left);
                //Join the back of the a parser with the front of the b parser.
                serial_join(rule,back_left,front_right,back,back_left);

                //Remove temporary nodes from the back nodes
                back.erase(front_right);
            }
            else {
                front=create_binary_builder(front,back_left,front_right,back);
                back.clear();
            }
        }
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,expand_mode mode) {
            node_p front_right;
            node_slots<RuleT> back_left;
            left()->expand(rule,front,back_left,(mode==readonly_mode)?copy_mode:mode);
            right()->expand(rule,front_right,back,(mode==readonly_mode)?copy_mode:mode);
            apply(rule,front,back_left,front_right,back);
        }
    };

}}}

#endif