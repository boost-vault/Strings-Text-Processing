#ifndef BOOST_SPIRIT_DETERMINISTIC_BUILDER_BUILDER_HPP
#define BOOST_SPIRIT_DETERMINISTIC_BUILDER_BUILDER_HPP

namespace boost { namespace spirit { namespace deterministic {

    template<typename RuleT>
    struct builder {
        typedef intrusive_ptr<builder<RuleT> > builder_p;
        typedef typename RuleT::node_p node_p;
        typedef typename RuleT::node_t node_t;
        typedef std::map<node_p,node_p> treated_node_map;
        enum expand_mode {
            transfer_mode,
            readonly_mode,
            copy_mode,
        };
        virtual ~builder() {}
        static bool is_builder(const node_p& node) {
            if(!node) return false;
            return node->is_builder();
        }
        void copy_recursive(RuleT* rule,const node_p& source_front,const node_slots<RuleT>& source_back,node_p& dest_front,node_slots<RuleT>& dest_back,treated_node_map& treated_nodes) {
            if(source_back.has_reference(source_front)) dest_back.insert(dest_front);
            if(!source_front) return;
            node_p& node=treated_nodes[source_front];
            if(node) {
                dest_front=node;
                return;
            }
            else {
                dest_front=source_front->unroll(rule,source_back,dest_back);
                node=dest_front;
                //Copy children and recursion nodes.
                typename node_t::range_iterator idest=dest_front->get_ranges().begin();
                typename node_t::const_range_iterator isource=source_front->get_ranges().begin();
                for(;isource!=source_front->get_ranges().end();++isource,++idest) {
                    copy_recursive(rule,isource->second,source_back,idest->second,dest_back,treated_nodes);
                }
            }
        }
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,expand_mode mode)=0;
        virtual void expand(RuleT* rule,node_p& front,node_slots<RuleT>& back,node_slots<RuleT>& exclude,expand_mode mode) {
            expand(rule,front,back,mode);
        }
        void add_ref() {++use_count;}
        void release() {if(--use_count==0) delete this;}
    private:
        int use_count;
    };
    template<typename RuleT>
    void intrusive_ptr_add_ref(builder<RuleT>* p)
    {
        p->add_ref();
    }

    template<typename RuleT>
    void intrusive_ptr_release(builder<RuleT>* p)
    {
        p->release();
    }
}}}
#endif