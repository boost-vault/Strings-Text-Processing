#ifndef BOOST_SPIRIT_DETERMINISTIC_NUMERICS_HPP
#define BOOST_SPIRIT_DETERMINISTIC_NUMERICS_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder/kleene_star.hpp>
#include <boost/spirit/deterministic/builder/optional.hpp>
#include <boost/spirit/deterministic/builder/sequence.hpp>
#include <boost/spirit/deterministic/builder/alternative.hpp>
#include <boost/spirit/deterministic/builder/positive.hpp>
#include <boost/spirit/deterministic/builder/primitives.hpp>

namespace boost { namespace spirit { namespace deterministic {

    template<int Radix>
    struct radix_parser : public char_parser<radix_parser<Radix> >
    {
        typedef radix_parser<Radix> self_t;

        radix_parser() {}

        template <typename CharT>
        static bool test(CharT ch)
        { 
            switch(Radix) {
            case 2:
                return ch>='0' && ch<='1';
            case 8:
                return ch>='0' && ch<='7';
            case 10:
                return ch>='0' && ch<='9';
            case 16:
                return (ch>='0' && ch<='9') || (ch>='a' && ch<='f') || (ch>='A' && ch<='F');
            default:
                return false;
            }
        }
    };

    template<typename RuleT,int Radix,typename SpaceP>
    void build_expression(RuleT* rule,radix_parser<Radix> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        switch(Radix) {
        case 2:
            parallel_add_range(rule,'0','1',front,back,back);
            break;
        case 8:
            parallel_add_range(rule,'0','7',front,back,back);
            break;
        case 10:
            parallel_add_range(rule,'0','9',front,back,back);
            break;
        case 16:
            {
                parallel_add_range(rule,'0','9',front,back,back);
                parallel_add_range(rule,'a','f',front,back,back);
                parallel_add_range(rule,'A','F',front,back,back);
                break;
            }
        }
    }

    template<typename RuleT,typename T,int Radix,unsigned MinDigits,int MaxDigits,typename SpaceP>
    void build_expression(RuleT* rule,uint_parser<T,Radix,MinDigits,MaxDigits> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
		typedef typename RuleT::node_p node_p;
        node_slots<RuleT> prior_end;
        prior_end.insert(front);
        for(int i=0;i<MinDigits;++i) {
            node_slots<RuleT> end;
            node_p start;
            build_expression(rule,radix_parser<Radix>(),space,start,end);
            serial_join(rule,prior_end,start,prior_end);
            end.erase(start);
            std::swap(prior_end,end);
        }
        if(MaxDigits<0) {
            node_p start;
            build_expression(rule,*radix_parser<Radix>(),space,start,back);
            back.join(prior_end);
            serial_join(rule,prior_end,start,back,prior_end);
            back.erase(start);
        }
        else {
            for(int i=MinDigits;i<MaxDigits;++i) {
                back.join(prior_end);
                node_slots<RuleT> end;
                node_p start;
                build_expression(rule,radix_parser<Radix>(),space,start,end);
                serial_join(rule,prior_end,start,prior_end);
                end.erase(start);
                std::swap(prior_end,end);
            }
            back.join(prior_end);
        }
/*        
        if(MaxDigits<0) {
            node_p* inode=&start;
            for(int i=0;i<MinDigits;++i) {
                inode=&((*inode)->unroll(back));
            }
            parallel_join(front,*inode,back);        
            back.erase(start);
        }
        else {
            std::vector<node_slots<RuleT> > middle;
            std::vector<node_p> start;
            start.resize(MaxDigits);
            middle.resize(MaxDigits);
            for(size_t i=0;i<MaxDigits;++i) {
                if(i==0) build_expression(rule,radix_parser<Radix>(),front,middle[i]);
                else build_expression(rule,radix_parser<Radix>(),start[i-1],middle[i]);
            }
            for(size_t i=1;i<MinDigits;++i) {
                node_slots<RuleT> ignore;
                serial_join(middle[i-1],start[i-1],ignore);
            }
            for(size_t i=MinDigits;i<=MaxDigits;++i) {
                serial_join(middle[i-1],start[i-1],back);
            }
            for(size_t i=0;i<start.size();++i) {
                back.erase(start[i]);
            }
        }*/
    }

    template<typename RuleT,typename T,int Radix,unsigned MinDigits,int MaxDigits,typename SpaceP>
    void build_expression(RuleT* rule,int_parser<T,Radix,MinDigits,MaxDigits> const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
        build_expression(rule,!(ch_p('-') | ch_p('+') ) >> uint_parser<T,Radix,MinDigits,MaxDigits>(),space,front,back);
    }

    template<typename RuleT,typename T,typename SpaceP>
    void build_expression(RuleT* rule,real_parser<T,real_parser_policies<T> > const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
        build_expression(rule,!(ch_p('-') | ch_p('+') ) >> real_parser<T,ureal_parser_policies<T> >(),space,front,back);
    }

    template<typename RuleT,typename T,typename SpaceP>
    void build_expression(RuleT* rule,real_parser<T,ureal_parser_policies<T> > const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        if(build_primitive_space(rule,p,space,front,back)) return;
        typedef typename RuleT::node_p node_p;
        node_p front_decimal,front_integer,front_exponent;
        node_slots<RuleT> back_decimal,back_integer,back_exponent;
        build_expression(rule,(('.' >> digit_p) | (+digit_p >> '.')) >> *digit_p,space,front_decimal,back_decimal);
        build_expression(rule,+digit_p,space,front_integer,back_integer);
        build_expression(rule,(ch_p('E') | 'e') >> !(ch_p('+') | '-') >> +digit_p,space,front_exponent,back_exponent);

        back_exponent.join(back_decimal);
        serial_join(rule,back_decimal,front_exponent,back_decimal,back_exponent);
        serial_join(rule,back_integer,front_exponent,back_decimal,back_exponent);
        back.join(back_exponent);
        parallel_join(rule,front,front_decimal,back);
        parallel_join(rule,front,front_integer,back);
/*            (
                (
                    (   
                        (('.' >> digit_p) | (+digit_p >> '.')) >> *digit_p
                    ) >> 
                    !(
                        (ch_p('E') | 'e') >> 
                        !(ch_p('+') | '-') >> 
                        +digit_p
                    )
                ) |
                (
                    +digit_p >> 
                    (
                        (ch_p('E') | 'e') >> 
                        !(ch_p('+') | '-') >> 
                        +digit_p
                    )
                )
            ),front,back
        );*/
    }

}}}

#endif