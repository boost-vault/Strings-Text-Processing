#ifndef BOOST_SPIRIT_DETERMINISTIC_NODE_PTR_HPP
#define BOOST_SPIRIT_DETERMINISTIC_NODE_PTR_HPP

#include <boost/checked_delete.hpp>
#include <boost/shared_ptr.hpp>
namespace boost { namespace spirit { namespace deterministic {

template<typename T>
struct counter_base {
public:
    counter_base(T* px) : weak_count_(1),use_count_(1), px_(px) {}
    long weak_count() const {return weak_count_;}
    long use_count() const {return use_count_;}
    T* px() const {return px_;}
    void add_ref() {++use_count_;}
    void add_ref_weak() {++weak_count_;}
    void release() {
        if(--use_count_ ==0) {
            boost::checked_delete( px_ );
            release_weak();
        }
    }
    void release_weak() {
        if(--weak_count_==0) {
            delete this;
        }
    }
private:
    long weak_count_;
    long use_count_;
    T* px_;
};
template<typename T>
struct node_ptr;

template<typename T>
struct owned_ptr {
    friend struct node_ptr<T>;

    owned_ptr(const owned_ptr<T>& other) 
        : counter(other.counter)
    {
        if(counter) counter->add_ref();
    }
    explicit owned_ptr(T* ptr) :
    counter(new counter_base<T>(ptr))
    {
    }
    ~owned_ptr() {
        if(counter) counter->release();
    }
    owned_ptr(const node_ptr<T>& other) 
        : counter(other.counter)
    {
        if(counter) counter->add_ref();
    }
    owned_ptr& operator=(const owned_ptr<T>& other) {
        counter_base<T> * tmp = other.counter;

        if( tmp != counter)
        {
            if( tmp != 0 ) tmp->add_ref();
            if( counter != 0 ) counter->release();
            counter = tmp;
        }
        return *this;            
    }
    void swap(owned_ptr<T> & r) // nothrow
    {
        counter_base<T> * tmp = r.counter;
        r.counter = counter;
        counter = tmp;
    }
private:
    counter_base<T>* counter;
};

template<typename T>
struct node_ptr {
    typedef node_ptr<T> this_type;
    friend struct owned_ptr<T>;

    size_t node_count() const {
        if(counter) {
            if(counter->use_count()==0) return 0;
            return counter->weak_count()-1;
        }
        return 0;
    }
    node_ptr() 
        : counter(0)
    {}
    node_ptr(const owned_ptr<T>& other) 
        : counter(other.counter)
    {
        if(counter) counter->add_ref_weak();
    }
    ~node_ptr() {
        if(counter) counter->release_weak();
    }
    node_ptr(const node_ptr<T>& other) 
        : counter(other.counter)
    {
        if(counter) counter->add_ref_weak();
    }
    node_ptr& operator=(const node_ptr<T>& other) {
        counter_base<T> * tmp = other.counter;

        if( tmp != counter)
        {
            if( tmp != 0 ) tmp->add_ref_weak();
            if( counter != 0 ) counter->release_weak();
            counter = tmp;
        }
        return *this;            
    }
    void swap(node_ptr<T> & r) // nothrow
    {
        counter_base<T> * tmp = r.counter;
        r.counter = counter;
        counter = tmp;
    }
    T* operator->() {return counter->px();}
    const T* operator->() const {return counter->px();}
    T* get() {if(counter) return counter->px();else return 0;}
    const T* get() const {if(counter) return counter->px();else return 0;}
    bool operator<(const node_ptr<T>& other) const{
        return get()<other.get();
    }
    bool operator! () const // never throws
    {
        return (counter == 0 || counter->px()==0);
    }
    static void unspecified_bool( this_type*** )
    {
    }
    bool operator==(const node_ptr<T>& other) const {
        return get()==other.get();
    }
    bool operator!=(const node_ptr<T>& other) const {
        return get()!=other.get();
    }
    typedef void (*unspecified_bool_type)( this_type*** );

    operator unspecified_bool_type() const // never throws
    {
        return (counter == 0 || counter->px()==0)? 0: unspecified_bool;
    }
private:
    counter_base<T>* counter;
};

}}}//namespace boost::spirit::deterministic
#endif
