#ifndef BOOST_SPIRIT_DETERMINISTIC_token_rule_HPP
#define BOOST_SPIRIT_DETERMINISTIC_token_rule_HPP

#include <boost/spirit/core.hpp>
#include <boost/spirit/deterministic/builder.hpp>
#include <boost/spirit/deterministic/node_ptr.hpp>
#include <boost/spirit/deterministic/symbol_node.hpp>
#include <boost/spirit/deterministic/builder/builder.hpp>
#include <boost/next_prior.hpp>
#include <set>
#include <stack>

namespace boost { namespace spirit { namespace deterministic {

	//Tokenparsing:
	/*
		We need to store the parsed text + a token ID.
		struct token {
		   std::string text;
		   size_t id;
		};
		iterator: iterator type and character type.
	//Full parsing
		Store parse tree:
		struct token2 {
			size_t id;
			token token_;
			std::vector<token2> nested;
		}
	*/

    template<typename IteratorT,typename TagT,typename SpaceParser=epsilon_parser>
    class deterministic_rule : public parser<deterministic_rule<IteratorT,TagT,SpaceParser> > {
    public:
        typedef deterministic_rule<IteratorT,TagT,SpaceParser> self_t;
        typedef typename IteratorT::value_type symbol_t;
        typedef symbol_node<self_t> node_t;
        typedef node_ptr<node_t> node_p;
        typedef const self_t& embed_t;

        typedef range_map<symbol_t,node_p> node_range;
        typedef std::vector<owned_ptr<node_t> > node_container;
        typedef typename node_container::iterator node_iterator;
        typedef typename node_t::builder_p builder_p;

        owned_ptr<node_t>& add_node() {nodes.push_back(owned_ptr<node_t>(new node_t(this)));return nodes.back();}

        deterministic_rule() :builder_count(0) {}
		deterministic_rule(self_t const& other)
            :builder_count(0)
		{
            SpaceParser space;
            build_expression(this,other,space,root,slots);
            //simplify_nodes(nodes.begin(),root,slots);
        }
        template<typename T>
        deterministic_rule(parser<T> const& expression) 
            :builder_count(0)
        {
            SpaceParser space;
            build_expression(this,expression.derived(),space,root,slots);
            //simplify_nodes(nodes.begin(),root,slots);
        }
		~deterministic_rule() {
		}


        template<typename T>
        self_t& operator=(const parser<T>& expression) {
            SpaceParser space;
            build_expression(this,expression.derived(),space,root,slots);
            //simplify_nodes(nodes.begin(),root,slots);
            return *this;
        }
        template<typename T>
        self_t& operator=(const self_t& other) {
            SpaceParser space;
            build_expression(this,other,space,root,slots);
            //simplify_nodes(nodes.begin(),root,slots);
            return *this;
        }
        void simplify_nodes() {
            simplify_nodes(nodes.begin(),root,slots);
        }
        void expand() {
            if(!get_root() || !get_root()->is_builder()) return;
            node_p front=get_root();
            get_root()=node_p();
            front->get_builder()->expand(this,get_root(),get_slots(),builder<self_t>::transfer_mode);
            front->set_builder(builder_p());
        }
        template<typename ScannerT>
        typename parser_result<self_t, ScannerT>::type
        parse(ScannerT& scan) const{
            const node_p* next=&root;
            const self_t* rule=this;
            while(*next && !scan.at_end()) {
                const node_p& node=*next;
                node_range::const_iterator it = node->get_ranges().find(*scan);
                //No match for next
                if(it==node->get_ranges().end()) {
                    if(get_slots().has_reference(node)) {
                        return scan.empty_match();
                    }
                    else {
                        return scan.no_match();
                    }
                }
                //The next node is empty.
                else if(!it->second) {
                    if(get_slots().has_reference(it)) {
                        return scan.empty_match();
                    }
                    else if(get_slots().has_reference(node)) {
                        return scan.empty_match();
                    }
                    else {
                        return scan.no_match();
                    }
                }
                //We have a legal node.
                else {
                    next=&it->second;
                }
                ++scan;
            }
            return scan.empty_match();
        }
        const node_p& get_root() const {return root;}
        node_p& get_root() {return root;}
        const node_slots<self_t>& get_slots() const {return slots;}
        node_slots<self_t>& get_slots() {return slots;}
        const node_container get_nodes() const {return nodes;}
        void simplify_nodes(node_iterator istart,node_p& start,node_slots<self_t>& nodes);
        template<typename Sorter>
        void collect_nodes(node_p& node,Sorter& sorted,std::set<node_p>& collected) {
            if(!node) return;
            sorted[&node].insert(node);
            if(!collected.insert(node).second) return;
            for(typename node_range::iterator it=node->get_ranges().begin();it!=node->get_ranges().end();++it) {
                collect_nodes(it->second,sorted,collected);
            }
        }
        template<typename CollectorMap>
        bool is_compatible(const node_p& first,const node_p& second,node_slots<self_t>& end_nodes,CollectorMap& nodes) {            
            if(first==second) {
                return end_nodes.has_reference(first)==end_nodes.has_reference(second);
            }
            if(!first || !second) return false;            
            if(end_nodes.has_reference(first)!=end_nodes.has_reference(second)) return false;
            if(first->get_ranges().size()!=second->get_ranges().size()) return false;
            //If this node has been evaluated already, don't consider it again.
            if(!nodes[first].insert(second).second) return true;

            if(first->get_parent()!=second->get_parent()) return false;
            typename node_range::const_iterator ifirst,isecond;
            for(ifirst=first->get_ranges().begin(),isecond=second->get_ranges().begin();
                ifirst!=first->get_ranges().end();++ifirst,++isecond) 
            {
                if(ifirst->first!=isecond->first) return false;
                if(!is_compatible(ifirst->second,isecond->second,end_nodes,nodes)) return false;
            }
            return true;
        }
        bool is_compatible(const node_p& first,const node_p& second,node_slots<self_t>& end_nodes) {
            std::map<node_p,std::set<node_p> > nodes;
            return is_compatible(first,second,end_nodes,nodes);
        }
        size_t get_builder_count() {return builder_count;}
        size_t increment_builder_count() {return ++builder_count;}
        size_t decrement_builder_count(){return --builder_count;}
    private:
		node_container nodes;
        node_p root;
        node_slots<self_t> slots;
        int empty_nodes;
        int builder_count;
    };

    template<typename RuleT>
    struct less_node {
        typedef typename RuleT::node_p node_p;
        typedef typename RuleT::node_t node_t;
        typedef typename node_t::node_builder_p node_builder_p;
        less_node(node_slots<RuleT>& end_nodes_) : end_nodes(end_nodes_) {}
        less_node(const less_node& other) : end_nodes(other.end_nodes) {}
        bool operator()(node_p* left,node_p* right) const {
            node_p& rleft=*left;
            node_p& rright=*right;
            if(rleft==rright) {
                bool end_left=end_nodes.has_reference(rleft);
                bool end_right=end_nodes.has_reference(rright);
                if(end_left!=end_right) return end_left;
                //Equal
                return false;
            }
            if(rleft->get_ranges().size()!=rright->get_ranges().size()) return rleft->get_ranges().size()<rright->get_ranges().size();
            typename RuleT::node_range::iterator ileft,iright;
            //Check if it covers the same ranges.
            for(ileft=rleft->get_ranges().begin(),iright=rright->get_ranges().begin();ileft!=rleft->get_ranges().end();++ileft,++iright) {
                if(ileft->first!=iright->first) return ileft->first<iright->first;
            }
            //Check end nodedness
            bool end_left=end_nodes.has_reference(rleft);
            bool end_right=end_nodes.has_reference(rright);
            if(end_left!=end_right) return end_left;
            //Equal
            return false;
        }
    private:
        node_slots<RuleT>& end_nodes;
    };
    template<typename RuleT>
    struct node_collector {
        typedef typename RuleT::node_p node_p;
        typedef std::map<node_p,node_slots<RuleT> > NodeMap;
        typedef typename NodeMap::iterator iterator;
        iterator begin() {return nodes.begin();}
        iterator end() {return nodes.end();}
        void insert(node_p& node) {nodes[node].insert(node);}
    private:
        NodeMap nodes;
    };

    template<typename IteratorT,typename TagT,typename SpaceParser>
    void deterministic_rule<IteratorT,TagT,SpaceParser>::simplify_nodes(node_iterator istart,node_p& start,node_slots<self_t>& nodes)
    {
        std::set<node_p> collected;
        less_node<self_t> compare(nodes);
        typedef std::map<node_p*,node_collector<self_t>,less_node<self_t> > Sorted;
        Sorted sorted(compare);
        collect_nodes(start,sorted,collected);
        for(Sorted::iterator isort=sorted.begin();isort!=sorted.end();++isort) {
            node_collector<self_t>& slots=isort->second;
            for(node_collector<self_t>::iterator inode=slots.begin();inode!=slots.end();++inode) {
                for(node_collector<self_t>::iterator inext=boost::next(inode);inext!=slots.end();++inext) {
                    const node_p& first=inode->first;
                    const node_p& second=inext->first;
                    if(is_compatible(first,second,nodes)) {
                        if(first==start || (second!=start && inode->second.size()>=inext->second.size())) {
                            BOOST_FOREACH(node_p* replace,inext->second) {
                                *replace=first;
                            }
                        }
                        else {
                            BOOST_FOREACH(node_p* replace,inode->second) {
                                *replace=second;
                            }
                        }
                    }
                }
            }
        }
    }

    
    template<typename RuleT,typename SpaceP>
    void build_expression(RuleT* rule,RuleT const& p,SpaceP const& space,typename RuleT::node_p& front,node_slots<RuleT>& back)
    {
        front=rule->add_node();
        rule_builder<RuleT>::apply(p,front);
    }

    template<typename RuleT>
    struct rule_builder : public builder<RuleT>{
        typedef rule_builder<RuleT> self_t;

        rule_builder(RuleT* rule_) : rule(rule_) {}
        virtual ~rule_builder() {}
        static void apply(RuleT const& p,node_p& front) {
            RuleT* rule=const_cast<RuleT*>(&p);
            front->set_builder(builder_p(new rule_builder(rule)));
            rule->increment_builder_count();
        }
        virtual void expand(RuleT* other_rule,node_p& front,node_slots<RuleT>& back,expand_mode mode) {
            rule->expand();
            if(mode==readonly_mode) {
                front=rule->get_root();
                back=rule->get_slots();
                if(back.erase(rule->get_root())) back.insert(front);
            }
            else if(mode==transfer_mode && rule->decrement_builder_count()==0) {
                front=rule->get_root();
                back=rule->get_slots();
                if(back.erase(rule->get_root())) back.insert(front);
                rule->get_root()=node_p();
            }
            else {
                treated_node_map treated_nodes;
                copy_recursive(other_rule,rule->get_root(),rule->get_slots(),front,back,treated_nodes);
            }
        }
        RuleT* rule;
    };
}}}

#endif