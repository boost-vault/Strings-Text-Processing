#include<boost/spirit/deterministic/deterministic_rule.hpp>
#include <boost/spirit/core.hpp>
#include<boost/spirit/deterministic/builder.hpp>
#include<boost/spirit/deterministic/graphviz_writer.hpp>
#include<boost/spirit/iterator/file_iterator.hpp>
#include <boost/spirit/symbols.hpp>

#include <fstream>
#include <malloc.h>
#include <iostream>
#include <strstream>
#include <time.h>

using namespace boost::spirit;
using namespace boost::spirit::deterministic;

struct cpp_lexer : public grammar<cpp_lexer>
{
    template <typename ScannerT>
    struct definition
    {
        typedef rule<ScannerT> rule_t;
        uint_parser<unsigned, 16,4,4> hex_quad;
        uint_parser<unsigned, 8,1,3> octal_digit;
        rule_t skip;
        rule_t lexer;
        rule_t integer_suffix;
        rule_t long_suffix,unsigned_suffix;
        rule_t c_char,s_char;
        rule_t escape_sequence;
        rule_t simple_escape_sequence;
        rule_t octal_escape_sequence;
        rule_t hexadecimal_escape_sequence;
        rule_t simple_escape_characters;
        rule_t floating_suffix;
        rule_t floating_literal;
        rule_t universal_character_name;
        rule_t integer_literal;
        rule_t character_literal;
        rule_t string_literal;

        rule_t r_token;
        rule_t r_identifier;
        symbols<> r_keyword;
        rule_t r_literal;
        symbols<> r_punctuator;
        rule_t const& start() const { return lexer; }
        definition(cpp_lexer const& /*self*/)
        {
            r_keyword = 
                "and",      "and_eq",  "asm",          "auto",     "bitand",   "bitor",
                "bool",     "break",   "case",         "catch",    "char",     "class",
                "compl",    "const",   "const_cast",   "continue", "default",  "delete",
                "do",       "double",  "dynamic_cast", "else",     "enum",     "explicit",
                "export",   "extern",  "false",        "float",    "for",      "friend",
                "goto",     "if",      "inline",       "int",      "long",     "mutable",
                "namespace","new",     "not",          "not_eq",   "operator", "or",
                "or_eq",    "private", "protected",    "public",   "register", "reinterpret_cast",
                "return",   "short",   "signed",       "sizeof",   "static",   "static_cast",
                "struct",   "switch",  "template",     "this",     "throw",    "true",
                "try",      "typedef", "typeid",       "typename", "union",    "unsigned",
                "using",    "virtual", "void",         "volatile", "wchar_t",  "while",
                "xor",      "xor_eq";

            r_punctuator =
                "{",  "}",  "[",  "]",  "(",  ")",  ";",  ":",  "?", "::",  ".", ".*",
                "+"  , "-",  "*",  "/",  "%",  "^",  "&",  "|",  "~",  "!",  "=",  "<",  ">",
                "+=" , "-=", "*=", "/=", "%=", "^=", "&=", "|=", "<<", ">>",">>=","<<=", "==",
                "!=" , "<=", ">=", "&&", "||", "++", "--",  ",","->*", "->","...","#"
                ;
            universal_character_name = 
                (ch_p('\\') >> ch_p('u') >> hex_quad) |
                (ch_p('\\') >> ch_p('U') >> hex_quad >> hex_quad);

            r_identifier= 
                (
                (alpha_p | '_' | universal_character_name) >> 
                *(alnum_p | '_' | universal_character_name)
                )
                - (r_keyword >> anychar_p - (alnum_p | '_' | universal_character_name))
                ;

            r_literal =
                integer_literal 
                |   character_literal 
                |   floating_literal 
                |   string_literal
                ;

            integer_literal = 
                (
                (ch_p('0'))
                | (ch_p('0') >> ch_p('x') >> hex_p)
                | (ch_p('0') >> oct_p)
                | (ch_p('0') >> oct_p >> range_p('8','9') >> !int_p)
                | (ch_p('0') >> range_p('8','9') >> !int_p)
                | (range_p('1','9') >> *digit_p)
                ) >> !integer_suffix
                ;

            integer_suffix = 
                (long_suffix >> !unsigned_suffix)
                |(unsigned_suffix >> !long_suffix)
                ;

            unsigned_suffix=(ch_p('u') | 'U');
            long_suffix=(ch_p('l') | 'L');

            character_literal = 
                !ch_p('L') >> ch_p('\'') >> *(c_char) >> ch_p('\'');

            c_char =
                (
                anychar_p 
                - (
                ch_p('\'') 
                |  ch_p('\\') 
                |  ch_p('\n')
                |  ch_p('\r')
                )
                )
                | escape_sequence
                | universal_character_name
                ;

            escape_sequence = 
                simple_escape_sequence |
                octal_escape_sequence |
                hexadecimal_escape_sequence;

            simple_escape_characters = ch_p("'") | "\"" | "?" | "\\" | "a" | "b" | "f" | "n" | "r" | "t" | "v";

            simple_escape_sequence = 
                ch_p('\\') >> simple_escape_characters;
            octal_escape_sequence = 
                '\\' >> octal_digit;
            hexadecimal_escape_sequence = 
                ch_p('\\') >> ch_p('x') >> hex_p;

            floating_literal = ureal_p >> !floating_suffix;
            floating_suffix =ch_p('f')|'F'|'l'|'L';

            string_literal =
                !ch_p('L') >> ch_p('"') >> *(s_char) >> ch_p('"');

            s_char =
                (
                anychar_p 
                - (
                ch_p('"') 
                |  ch_p('\\') 
                |  ch_p('\n')
                |  ch_p('\r')
                )
                )
                | escape_sequence
                | universal_character_name
                ;

            skip=
                (
                space_p
                | (str_p("//") >> *(anychar_p-eol_p) >> eol_p)
                | str_p("/*") >> *(anychar_p-str_p("*/")) >> str_p("*/")
                )
                ;

            r_token=
                r_identifier
                |r_keyword
                |r_literal
                |r_punctuator
                ;

            lexer = *(skip|r_token);
        }
    };
};
int heapsize();
void test_nondeterministic() {
    {
        std::cout << "Nondeterministic parser:" << std::endl;
        int used1=heapsize();
        clock_t build_start=clock();
        cpp_lexer stat;
        cpp_lexer::definition<scanner<boost::spirit::file_iterator<>, scanner_policies<> > > def(stat);
        clock_t build_end=clock();
        int used2=heapsize();
        std::cout << "Memory used: " << used2-used1 << std::endl;
        std::cout << "Time to build: " << double(build_end-build_start)/double(CLOCKS_PER_SEC)<< std::endl;
        clock_t start=clock();
        boost::spirit::file_iterator<> is("function.i");
        boost::spirit::file_iterator<> eof;
        parse(is,eof,def.start());
        clock_t end=clock();
        std::cout << "Time to parse (555 KB):" << double(end-start)/double(CLOCKS_PER_SEC)<< std::endl;
        std::cout << std::endl;
    }
}