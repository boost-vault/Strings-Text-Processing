#include<boost/spirit/deterministic/deterministic_rule.hpp>
#include <boost/spirit/core.hpp>
#include<boost/spirit/deterministic/builder.hpp>
#include<boost/spirit/deterministic/graphviz_writer.hpp>
#include <fstream>

using namespace boost::spirit;
using namespace boost::spirit::deterministic;

void main() {
    typedef deterministic_rule<std::string::iterator,int> rule_t; 
    uint_parser<unsigned, 16,4,4> hex_quad;
    rule_t rule;
    rule=(
            (
                alpha_p 
              | '_' 
              | ("\\b" >> hex_quad)
            ) >> 
            *(
                alnum_p
              | '_' 
              | ("\\b" >> hex_quad)
            )
        ) - (str_p("int")|str_p("if"))
        ;
    //rule.simplify_nodes();
    std::ofstream name("literal.dot");
    write_graphviz_rule(name,rule);
}