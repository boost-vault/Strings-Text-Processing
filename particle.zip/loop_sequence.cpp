#include<boost/spirit/deterministic/deterministic_rule.hpp>
#include <boost/spirit/core.hpp>
#include<boost/spirit/deterministic/builder.hpp>
#include<boost/spirit/deterministic/graphviz_writer.hpp>
#include <fstream>

using namespace boost::spirit;
using namespace boost::spirit::deterministic;

void main() {
    typedef deterministic_rule<std::string::iterator,int> rule_t; 
    uint_parser<unsigned, 16,4,4> hex_quad;
    rule_t rule;
    rule=*(
            *(space_p | ("/*" >> (*(anychar_p-"*/") >> "*/"))) >>
            (
                (
                    (alpha_p | ("\\b" >> hex_quad)) >> (*(alnum_p| ("\\b" >> hex_quad)))
                ) |
                real_p
            )
          );
    std::ofstream name("loop_sequence.dot");
    write_graphviz_rule(name,rule);
}