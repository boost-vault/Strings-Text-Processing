//Purpose:
//  Demonstrate error in non-classic multi_pass iterator compilation.
//
#define USE_FUNCTOR_INPUT
//#define USE_MULTI_PASS_CLASSIC
#ifdef USE_MULTI_PASS_CLASSIC
  #define MULTI_PASS_NS BOOST_SPIRIT_CLASSIC_NS
  #include <iterator>
  #include <boost/spirit/home/classic.hpp>
  #include <boost/spirit/home/classic/iterator.hpp>
#else
  #define MULTI_PASS_NS boost::spirit
  #include <boost/spirit/home/qi.hpp>
  #include <boost/spirit/home/support.hpp>
  #include <boost/spirit/home/support/multi_pass.hpp>
  #ifdef USE_FUNCTOR_INPUT
    #include <boost/spirit/home/support/iterators/detail/functor_input_policy.hpp>
  #else
    #include <boost/spirit/home/support/iterators/detail/input_iterator_policy.hpp>
  #endif
#endif
#include <fstream>

//[iterate_a2m:
// copied from:
//    http://www.boost.org/doc/libs/1_41_0/libs/spirit/doc/html/spirit/support/multi_pass.html

// define the function object
template<typename CharT=char>
class istreambuf_functor
{
public:
        typedef 
      std::istreambuf_iterator<CharT> 
    buf_iterator_type;
        typedef 
      typename buf_iterator_type::int_type
    result_type;
        static 
      result_type 
    eof;

    istreambuf_functor(void)
      : current_chr(eof)
    {}

    istreambuf_functor(std::ifstream& input) 
      : my_first(input)
      , current_chr(eof)
    {}

    result_type& operator()()
    {
        buf_iterator_type last;
        if (my_first == last)
        {
            return eof;
        }
        current_chr=*my_first;
        ++my_first;
        return current_chr;
    }

private:
    buf_iterator_type my_first;
    result_type current_chr;
};

template<typename CharT>
  typename istreambuf_functor<CharT>::result_type 
  istreambuf_functor<CharT>::
eof
( istreambuf_functor<CharT>::buf_iterator_type::traits_type::eof()
)
;

//]iterate_a2m:

#ifdef USE_FUNCTOR_INPUT
    typedef
  istreambuf_functor<char>
base_iterator_type;
#else  
    typedef 
  std::istreambuf_iterator<char> 
base_iterator_type;
#endif

    typedef
  MULTI_PASS_NS::multi_pass
  < base_iterator_type
#ifdef USE_MULTI_PASS_CLASSIC
#else
  , boost::spirit::iterator_policies::default_policy
    < boost::spirit::iterator_policies::first_owner
    , boost::spirit::iterator_policies::no_check
  #ifdef USE_FUNCTOR_INPUT
    , boost::spirit::iterator_policies::functor_input
  #else
    , boost::spirit::iterator_policies::input_iterator
  #endif
    , boost::spirit::iterator_policies::split_std_deque
    >
#endif
  > 
chr_iterator_type;

// ======================================================================       
// Main                                                                         
int main(int argc, char** argv) {
    std::ifstream in("multi_pass.txt");    // we get our input from this file
    if (!in.is_open()) {
        std::cout << "Could not open input file: 'multi_pass.txt'" << std::endl;
        return -1;
    }
    unsigned num_toks=0;
    unsigned const max_toks=10;
  #if 1
    base_iterator_type base_first(in);
    chr_iterator_type chr_first(base_first);
    chr_iterator_type chr_last;
    for
      (
      ; (chr_first != chr_last && ++num_toks < max_toks)
      ; ++chr_first
      )
    {
        std::cout<<":num_toks="<<num_toks<<":chr="<<*chr_first<<"\n";
    }
  #else
    istreambuf_functor<> functor(in);
    for
      ( char chr=functor()
      ; (chr != istreambuf_functor<>::eof && ++num_toks < max_toks)
      ; chr=functor() 
      )
    {
        std::cout<<":num_toks="<<num_toks<<":chr="<<chr<<"\n";
    }
  #endif
    return 0;
}    
