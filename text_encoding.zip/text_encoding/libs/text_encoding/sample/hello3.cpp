#include <string>
#include <iostream>
#include <boost/text_encoding.hpp>
#include <boost/assert.hpp>
using namespace std;
using namespace boost::text_encoding;
int main() {
  c_string cs = L"\x00AB";
  utf8_string us = cs;
  
  // These comparing are not equal because they have different bytes.
  BOOST_ASSERT(cs.compare(us) != 0);
  BOOST_ASSERT(
    static_cast<string const &>(cs)
     !=
    static_cast<string const &>(us)
  );

  // These comparing are equal because they have same characters.
  BOOST_ASSERT(cs.wcompare(wstring(us)) == 0);
  BOOST_ASSERT(cs == us);

  wcout << cs << endl;
  wcout << us << endl;
  return 0;
}
