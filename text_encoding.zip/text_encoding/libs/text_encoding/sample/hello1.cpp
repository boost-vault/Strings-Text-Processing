#include <iostream>
#include <boost/text_encoding.hpp>
using namespace std;
using namespace boost::text_encoding;
int main() {
  utf8_string hello = L"Hello, World!";
  cout << hello << endl;
  return 0;
}
