#include <string>
#include <iostream>
#include <boost/text_encoding.hpp>
#include <boost/assert.hpp>
using namespace std;
using namespace boost::text_encoding;
int main() {
  utf8_string hello = "Hello, World!";
  BOOST_ASSERT(hello == L"Hello, World!");
  BOOST_ASSERT(hello == "Hello, World!");
  
  hello = L"Hello, Wide World!";
  BOOST_ASSERT(hello == L"Hello, Wide World!");
  BOOST_ASSERT(hello == "Hello, Wide World!");

  cout << hello << endl;
  return 0;
}
