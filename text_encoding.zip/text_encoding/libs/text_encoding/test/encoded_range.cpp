#include <boost/test/unit_test.hpp>
#include <boost/text_encoding/detail/utf8_codecvt_facet.hpp>
//#include <boost/archive/xml_woarchive.hpp>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <locale>
#include <boost/lexical_cast.hpp>
#include <boost/text_encoding/encoded_range.hpp>

using namespace boost::text_encoding;
BOOST_AUTO_TEST_CASE(encoded_range1_test)
{
  std::basic_string<wchar_t> ws = L"hello world";
  std::string s(boost::begin(make_coded_range<charset::utf8>(ws)), make_coded_range<charset::utf8>(ws).end());
  BOOST_CHECK(s == "hello world");
  BOOST_CHECK(std::basic_string<wchar_t>(make_coded_range<charset::utf8>(s).begin(), make_coded_range<charset::utf8>(s).end()) == L"hello world");
}

BOOST_AUTO_TEST_CASE(encoded_range2_test)
{
  const wchar_t ws[] = L"hello world";
  std::equal(boost::begin(ws), boost::end(ws), boost::begin(make_coded_range<charset::utf8>(make_coded_range<charset::utf8>(ws))));
}

BOOST_AUTO_TEST_CASE(encoded_range3_test)
{
  const wchar_t ws[] = L"hello world";
  std::equal(boost::begin(ws), boost::end(ws), boost::begin(make_decoded_range<charset::utf8>(make_encoded_range<charset::utf8>(ws))));
}

BOOST_AUTO_TEST_CASE(encoded_range4_test)
{
  const char s[] = "hello world";
  std::equal(boost::begin(s), boost::end(s), boost::begin(make_coded_range<charset::utf8>(make_coded_range<charset::utf8>(s))));
}

BOOST_AUTO_TEST_CASE(encoded_range5_test)
{
  const char s[] = "hello world";
  std::equal(boost::begin(s), boost::end(s), boost::begin(make_encoded_range<charset::utf8>(make_decoded_range<charset::utf8>(s))));
}
