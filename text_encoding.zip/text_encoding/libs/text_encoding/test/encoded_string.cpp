#include <boost/test/unit_test.hpp>
#include <sstream>
#include <boost/bind.hpp>
#include <boost/text_encoding.hpp>
using namespace std;
using namespace boost;
using namespace boost::text_encoding;
namespace {
  utf8_string fv(utf8_string s){ return s;}
  utf8_string& fr(utf8_string& s){ return s;}
}
BOOST_AUTO_TEST_CASE(bind_test) {
  utf8_string us = L"";
  BOOST_CHECK(bind(&fv, us)() == us);
  BOOST_CHECK(&bind(&fr, ref(us))() == &us);
}

BOOST_AUTO_TEST_CASE(contruct_from_wstring_test) {
  basic_string<wchar_t> ws = L"abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  utf8_string us = ws;
  c_string cs = ws;

  BOOST_CHECK(cs == us);
  BOOST_CHECK(cs == ws);
  BOOST_CHECK(us == ws);
  BOOST_CHECK(us == cs);
  BOOST_CHECK(ws == cs);
  BOOST_CHECK(ws == us);

  BOOST_CHECK(!(cs != us));
  BOOST_CHECK(!(cs != ws));
  BOOST_CHECK(!(us != ws));
  BOOST_CHECK(!(us != cs));
  BOOST_CHECK(!(ws != cs));
  BOOST_CHECK(!(ws != us));
}

BOOST_AUTO_TEST_CASE(assign_from_wstring_test) {
  basic_string<wchar_t> ws = L"abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  utf8_string us; us = ws;
  c_string cs; cs = ws;

  BOOST_CHECK(cs == us);
  BOOST_CHECK(cs == ws);
  BOOST_CHECK(us == ws);
  BOOST_CHECK(us == cs);
  BOOST_CHECK(ws == cs);
  BOOST_CHECK(ws == us);

  BOOST_CHECK(!(cs != us));
  BOOST_CHECK(!(cs != ws));
  BOOST_CHECK(!(us != ws));
  BOOST_CHECK(!(us != cs));
  BOOST_CHECK(!(ws != cs));
  BOOST_CHECK(!(ws != us));
}

BOOST_AUTO_TEST_CASE(contruct_from_string_test) {
  string s = "abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  utf8_string us = s;
  c_string cs = s;

  BOOST_CHECK(cs == us);
  BOOST_CHECK(cs == s);
  BOOST_CHECK(us == s);
  BOOST_CHECK(us == cs);
  BOOST_CHECK(s == cs);
  BOOST_CHECK(s == us);

  BOOST_CHECK(!(cs != us));
  BOOST_CHECK(!(cs != s));
  BOOST_CHECK(!(us != s));
  BOOST_CHECK(!(us != cs));
  BOOST_CHECK(!(s != cs));
  BOOST_CHECK(!(s != us));
}

BOOST_AUTO_TEST_CASE(assign_from_string_test) {
  string s = "abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  utf8_string us; us = s;
  c_string cs; cs = s;

  BOOST_CHECK(cs == us);
  BOOST_CHECK(cs == s);
  BOOST_CHECK(us == s);
  BOOST_CHECK(us == cs);
  BOOST_CHECK(s == cs);
  BOOST_CHECK(s == us);

  BOOST_CHECK(!(cs != us));
  BOOST_CHECK(!(cs != s));
  BOOST_CHECK(!(us != s));
  BOOST_CHECK(!(us != cs));
  BOOST_CHECK(!(s != cs));
  BOOST_CHECK(!(s != us));
}

BOOST_AUTO_TEST_CASE(to_string_test) {
  basic_string<wchar_t> ws = L"abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  utf8_string us = ws;
  c_string cs = ws;
  string s1 = us;
  string s2 = cs;
  string s3; s3 = us;
  string s4; s4 = cs;
  BOOST_CHECK(s1 == s3);
  BOOST_CHECK(s2 == s4);
  utf8_string us1 = s1;
  utf8_string us2 = s3;
  c_string cs1 = s2;
  c_string cs2 = s4;
  BOOST_CHECK(ws == cs1);
  BOOST_CHECK(ws == us1);
  BOOST_CHECK(ws == us2);
  BOOST_CHECK(ws == cs1);
  BOOST_CHECK(ws == cs2);
}
BOOST_AUTO_TEST_CASE(to_wstring_test) {
  basic_string<wchar_t> ws = L"abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  utf8_string us = ws;
  c_string cs = ws;
  basic_string<wchar_t> ws1 = us;
  basic_string<wchar_t> ws2 = cs;
  BOOST_CHECK(ws == ws1);
  BOOST_CHECK(ws == ws2);
}

BOOST_AUTO_TEST_CASE(stream_test) {

  basic_string<wchar_t> ws = L"abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  {
    stringstream ss;
    utf8_string us = ws;
    ss << us;
    BOOST_CHECK(ss.str() == us);
  }
  {
    stringstream ss;
    c_string cs = ws;
    ss << cs;
    BOOST_CHECK(ss.str() == cs);
  }
}
BOOST_AUTO_TEST_CASE(wstream_test) {

  basic_string<wchar_t> ws = L"abcdef@%*&(& ?/';{}>\"\\=+_)(&";
  {
    basic_stringstream<wchar_t> wss;
    utf8_string us = ws;
    wss << us;
    BOOST_CHECK(wss.str() == us);
  }
  {
    basic_stringstream<wchar_t> wss;
    c_string cs = ws;
    wss << cs;
    BOOST_CHECK(wss.str() == cs);
  }
}
