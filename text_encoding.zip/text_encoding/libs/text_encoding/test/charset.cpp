#include <boost/test/unit_test.hpp>
#include <boost/text_encoding/charset.hpp>

namespace {
  using namespace boost::text_encoding;
  codecvt_by_charset<charset::utf8> utf_codecvt(1);
  codecvt_by_charset<charset::c> c_codecvt(1);
}
