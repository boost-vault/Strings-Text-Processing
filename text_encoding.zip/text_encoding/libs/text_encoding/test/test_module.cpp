#define BOOST_TEST_MAIN
#include <boost/test/unit_test.hpp>
