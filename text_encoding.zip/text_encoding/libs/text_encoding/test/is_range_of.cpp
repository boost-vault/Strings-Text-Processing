#include <boost/range/is_range_of.hpp>
#include <boost/static_assert.hpp>
#include <vector>
using namespace boost;
BOOST_STATIC_ASSERT(is_range<char [2]>::value);
BOOST_STATIC_ASSERT(!is_range<char>::value);
BOOST_STATIC_ASSERT(is_range<std::vector<char> >::value);
BOOST_STATIC_ASSERT(is_range<const char *>::value);
namespace {
struct t {
};
}
BOOST_STATIC_ASSERT(is_range<t [2]>::value);
BOOST_STATIC_ASSERT(!is_range<t>::value);
BOOST_STATIC_ASSERT(is_range<std::vector<t> >::value);
BOOST_STATIC_ASSERT(!is_range<const t *>::value);

BOOST_STATIC_ASSERT((!is_range_of<const t *, int>::value));
BOOST_STATIC_ASSERT((!is_range_of<const t *, t>::value));
BOOST_STATIC_ASSERT((is_range_of<t const[25], t>::value));
BOOST_STATIC_ASSERT((is_range_of<std::vector<t>, t>::value));
