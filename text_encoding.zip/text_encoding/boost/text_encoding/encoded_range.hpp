#ifndef BOOST_CODED_STRING_ENCODED_RANGE_HPP_INCLUDED
#define BOOST_CODED_STRING_ENCODED_RANGE_HPP_INCLUDED
#include <boost/text_encoding/detail/utf8_codecvt_facet.hpp>
#include <cstring>
#include <cstdio>
#include <boost/throw_exception.hpp>
#include <boost/range.hpp>
#include <boost/limits.hpp>
#include <boost/iterator/iterator_adaptor.hpp>
#include <boost/text_encoding/error.hpp>
#include <boost/text_encoding/charset.hpp>
namespace boost { namespace text_encoding {

  template <typename charsetT, typename input_rangeT>
  class decoded_range {
  public:
    typedef charsetT charset_type;
    typedef input_rangeT input_range_type;
  private:
    typedef decoded_range<charsetT, input_rangeT> self_type;
    typedef codecvt_by_charset<charset_type> codecvt_type;
    typedef typename codecvt_type::extern_type extern_type;
    typedef typename codecvt_type::intern_type intern_type;
    typedef typename codecvt_type::state_type state_type;
    typedef typename boost::range_const_iterator<input_range_type>::type input_iterator_type;
    //codecvt_type& codecvt_;
    input_range_type const & input_range_;
  public:
    class iterator;
    typedef truncated_bytes<iterator> truncated_bytes_error;

    class iterator : public boost::iterator_facade<iterator, intern_type, boost::forward_traversal_tag, intern_type> {
    private:
      typedef self_type decoded_range_type;
      friend class decoded_range<charsetT, input_rangeT>;
      decoded_range_type decoded_range_;
      input_iterator_type current_input_;
      intern_type current_output_;
      extern_type input_buffer_[MB_LEN_MAX];
      std::size_t input_buffer_length_;

      iterator(decoded_range_type r, input_iterator_type i) :
        decoded_range_(r),
        current_input_(i),
        input_buffer_length_(0)
      {
        if(!is_end()) {
          fetch();
        }
      }

      iterator(decoded_range_type r) :
        decoded_range_(r),
        current_input_(boost::end(r.input_range_)),
        input_buffer_length_(EOF)
      {}

      void fetch() {
        while(current_input_ != boost::end(decoded_range_.input_range_) && input_buffer_length_ < MB_LEN_MAX) {
          input_buffer_[input_buffer_length_] = *current_input_;
          input_buffer_length_++;
          current_input_++;
        }
        if(input_buffer_length_ == 0) {
          input_buffer_length_ = EOF;
          return;
        }
        const extern_type* next_input;
        state_type state;
        fill_state<charset_type>(state);
        intern_type* next_output;
        switch(global_codecvt<charset_type>().in(state, input_buffer_, input_buffer_ + input_buffer_length_, next_input, &current_output_, &current_output_ + 1, next_output)) {
          case std::codecvt_base::noconv:
          case std::codecvt_base::ok:
          case std::codecvt_base::partial:
            input_buffer_length_ = input_buffer_length_ - (next_input - input_buffer_);
            std::memmove(input_buffer_, next_input, input_buffer_length_);
            break;
          case std::codecvt_base::error:
            boost::throw_exception(codecvt_error());
            break;
        }
      }
      bool is_end() const {
        return current_input_ == boost::end(decoded_range_.input_range_) && input_buffer_length_ == std::size_t(EOF);
      }
    public:
      bool equal(iterator const & rhs) const {
        return &decoded_range_.input_range_ == &rhs.decoded_range_.input_range_ && ((current_input_ == rhs.current_input_ && input_buffer_length_ == rhs.input_buffer_length_ && current_output_ == rhs.current_output_) || (is_end() && rhs.is_end()));
      }
      intern_type dereference() const {
        BOOST_ASSERT(!is_end());
        return current_output_;
      }
      void increment() {
        if(is_end()) {
          boost::throw_exception(std::out_of_range(""));
        }
        fetch();
      }
    };

    typedef iterator const_iterator;
    iterator begin() const {
      iterator ret(*this, boost::begin(input_range_));
      return ret;
    }
    iterator end() const {
      iterator ret(*this);
      return ret;
    }

    decoded_range(input_range_type const & r) :
      input_range_(r)
    {}

    bool operator == (self_type const & rhs) const {
      return input_range_ == rhs.input_range_;
    }

    bool operator != (self_type const & rhs) const {
      return !(*this == rhs);
    }
  };

  template <typename charsetT, typename input_rangeT>
  class encoded_range {
  public:
    typedef charsetT charset_type;
    typedef input_rangeT input_range_type;
  private:
    typedef encoded_range<charsetT, input_rangeT> self_type;
    typedef codecvt_by_charset<charset_type> codecvt_type;
    typedef typename codecvt_type::extern_type extern_type;
    typedef typename codecvt_type::intern_type intern_type;
    typedef typename codecvt_type::state_type state_type;

    typedef typename boost::range_const_iterator<input_range_type>::type input_iterator_type;
    input_range_type const & input_range_;
  public:
    class iterator;
    typedef truncated_bytes<iterator> truncated_bytes_error;
    class iterator : public boost::iterator_facade<iterator, extern_type, boost::forward_traversal_tag, extern_type> {
    private:
      typedef self_type encoded_range_type;
      friend class encoded_range<charsetT, input_rangeT>;

      encoded_range_type encoded_range_;
      input_iterator_type current_input_;
      extern_type output_buffer_[MB_LEN_MAX];
      std::size_t output_buffer_length_;
      std::size_t current_output_;
      iterator(encoded_range_type r, input_iterator_type i) :
        encoded_range_(r),
        current_input_(i),
        output_buffer_length_(0),
        current_output_(output_buffer_length_)
      {
        if(!is_end()) {
          fetch();
        }
      }

      iterator(encoded_range_type r) :
        encoded_range_(r),
        current_input_(boost::end(encoded_range_.input_range_)),
        current_output_(EOF)
      {
      }

      void fetch() {
        BOOST_ASSERT(current_input_ != boost::end(encoded_range_.input_range_));
        intern_type input = *current_input_;
        const intern_type* next_input;
        state_type state;
        fill_state<charset_type>(state);
        extern_type* output_buffer_end;
        switch(global_codecvt<charset_type>().out(state, &input, &input + 1, next_input, output_buffer_, output_buffer_ + MB_LEN_MAX, output_buffer_end)) {
          case std::codecvt_base::noconv:
          case std::codecvt_base::ok:
            output_buffer_length_ = output_buffer_end - output_buffer_;
            current_output_ = 0;
            break;
          case std::codecvt_base::error:
            boost::throw_exception(codecvt_error());
            break;
          case std::codecvt_base::partial:
            boost::throw_exception(truncated_bytes_error(*this));
            break;
        }
        //++current_input_;
      }
      bool is_end() const {
        return current_input_ == boost::end(encoded_range_.input_range_);
      }
    public:
      bool equal(iterator const & rhs) const {
        return &encoded_range_.input_range_ == &rhs.encoded_range_.input_range_ && ((current_input_ == rhs.current_input_ && current_output_ == rhs.current_output_ && output_buffer_length_ == rhs.output_buffer_length_) || (is_end() && rhs.is_end()));
      }
      extern_type dereference() const {
        BOOST_ASSERT(!is_end());
        return output_buffer_[current_output_];
      }
      void increment() {
        if(is_end()) {
          boost::throw_exception(std::out_of_range(""));
        }
        if(current_output_ + 1 < output_buffer_length_) {
          ++current_output_;
        } else if (++current_input_ != boost::end(encoded_range_.input_range_)) {
          fetch();
        }
      }
    };
    typedef iterator const_iterator;
    iterator begin() const {
      iterator ret(*this, boost::begin(input_range_));
      return ret;
    }
    iterator end() const {
      iterator ret(*this);
      return ret;
    }

    encoded_range(input_range_type const & r) :
      input_range_(r)
    {}

    bool operator == (self_type const & rhs) const {
      return input_range_ == rhs.input_range_;
    }

    bool operator != (self_type const & rhs) const {
      return !(*this == rhs);
    }
  };

  template <typename charsetT, typename input_rangeT>
  encoded_range<charsetT, input_rangeT> make_encoded_range(input_rangeT const& input_range) {
    encoded_range<charsetT, input_rangeT> ret(input_range);
    return ret;
  }

  template <typename charsetT, typename input_rangeT>
  decoded_range<charsetT, input_rangeT> make_decoded_range(input_rangeT const& input_range) {
    decoded_range<charsetT, input_rangeT> ret(input_range);
    return ret;
  }

  namespace result_of {
    template <typename charsetT, typename input_rangeT>
    struct make_coded_range {
    private:
    public:
      typedef typename mpl::if_<
        is_same <
          typename boost::range_value<input_rangeT>::type,
          typename codecvt_by_charset<charsetT>::extern_type
        >,
        decoded_range<charsetT, input_rangeT>,
        typename mpl::if_<
          is_same <
            typename range_value<input_rangeT>::type,
            typename codecvt_by_charset<charsetT>::intern_type
          >,
          encoded_range<charsetT, input_rangeT>,
          void
        >::type
      >::type type;
    };
  };

  template <typename charsetT, typename input_rangeT>
  typename result_of::make_coded_range<charsetT, input_rangeT>::type
  make_coded_range(input_rangeT const& input_range) {
    typedef typename result_of::make_coded_range<charsetT, input_rangeT>::type result_type;
    
    // You must make sure the type of input_range's element is codecvt's intern_type or extern_type, or you will meet an error here. 
    BOOST_STATIC_ASSERT((!boost::is_same<void, result_type>::value));

    result_type ret(input_range);
    return ret;
  }

}}
#endif
