#ifndef BOOST_CODED_STRING_ENCODED_STRING_HPP_INCLUEDED
#define BOOST_CODED_STRING_ENCODED_STRING_HPP_INCLUEDED
#include <boost/text_encoding/charset.hpp>
#include <boost/text_encoding/encoded_range.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>
#include <boost/range.hpp>
#include <boost/range/is_range_of.hpp>
#include <boost/mpl/pair.hpp>
#include <boost/mpl/and.hpp>
#include <boost/mpl/not.hpp>
#include <string>

namespace boost { namespace text_encoding {
template<typename charsetT, typename containerT = std::basic_string<typename codecvt_by_charset<charsetT>::extern_type> >
class encoded_string : public containerT {
public:
  typedef containerT container_type;
  typedef charsetT charset_type;
  typedef codecvt_by_charset<charsetT> codecvt_type;
  typedef typename codecvt_type::intern_type intern_type;
  typedef typename codecvt_type::extern_type extern_type;
  typedef typename codecvt_type::state_type state_type;
  typedef typename container_type::allocator_type allocator_type;
private:
  typedef encoded_string<charset_type, container_type> self_type;

public:
  typedef typename container_type::size_type size_type;

  encoded_string(self_type const & rhs, size_type index = 0, 
    size_type count = container_type::npos, allocator_type allocator = allocator_type()) :
    container_type(rhs, index, count, allocator)
  {}

  template<typename rhs_charsetT, typename rhs_containerT>
  encoded_string(encoded_string<rhs_charsetT, rhs_containerT> const & rhs, allocator_type allocator = allocator_type()) :
    container_type(allocator)
  {
    assignment_operator_impl(rhs);
  }

  encoded_string(container_type const & rhs, size_type index = 0, 
   size_type count = container_type::npos, allocator_type allocator = allocator_type()) :
    container_type(rhs, index, count, allocator)
  {}
  explicit encoded_string(allocator_type allocator = allocator_type()) :
    container_type(allocator)
  {}

  template<typename rangeT>
  encoded_string(rangeT const & r, typename boost::enable_if<boost::is_range_of<rangeT, extern_type>, allocator_type>::type allocator = allocator_type()) :
    container_type(allocator)
  {
    assign(boost::begin(r), boost::end(r));
  }


  template<typename rangeT>
  encoded_string (
    rangeT const & r,
    typename boost::enable_if <
      boost::is_range_of <
        rangeT,
        intern_type
      >,
      allocator_type
    >::type allocator = allocator_type()
  ) :
    container_type(allocator)
  {
    wassign(boost::begin(r), boost::end(r));
  }

  template<typename rangeT>
  self_type& operator=(rangeT const & r) {
    BOOST_STATIC_ASSERT((boost::is_range_of<rangeT, extern_type>::value || boost::is_range_of<rangeT, intern_type>::value));
    assignment_operator_impl(r);
    return *this;
  }

  template<typename iteratorT>
  void wassign(iteratorT begin, iteratorT end) {
    std::pair<iteratorT, iteratorT> input_range = std::make_pair(begin, end);
    assign(boost::begin(make_encoded_range<charsetT>(input_range)), boost::end(make_encoded_range<charsetT>(input_range)));
  }
  //template<typename rangeT>
  //typename boost::enable_if<typename boost::is_range_of<rangeT, intern_type>, self_type&>::type operator=(rangeT const & r) {
  //  assign(boost::begin(make_encoded_range(codecvt_, r)), boost::end(make_encoded_range(codecvt_, r)));
  //  return *this;
  //}

  //template<typename rangeT>
  //typename boost::enable_if<boost::mpl::and_<boost::is_range_of<rangeT, extern_type>, boost::mpl::not_<boost::is_range_of<rangeT, intern_type> > >, self_type&>::type operator=(rangeT const & r) {
  //  assign(boost::begin(r), boost::end(r));
  //  return *this;
  //}

  template<typename CharTraits, typename Allocator>
  operator std::basic_string<intern_type, CharTraits, Allocator>() const {
    std::basic_string<intern_type, CharTraits, Allocator> ret;
    ret.assign(boost::begin(make_decoded_range<charsetT>(*this)), boost::end(make_decoded_range<charsetT>(*this)));
    return ret;
  }


  int wcompare(intern_type const* rhs) const {
    return static_cast<std::basic_string<intern_type> >(*this).compare(rhs);
  }

  template<typename CharTrait, typename Allocator>
  int wcompare(std::basic_string<intern_type, CharTrait, Allocator> const& rhs) const {
    return static_cast<std::basic_string<intern_type, CharTrait, Allocator> >(*this).compare(rhs);
  }

  template<typename rhs_charsetT, typename rhs_containerT>
  int wcompare(encoded_string<rhs_charsetT, rhs_containerT> const& rhs) const {
    return static_cast<std::basic_string<intern_type> >(*this).compare(static_cast<std::basic_string<intern_type> >(rhs));
  }
private:
  template<typename rhs_charsetT, typename rhs_containerT>
  void assignment_operator_impl(encoded_string<rhs_charsetT, rhs_containerT> const & r) {
    assignment_operator_impl(static_cast<std::basic_string<intern_type> const &>(r));
  }
  
  template<typename rangeT>
  void assignment_operator_impl(rangeT const & r, typename boost::enable_if<is_range_of<rangeT, extern_type>, int>::type = 0) {
    assign(boost::begin(r), boost::end(r));
  }

  template<typename rangeT>
  void assignment_operator_impl(rangeT const & r, typename boost::enable_if<is_range_of<rangeT, intern_type>, int>::type = 0) {
    wassign(boost::begin(r), boost::end(r));
  }


};

typedef encoded_string<charset::utf8> utf8_string;
typedef encoded_string<charset::c> c_string;


}}

template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator==(rangeT const & lhs, boost::text_encoding::encoded_string<charsetT, containerT> const & rhs) {
  return rhs.wcompare(lhs) == 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator!=(rangeT const & lhs, boost::text_encoding::encoded_string<charsetT, containerT> const & rhs) {
  return rhs.wcompare(lhs) != 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator<(rangeT const & lhs, boost::text_encoding::encoded_string<charsetT, containerT> const & rhs) {
  return rhs.wcompare(lhs) > 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator>(rangeT const & lhs, boost::text_encoding::encoded_string<charsetT, containerT> const & rhs) {
  return rhs.wcompare(lhs) < 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator<=(rangeT const & lhs, boost::text_encoding::encoded_string<charsetT, containerT> const & rhs) {
  return rhs.wcompare(lhs) >= 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator>=(rangeT const & lhs, boost::text_encoding::encoded_string<charsetT, containerT> const & rhs) {
  return rhs.wcompare(lhs) <= 0;
}

template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator==(boost::text_encoding::encoded_string<charsetT, containerT> const & lhs, rangeT const & rhs) {
  return lhs.wcompare(rhs) == 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator!=(boost::text_encoding::encoded_string<charsetT, containerT> const & lhs, rangeT const & rhs) {
  return lhs.wcompare(rhs) != 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator<(boost::text_encoding::encoded_string<charsetT, containerT> const & lhs, rangeT const & rhs) {
  return lhs.wcompare(rhs) < 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator>(boost::text_encoding::encoded_string<charsetT, containerT> const & lhs, rangeT const & rhs) {
  return lhs.wcompare(rhs) > 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator<=(boost::text_encoding::encoded_string<charsetT, containerT> const & lhs, rangeT const & rhs) {
  return lhs.wcompare(rhs) <= 0;
}
template<typename charsetT, typename containerT, typename rangeT>
typename boost::enable_if<boost::is_range_of<rangeT, typename boost::text_encoding::codecvt_by_charset<charsetT>::intern_type>, bool>::type operator>=(boost::text_encoding::encoded_string<charsetT, containerT> const & lhs, rangeT const & rhs) {
  return lhs.wcompare(rhs) >= 0;
}

template<typename lhs_charsetT, typename lhs_containerT, typename rhs_charsetT, typename rhs_containerT>
bool operator==(boost::text_encoding::encoded_string<lhs_charsetT, lhs_containerT> const & lhs, boost::text_encoding::encoded_string<rhs_charsetT, rhs_containerT> const & rhs) {
  return lhs.wcompare(rhs) == 0;
}
template<typename lhs_charsetT, typename lhs_containerT, typename rhs_charsetT, typename rhs_containerT>
bool operator!=(boost::text_encoding::encoded_string<lhs_charsetT, lhs_containerT> const & lhs, boost::text_encoding::encoded_string<rhs_charsetT, rhs_containerT> const & rhs) {
  return lhs.wcompare(rhs) != 0;
}
template<typename lhs_charsetT, typename lhs_containerT, typename rhs_charsetT, typename rhs_containerT>
bool operator<(boost::text_encoding::encoded_string<lhs_charsetT, lhs_containerT> const & lhs, boost::text_encoding::encoded_string<rhs_charsetT, rhs_containerT> const & rhs) {
  return lhs.wcompare(rhs) < 0;
}
template<typename lhs_charsetT, typename lhs_containerT, typename rhs_charsetT, typename rhs_containerT>
bool operator>(boost::text_encoding::encoded_string<lhs_charsetT, lhs_containerT> const & lhs, boost::text_encoding::encoded_string<rhs_charsetT, rhs_containerT> const & rhs) {
  return lhs.wcompare(rhs) > 0;
}
template<typename lhs_charsetT, typename lhs_containerT, typename rhs_charsetT, typename rhs_containerT>
bool operator<=(boost::text_encoding::encoded_string<lhs_charsetT, lhs_containerT> const & lhs, boost::text_encoding::encoded_string<rhs_charsetT, rhs_containerT> const & rhs) {
  return lhs.wcompare(rhs) <= 0;
}
template<typename lhs_charsetT, typename lhs_containerT, typename rhs_charsetT, typename rhs_containerT>
bool operator>=(boost::text_encoding::encoded_string<lhs_charsetT, lhs_containerT> const & lhs, boost::text_encoding::encoded_string<rhs_charsetT, rhs_containerT> const & rhs) {
  return lhs.wcompare(rhs) >= 0;
}

template<typename internT, typename traitsT, typename charsetT, typename containerT>
typename boost::enable_if<boost::is_same<internT, typename boost::text_encoding::encoded_string<charsetT, containerT>::intern_type>, std::basic_ostream<internT, traitsT>& >::type operator<<(std::basic_ostream<internT, traitsT>& os, boost::text_encoding::encoded_string<charsetT, containerT> const & s) {
  std::locale default_locale;
  std::locale new_locale(default_locale, &boost::text_encoding::template global_codecvt<charsetT>());
  std::locale old_locale = os.imbue(new_locale);
  os << static_cast<std::basic_string<typename boost::text_encoding::encoded_string<charsetT, containerT>::intern_type, traitsT> >(s);
  os.imbue(old_locale);
  return os;
}

template<typename externT, typename traitsT, typename charsetT, typename containerT>
typename boost::enable_if<boost::is_same<externT, typename boost::text_encoding::encoded_string<charsetT, containerT>::extern_type>, std::basic_ostream<externT, traitsT>& >::type operator<<(std::basic_ostream<externT, traitsT>& os, boost::text_encoding::encoded_string<charsetT, containerT> const & s) {
  std::locale default_locale;
  std::locale new_locale(default_locale, &boost::text_encoding::template global_codecvt<charsetT>());
  std::locale old_locale = os.imbue(new_locale);
  os << static_cast<containerT const &>(s);
  os.imbue(old_locale);
  return os;
}

template<typename internT, typename traitsT, typename charsetT, typename containerT>
typename boost::enable_if<boost::is_same<internT, typename boost::text_encoding::encoded_string<charsetT, containerT>::intern_type>, std::basic_istream<internT, traitsT>& >::type operator>>(std::basic_istream<internT, traitsT>& is, boost::text_encoding::encoded_string<charsetT, containerT> & s) {
  std::locale default_locale;
  std::locale new_locale(default_locale, &boost::text_encoding::template global_codecvt<charsetT>());
  std::locale old_locale = is.imbue(new_locale);
  std::basic_string<typename boost::text_encoding::encoded_string<charsetT, containerT>::intern_type, traitsT> ws;
  is >> ws;
  s = ws;
  is.imbue(old_locale);
  return is;
}

template<typename externT, typename traitsT, typename charsetT, typename containerT>
typename boost::enable_if<boost::is_same<externT, typename boost::text_encoding::encoded_string<charsetT, containerT>::extern_type>, std::basic_istream<externT, traitsT>& >::type operator>>(std::basic_istream<externT, traitsT>& is, boost::text_encoding::encoded_string<charsetT, containerT> & s) {
  std::locale default_locale;
  std::locale new_locale(default_locale, &boost::text_encoding::template global_codecvt<charsetT>());
  std::locale old_locale = is.imbue(new_locale);
  is >> static_cast<containerT &>(s);
  is.imbue(old_locale);
  return is;
}
#endif
