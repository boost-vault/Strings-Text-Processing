#ifndef BOOST_TEXT_ENCODING_DETAIL_UTF8_CODECVT_FACET_HPP_INCLUDED
#define BOOST_TEXT_ENCODING_DETAIL_UTF8_CODECVT_FACET_HPP_INCLUDED

#define BOOST_UTF8_BEGIN_NAMESPACE \
  namespace boost { namespace text_encoding { namespace detail { namespace {
#define BOOST_UTF8_DECL
#define BOOST_UTF8_END_NAMESPACE }}}}
#include <boost/detail/utf8_codecvt_facet.hpp>
#include "utf8_codecvt_facet.ipp"
#undef BOOST_UTF8_END_NAMESPACE
#undef BOOST_UTF8_DECL
#undef BOOST_UTF8_BEGIN_NAMESPACE

#endif
