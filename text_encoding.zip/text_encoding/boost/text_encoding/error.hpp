#ifndef BOOST_CODED_STRING_ERROR_HPP_INCLUDED
#define BOOST_CODED_STRING_ERROR_HPP_INCLUDED
#include <boost/limits.hpp>
#include <stdexcept>
namespace boost { namespace text_encoding {

class codecvt_error : public std::bad_cast {
};

template<typename iteratorT>
class truncated_bytes : public codecvt_error {
private:
  iteratorT error_position_;
public:
  truncated_bytes(iteratorT ep) : error_position_(ep) {}
  iteratorT error_position() {
    return error_position_;
  }
};


}}

#endif
