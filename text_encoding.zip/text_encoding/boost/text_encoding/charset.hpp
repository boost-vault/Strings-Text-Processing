#ifndef BOOST_CODED_STRING_CHARSET_HPP_INCLUDED
#define BOOST_CODED_STRING_CHARSET_HPP_INCLUDED
#include <boost/noncopyable.hpp>
#include <locale>
#include "detail/utf8_codecvt_facet.hpp"
namespace boost { namespace text_encoding {

template<typename charsetT>
struct codecvt_by_charset;

//template<typename charsetT>
//struct intern_char {
//  typedef typename codecvt_by_charset<charsetT>::intern_type type;
//};
//template<typename charsetT>
//struct extern_byte {
//  typedef typename codecvt_by_charset<charsetT>::extern_type type;
//};
//template<typename charsetT>
//struct state {
//  typedef typename codecvt_by_charset<charsetT>::state_type type;
//};

template<typename charsetT>
void fill_state(typename codecvt_by_charset<charsetT>::state_type& s) {
  memset(&s, 0, sizeof(typename codecvt_by_charset<charsetT>::state_type));
}

template<typename charsetT>
codecvt_by_charset<charsetT>& global_codecvt() {
  static codecvt_by_charset<charsetT> ret(1);
  return ret;
}

namespace charset {
  struct utf8 {};
  struct c {};
}



template<>
struct codecvt_by_charset<charset::utf8> : detail::utf8_codecvt_facet, boost::noncopyable 
#ifdef BOOST_TEXT_ENCODING_DOXYGEN_INVOKED
, public std::codecvt<wchar_t, char, std::mbstate_t>
#endif
{
  explicit codecvt_by_charset(std::size_t no_locale_manage) :
    detail::utf8_codecvt_facet(no_locale_manage)
  {}
};

template<>
struct codecvt_by_charset<charset::c> : std::codecvt_byname<wchar_t, char, std::mbstate_t>, boost::noncopyable
#ifdef BOOST_TEXT_ENCODING_DOXYGEN_INVOKED
, public std::codecvt<wchar_t, char, std::mbstate_t>
#endif
{
  explicit codecvt_by_charset(std::size_t no_locale_manage) :
    std::codecvt_byname<wchar_t, char, std::mbstate_t>("C", no_locale_manage)
  {}
};


}}

#endif
