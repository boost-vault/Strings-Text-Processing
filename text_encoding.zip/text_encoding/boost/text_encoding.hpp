#ifndef BOOST_TEXT_ENCODING_HPP_INCLUEDED
#define BOOST_TEXT_ENCODING_HPP_INCLUEDED
#include <boost/text_encoding/charset.hpp>
#include <boost/text_encoding/error.hpp>
#include <boost/text_encoding/encoded_range.hpp>
#include <boost/text_encoding/encoded_string.hpp>
#endif
