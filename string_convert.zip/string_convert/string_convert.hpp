// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_HPP
#define STRING_CONVERT_HPP 

#include <locale>
#include "detail/stream_to.hpp"
#include "detail/to_stream.hpp"

namespace string_convert {
  template <typename StringT, size_t Size = BOOST_LOCALE_STREAM_BUFFER_SIZE>
  class basic_string_convert {
      typedef StringT                                        string_type;
      typedef BOOST_DEDUCED_TYPENAME StringT::value_type     char_type;
      typedef BOOST_DEDUCED_TYPENAME StringT::traits_type    traits_type;
      typedef BOOST_DEDUCED_TYPENAME StringT::allocator_type allocator_type;
    public:
      basic_string_convert() 
        : m_stream() { get_flags(); }
      explicit basic_string_convert(
        const std::locale& a_loc
      ) : m_stream() {
        m_stream.imbue(a_loc); get_flags();
      }
      template <typename ModifierT>
      explicit basic_string_convert(
        const ModifierT& a_modifier
      ) : m_stream() {
        m_stream << a_modifier; get_flags();
      }
      template <typename ModifierT>
      basic_string_convert(
        const ModifierT&   a_modifier,
        const std::locale& a_loc
      ) : m_stream() {
        m_stream.imbue(a_loc); m_stream << a_modifier; get_flags();
      }
      template <typename TargetT>
      TargetT string_to(
        const string_type& a_str
      ) {
        reset_istream();
        return detail::stream_to<
          false, false
        >::template from<TargetT>(m_stream.str(&*a_str.begin(), &*a_str.end()));
      }
      template <typename TargetT, typename ValueT>
      TargetT string_to(
        const string_type& a_str,
        const ValueT&      a_val
      ) {
        reset_istream();
        return detail::stream_to<
          false,
          boost::is_convertible<ValueT, TargetT>::value
        >::template from<TargetT>(m_stream.str(&*a_str.begin(), &*a_str.end()), a_val);
      }
      template <typename TargetT, typename ModifierT>
      TargetT from_string(
        const string_type& a_str,
        const ModifierT&   a_modifier,
        const TargetT&     a_def
      ) {
        reset_istream();
        return detail::stream_to<
          false, true
        >::template from<TargetT>(m_stream.str(&*a_str.begin(), &*a_str.end()), a_modifier, a_def);
      }
      template <typename ValueT>
      string_type to_string(
        const ValueT& a_val
      ) {
        reset_ostream();
        detail::to_stream(m_stream, a_val);
        return string_type(m_stream.c_str());
      }
      template <typename ValueT, typename ModifierT>
      string_type to_string(
        const ValueT&    a_val,
        const ModifierT& a_modifier
      ) {
        reset_ostream();
        detail::to_stream(m_stream, a_val, a_modifier);
        return string_type(m_stream.c_str());
      }
      template <typename ValueT>
      const char_type* to_c_str(
        const ValueT& a_val
      ) {
        reset_ostream();
        detail::to_stream(m_stream, a_val);
        return m_stream.c_str();
      }
      template <typename ValueT, typename ModifierT>
      const char_type* to_c_str(
        const ValueT&    a_val,
        const ModifierT& a_modifier
      ) {
        reset_ostream();
        detail::to_stream(m_stream, a_val, a_modifier);
        return m_stream.c_str();
      }
    private:    
      void get_flags() {
        m_flags = m_stream.flags(); m_precision = m_stream.precision();
        m_width = m_stream.width(); m_fill = m_stream.fill();
      }
      void reset_istream() { m_stream.flags(m_flags); m_stream.clear(); }
      void reset_ostream() { 
        m_stream.flags(m_flags); m_stream.precision(m_precision);
        m_stream.width(m_width); m_stream.fill(m_fill);
        m_stream.clear(); m_stream.reset();
      }
    private:
      std::streamsize          m_precision, m_width;
      std::ios_base::fmtflags  m_flags;
      std::ios::char_type      m_fill;
      detail::iosimplestream<
        char_type, Size
      > m_stream;
  };
} // namespace
#endif // STRING_CONVERT_HPP 
