// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_TO_STRING_HPP
#define STRING_CONVERT_TO_STRING_HPP 

#include <locale>
#include <boost/type_traits.hpp>
#include "detail/to_stream.hpp"

namespace string_convert {
  // small string optimization
  const size_t BOOST_LOCALE_STREAM_BUFFER_SIZE = 50;
  
  // basic_to_string
  template <class StringT, typename ValueT>
  StringT basic_to_string(
    const ValueT& a_val
  ) {
    detail::iosimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type,
      BOOST_LOCALE_STREAM_BUFFER_SIZE
    > stream;
    detail::to_stream(stream, a_val);
    return StringT(stream.c_str());
  }

  template <class StringT, typename ValueT>
  StringT basic_to_string(
    const ValueT&      a_val,
    const std::locale& a_loc
  ) {
    detail::iosimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type,
      BOOST_LOCALE_STREAM_BUFFER_SIZE
    > stream;
    detail::to_stream(stream, a_val, a_loc);
    return StringT(stream.c_str());
  }

  template <class StringT, typename ValueT>
  StringT basic_to_string_classic(
    const ValueT& a_val
  ) {
    detail::iosimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type,
      BOOST_LOCALE_STREAM_BUFFER_SIZE
    > stream;
    detail::to_stream(stream, a_val, std::locale::classic());
    return StringT(stream.c_str());
  }

  // std::string specializations
  template <typename ValueT> 
  std::string to_string(const ValueT& a_val) {
    return basic_to_string<std::string, ValueT>(a_val);
  }
  template <typename ValueT> 
  std::string to_string(const ValueT& a_val, const std::locale& a_loc) {
    return basic_to_string<std::string, ValueT>(a_val, a_loc);
  }
  template <typename ValueT> 
  std::string to_string_classic(const ValueT& a_val) {
    return basic_to_string_classic<std::string, ValueT>(a_val);
  }

  // std::wstring specializations
  template <typename ValueT> 
  std::wstring to_wstring(const ValueT& a_val) {
    return basic_to_string<std::wstring, ValueT>(a_val);
  }
  template <typename ValueT> 
  std::wstring to_wstring(const ValueT& a_val, const std::locale& a_loc) {
    return basic_to_string<std::wstring, ValueT>(a_val, a_loc);
  }
  template <typename ValueT> 
  std::wstring to_wstring_classic(const ValueT& a_val) {
    return basic_to_string_classic<std::wstring, ValueT>(a_val);
  }
} // namespace
#endif // STRING_CONVERT_STRING_TO_HPP 
