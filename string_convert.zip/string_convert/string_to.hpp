// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_STRING_TO_HPP
#define STRING_CONVERT_STRING_TO_HPP 

#include <locale>
#include "detail/stream_to.hpp"

namespace string_convert {
  // Single argument version
  template <typename TargetT, typename StringT>
  TargetT string_to(
    const StringT& a_str
  ) {
    detail::isimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type
    > stream(&*a_str.begin(), &*a_str.end());
    return detail::stream_to<
      false, false
    >::template from<TargetT>(stream);
  }
  // 2 argument version. Second argument is one of
  // - locale
  // - stream modifier(s)
  // - default value  
  template <typename TargetT, typename StringT, typename ValueT>
  TargetT string_to(
    const StringT& a_str,
    const ValueT& a_value
  ) {
    detail::isimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type
    > stream(&*a_str.begin(), &*a_str.end());
    return detail::stream_to<
      boost::is_same<ValueT, std::locale>::value,
      boost::is_convertible<ValueT, TargetT>::value
    >::template from<TargetT>(stream, a_value);
  }
  // 3 argument version
  // 2nd      3rd
  // locale   def
  // modifier locale
  // modifier def
  template <typename TargetT, typename StringT, typename Value1T, typename Value2T>
  TargetT string_to(
    const StringT& a_str,
    const Value1T& a_value1,
    const Value2T& a_value2
  ) {
    detail::isimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type
    > stream(&*a_str.begin(), &*a_str.end());
    return detail::stream_to<
      boost::is_same<Value1T, std::locale>::value,
      boost::is_convertible<Value2T, TargetT>::value
    >::template from<TargetT>(stream, a_value1, a_value2);
  }
  // 4 argument version
  template <typename TargetT, typename StringT, typename ModifierT>
  TargetT string_to(
    const StringT&     a_str,
    const ModifierT&   a_modifier,
    const std::locale& a_loc,
    const TargetT&     a_def
  ) {
    detail::isimplestream<
      BOOST_DEDUCED_TYPENAME StringT::value_type
    > stream(&*a_str.begin(), &*a_str.end());
    return detail::stream_to<
      true, true
    >::template from<TargetT>(stream, a_modifier, a_loc, a_def);
  }
  
  template <typename TargetT, typename StringT>
  TargetT string_to_classic(
    const StringT& a_str
  ) {
    return string_to<TargetT>(a_str, std::locale::classic());
  }
  template <typename TargetT, typename StringT>
  TargetT string_to_classic(
    const StringT& a_str,
    const TargetT& a_def
  ) {
    return string_to<TargetT>(a_str, std::locale::classic(), a_def);
  }
  // for completness, also add w-versions
  template <typename TargetT>
  TargetT wstring_to(const std::wstring& a_str) {
    return string_to<TargetT, std::wstring>(a_str);
  }
  template <typename TargetT, typename ValueT>
  TargetT wstring_to(
    const std::wstring& a_str,
    const ValueT& a_value
  ) {
    return string_to<TargetT, std::wstring, ValueT>(a_str, a_value);
  }
  template <typename TargetT, typename Value1T, typename Value2T>
  TargetT wstring_to(
    const std::wstring& a_str,
    const Value1T& a_value1,
    const Value2T& a_value2
  ) {
    return string_to<TargetT, std::wstring, Value1T, Value2T>(
      a_str, a_value1, a_value2
    );
  }
  template <typename TargetT, typename ModifierT>
  TargetT wstring_to(
    const std::wstring& a_str,
    const ModifierT&    a_modifier,
    const std::locale&  a_loc,
    const TargetT&      a_def
  ) {
    return string_to<TargetT, std::wstring, ModifierT>(
      a_str, a_modifier, a_loc, a_def
    );
  }
} // namespace
#endif // STRING_CONVERT_STRING_TO_HPP 
