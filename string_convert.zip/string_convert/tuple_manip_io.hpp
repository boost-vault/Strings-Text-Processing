// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_DETAIL_TUPLE_MANIP_IO_HPP
#define STRING_CONVERT_DETAIL_TUPLE_MANIP_IO_HPP 

namespace string_convert { namespace detail {
#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)
  template<typename CharT, typename TraitsT, typename T1>
  inline std::basic_istream<CharT, TraitsT>& imanip_stream(
    std::basic_istream<CharT, TraitsT>& istr, 
    const boost::tuples::cons<T1, boost::tuples::null_type>& t
  ) {
    return istr >> t.head;
  }
  template<typename CharT, typename TraitsT, typename T1>
  inline std::basic_ostream<CharT, TraitsT>& omanip_stream(
    std::basic_ostream<CharT, TraitsT>& ostr, 
    const boost::tuples::cons<T1, boost::tuples::null_type>& t
  ) {
    return ostr << t.head;
  }
#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
  template<typename CharT, typename TraitsT, typename T1, typename T2>
  inline std::basic_istream<CharT, TraitsT>& imanip_stream(
    std::basic_istream<CharT, TraitsT>& istr, 
    const boost::tuples::cons<T1, T2>& t
  ) {
    return imanip_stream(istr >> t.head, t.tail);
  }
  template<typename CharT, typename TraitsT>
  inline std::basic_istream<CharT, TraitsT>& imanip_stream(
    std::basic_istream<CharT, TraitsT>& istr, 
    const boost::tuples::null_type& 
  ) {
    return istr;
  }

  template<typename CharT, typename TraitsT, typename T1, typename T2>
  inline std::basic_ostream<CharT, TraitsT>& omanip_stream(
    std::basic_ostream<CharT, TraitsT>& ostr, 
    const boost::tuples::cons<T1, T2>& t
  ) {
    return omanip_stream(ostr << t.head, t.tail);
  }
  template<typename CharT, typename TraitsT>
  inline std::basic_ostream<CharT, TraitsT>& omanip_stream(
    std::basic_ostream<CharT, TraitsT>& ostr, 
    const boost::tuples::null_type& 
  ) {
    return ostr;
  }
}} // namespace string_convert::detail

namespace boost { namespace tuples {
  // stream a tuple
  template<class CharT, class TraitsT, class T1, class T2>
  inline std::basic_ostream<CharT, TraitsT>& operator<<(
    std::basic_ostream<CharT, TraitsT>& ostr, 
    const boost::tuples::cons<T1, T2>& t
  ) {
    return string_convert::detail::omanip_stream(ostr, t);
  }
  template<class CharT, class TraitsT, class T1, class T2>
  inline std::basic_ostream<CharT, TraitsT>& operator<<(
    std::basic_ostream<CharT, TraitsT>& ostr, 
    const boost::tuples::null_type& t
  ) {
    return ostr;
  }

  template<class CharT, class TraitsT, class T1, class T2>
  inline std::basic_istream<CharT, TraitsT>& operator>>(
    std::basic_istream<CharT, TraitsT>& istr, 
    const boost::tuples::cons<T1, T2>& t
  ) {
    return string_convert::detail::imanip_stream(istr, t);
  }
  template<class CharT, class TraitsT, class T1, class T2>
  inline std::basic_istream<CharT, TraitsT>& operator>>(
    std::basic_istream<CharT, TraitsT>& istr, 
    const boost::tuples::null_type& t
  ) {
    return istr;
  }
}} // namespace boost::tuples
#endif // STRING_CONVERT_DETAIL_TUPLE_MANIP_IO_HPP 
