// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_DETAIL_TO_STREAM_HPP
#define STRING_CONVERT_DETAIL_TO_STREAM_HPP 

#include <locale>
#include <stdexcept>
#include "simplestream.hpp"

namespace string_convert { namespace detail {
  // check for errors
  template <typename StreamT>
  void ostream_done(StreamT& a_stream) {
    if (a_stream.fail())
      throw std::invalid_argument("locale::to_string"); 
  }

  template <typename StreamT, typename ValueT>
  void to_stream(
    StreamT&      a_stream,
    const ValueT& a_val
  ) {
    a_stream << a_val; ostream_done(a_stream);
  }

  template <typename StreamT, typename ValueT>
  void to_stream(
    StreamT&           a_stream,
    const ValueT&      a_val,
    const std::locale& a_loc
  ) {
    a_stream.imbue(a_loc);
    to_stream(a_stream, a_val);
  }
}} // namespace string_convert::detail

#endif // STRING_CONVERT_DETAIL_TO_STREAM_HPP
