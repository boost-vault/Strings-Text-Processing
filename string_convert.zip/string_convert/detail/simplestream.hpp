// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_DETAIL_SIMPLESTREAM_HPP
#define STRING_CONVERT_DETAIL_SIMPLESTREAM_HPP 

namespace string_convert { namespace detail {
  // simple input only buffer
  // uses externally supplied buffer to avoid copying
  template<typename CharT>
  class basic_isimplebuf : public std::basic_streambuf<CharT> {
    public:
      typedef std::basic_streambuf<CharT>                   base_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::char_type   char_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::int_type    int_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::traits_type traits_type;
    public:
      basic_isimplebuf() { } // delayed construction
      basic_isimplebuf(char_type* a_beg, char_type* a_end) {
        str(a_beg, a_end);
      }
      void str(char_type* a_beg, char_type* a_end) {
        setg(a_beg, a_beg, a_end);
      }
    protected:
      virtual int_type underflow() {
        return (gptr() < egptr()) ?
                traits_type::to_int_type(*gptr()) :
                traits_type::eof();
      }
  };
  // simple(?) bi-directional buffer
  // uses externally supplied input buffer
  // output buffer uses small string optimization (Size parameter)
  // str method replaces input buffer
  // reset method clears output buffer but reuses same buffer
  // c_str method returns pointer to output buffer
  template<typename CharT, unsigned Size>
  class basic_simplebuf
    : public basic_isimplebuf<CharT> {
      typedef basic_isimplebuf<CharT>                       base_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::char_type   char_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::int_type    int_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::traits_type traits_type;
      typedef std::allocator<CharT>                         allocator_type;
    public:
      // initalize output buffer only
      basic_simplebuf() 
        : base_type(), m_bufptr(NULL) { 
        setp(m_buf, m_buf + Size);
      } 
      // initialize both buffers
      basic_simplebuf(char_type* a_beg, char_type* a_end) 
       : base_type(a_beg, a_end), m_bufptr(NULL) {
        setp(m_buf, m_buf + Size);
      }
      const char_type* c_str() { 
        *pptr() = '\0'; return pbase();
      }
      void reset() {
        setp(pbase(), epptr());
      }
      ~basic_simplebuf() { 
        if (m_bufptr) {
          size_t oldsize = (epptr() - pbase())/sizeof(char_type);
          m_alloc.deallocate(m_bufptr, oldsize+1);
        }
      }
    protected:
      virtual int_type overflow(int_type a_ch = traits_type::eof()) {
        if (traits_type::eq_int_type(traits_type::eof(), a_ch))
          return traits_type::not_eof(a_ch);
        if (pptr() >= epptr()) { // buffer full, increase
          int oldsize = static_cast<int>((epptr() - pbase())/sizeof(char_type)); // pbump requires int
          char_type* newbuf = m_alloc.allocate(oldsize * 2 + 1);
          traits_type::copy(newbuf, m_bufptr ? m_bufptr : m_buf, oldsize); 
          setp(newbuf, newbuf + oldsize * 2); pbump(oldsize);
          if (m_bufptr) m_alloc.deallocate(m_bufptr, oldsize + 1);
          m_bufptr = newbuf;
        } 
        *pptr() = traits_type::to_char_type(a_ch); pbump(1);
        return a_ch;
      }
    private:
      char_type*     m_bufptr;
      char_type      m_buf[Size+1]; // small string opt
      allocator_type m_alloc;
  };
  
  // input stream that uses isimplebuf
  // exports str method
  template<typename CharT>
  class isimplestream 
    : public std::basic_istream<CharT> {
      typedef isimplestream<CharT>       this_type;
      typedef std::basic_istream<CharT>  base_type;
      typedef basic_isimplebuf<CharT>    buffer_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::char_type char_type;
    public: /* construction */ 
      isimplestream() 
        : base_type(&m_buffer), m_buffer() {
      }
      isimplestream(const char_type* a_beg, const char_type* a_end)
        : base_type(&m_buffer), m_buffer(const_cast<char_type*>(a_beg),
                                         const_cast<char_type*>(a_end)) { 
      }
      this_type& str(const char_type* a_beg, const char_type* a_end) {
        m_buffer.str(const_cast<char_type*>(a_beg), const_cast<char_type*>(a_end)); return *this;
      } 
    private:
      buffer_type m_buffer;
  };

  // bidirections stream that uses simplebuf
  // exports str, c_str, reset methods
  template<typename CharT, size_t Size>
  class iosimplestream 
    : public std::basic_iostream<CharT> {
      typedef iosimplestream<CharT, Size>  this_type;
      typedef std::basic_iostream<CharT>   base_type;
      typedef basic_simplebuf<CharT, Size> buffer_type;
      typedef BOOST_DEDUCED_TYPENAME base_type::char_type char_type;
    public: /* construction */ 
      iosimplestream() 
        : base_type(&m_buffer), m_buffer() {
      }
      iosimplestream(const char_type* a_beg, const char_type* a_end)
        : base_type(&m_buffer), m_buffer(const_cast<char_type*>(a_beg),
                                         const_cast<char_type*>(a_end)) { 
      }
      this_type& str(const char_type* a_begin, const char_type* a_end) {
        m_buffer.str(const_cast<char_type*>(a_begin), const_cast<char_type*>(a_end));
        return *this;
      } 
      const char_type* c_str() { return m_buffer.c_str(); }
      void reset() { m_buffer.reset(); }
    private:
      buffer_type m_buffer;
  };
}} // namespace string_convert::detail
#endif STRING_CONVERT_DETAIL_SIMPLESTREAM_HPP
