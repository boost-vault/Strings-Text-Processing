// (C) Copyright 2005: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifdef BOOST_MSVC
# pragma once
#endif // BOOST_MSVC
#ifndef STRING_CONVERT_DETAIL_STREAM_TO_HPP
#define STRING_CONVERT_DETAIL_STREAM_TO_HPP

#include <locale>
#include <stdexcept>
#include "simplestream.hpp"

namespace string_convert { namespace detail {
  // check if input streaming worked
  template <typename CharT, typename TraitsT>
  bool parse_failed(std::basic_istream<CharT, TraitsT>& a_stream) {
    if (a_stream.fail()) return true; // error
    if (a_stream.eof())  return false; // ok
    if ((a_stream.flags() & std::ios_base::skipws) == 0) return true; // error
    a_stream >> std::ws;
    return !a_stream.eof(); // ok if eof
  }
  
  // stream into variable, throw if error    
  template <typename TargetT, typename CharT, typename TraitsT>
  TargetT stream_to_value(std::basic_istream<CharT, TraitsT>& a_stream) {
    TargetT val; a_stream >> val;
    if (parse_failed(a_stream))
      throw std::invalid_argument("locale::string_to");
    return val;
  }
  // stream into variable, return default if error
  template <typename TargetT, typename CharT, typename TraitsT>
  TargetT stream_to_value(
    std::basic_istream<CharT, TraitsT>& a_stream, 
    const TargetT&                      a_def
  ) {
    TargetT val; a_stream >> val;
    return parse_failed(a_stream) ? a_def : val;
  }

  template <bool Loc, bool Default> struct stream_to; 
  // locale, no default
  template <> struct stream_to<true, false> {
    template <typename TargetT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const std::locale& a_loc
    ) {
      a_stream.imbue(a_loc);
      return stream_to_value<TargetT>(a_stream);
    }
  };
  // locale, default
  template <> struct stream_to<true, true> {
    template <typename TargetT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const std::locale& a_loc,
      const TargetT&     a_def
    ) {
      a_stream.imbue(a_loc);
      return stream_to_value<TargetT>(a_stream, a_def);
    }
    template <typename TargetT, typename ModifierT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const ModifierT&   a_modifier,
      const std::locale& a_loc,
      const TargetT&     a_def
    ) {
      a_stream.imbue(a_loc);
      return stream_to_value<TargetT>(a_stream >> a_modifier, a_def);
    }
  };
  // no locale, default
  template <> struct stream_to<false, true> {
    template <typename TargetT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const TargetT& a_def
    ) {
      return stream_to_value<TargetT>(a_stream, a_def);
    }
    template <typename TargetT, typename ModifierT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const ModifierT a_modifier,
      const TargetT&  a_def
    ) {
      return from<TargetT, CharT, TraitsT>(a_stream >> a_modifier, a_def);
    }
  };
  // no locale, no default
  template <> struct stream_to<false, false> {
    template <typename TargetT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream
    ) {
      return stream_to_value<TargetT>(a_stream);
    }
    template <typename TargetT, typename ModifierT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const ModifierT& a_modifier
    ) {
      return from<TargetT, CharT, TraitsT>(a_stream >> a_modifier);
    }
    template <typename TargetT, typename ModifierT, typename CharT, typename TraitsT>
    static TargetT from(
      std::basic_istream<CharT, TraitsT>& a_stream,
      const ModifierT&   a_modif,
      const std::locale& a_loc
    ) {
      a_stream.imbue(a_loc);
      return from<TargetT, ModifierT, CharT, TraitsT>(a_stream, a_modif);
    }
  };
}} // namespace string_convert::detail

#endif // STRING_CONVERT_DETAIL_STREAM_TO_HPP
