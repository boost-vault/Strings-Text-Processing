// (C) Copyright 2006: Martin Adrian
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#pragma warning(push)
#pragma warning(disable : 4511 4512 4127)
#include <boost/test/minimal.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
#include <boost/date_time/date_facet.hpp>
#include <boost/tuple/tuple.hpp>
#include "to_string.hpp"
#include "string_to.hpp"
#include "string_convert.hpp"
#include "tuple_manip_io.hpp"
#pragma warning(pop)
using namespace string_convert;
using namespace boost::gregorian;

template <typename CharT>
struct datefacet : 
 public boost::date_time::date_names_put<greg_facet_config, CharT> {
    datefacet(boost::date_time::ymd_order_spec ord) : mord(ord) { }
    virtual boost::date_time::ymd_order_spec do_date_order() const {
      return mord;
    };
    virtual boost::date_time::month_format_spec do_month_format() const {
      return boost::date_time::month_as_integer;
    }
    const boost::date_time::ymd_order_spec mord;
}; 

void string_convert_test() {
  // use dates to check different locales
  const date easter(2006,4,16);
  const std::locale dmyloc(std::locale(std::locale::classic(), 
                                       new datefacet<char>(boost::date_time::ymd_order_dmy)),
                                       new datefacet<wchar_t>(boost::date_time::ymd_order_dmy));
  const std::locale mdyloc(std::locale(std::locale::classic(), 
                                       new datefacet<char>(boost::date_time::ymd_order_us)),
                                       new datefacet<wchar_t>(boost::date_time::ymd_order_us));
  const std::string dmystr("16-04-2006");
  const std::string mdystr("04-16-2006");
  const std::string classicstr("2006-Apr-16");
  const std::wstring wdmystr(L"16-04-2006");
  const std::wstring wmdystr(L"04-16-2006");
  const std::wstring wclassicstr(L"2006-Apr-16");
  std::locale::global(dmyloc); // set dmy as default

  BOOST_CHECK(to_string(123) == "123");
  BOOST_CHECK(to_string(1.23) == "1.23");
  BOOST_CHECK(to_string(easter) == dmystr);

  BOOST_CHECK(to_string(123, mdyloc) == "123");
  BOOST_CHECK(to_string(1.23, mdyloc) == "1.23");
  BOOST_CHECK(to_string(easter, mdyloc) == mdystr);

  BOOST_CHECK(to_string_classic(123) == "123");
  BOOST_CHECK(to_string_classic(1.23) == "1.23");
  BOOST_CHECK(to_string_classic(easter) == classicstr);

  BOOST_CHECK(to_wstring(123) == L"123");
  BOOST_CHECK(to_wstring(1.23) == L"1.23");
  BOOST_CHECK(to_wstring(easter) == wdmystr);

  BOOST_CHECK(to_wstring(123, mdyloc) == L"123");
  BOOST_CHECK(to_wstring(1.23, mdyloc) == L"1.23");
  BOOST_CHECK(to_wstring(easter, mdyloc) == wmdystr);

  BOOST_CHECK(to_wstring_classic(123) == L"123");
  BOOST_CHECK(to_wstring_classic(1.23) == L"1.23");
  BOOST_CHECK(to_wstring_classic(easter) == wclassicstr);

  BOOST_CHECK(to_string(boost::make_tuple(&std::hex, 123)) == "7b");
  BOOST_CHECK(to_string(boost::make_tuple(&std::fixed, std::setprecision(1), 1.23)) == "1.2");

  BOOST_CHECK(string_to<int>(std::string("123")) == 123);
  BOOST_CHECK(string_to<double>(std::string("1.23")) == 1.23);
//  BOOST_CHECK(string_to<date>(dmystr) == easter);

  BOOST_CHECK(string_to<int>(std::string("123"), mdyloc) == 123);
  BOOST_CHECK(string_to<double>(std::string("1.23"), mdyloc) == 1.23);
//  BOOST_CHECK(string_to<date>(mdystr, mdyloc) == easter);

  BOOST_CHECK(string_to<int>(std::string("7b"), &std::hex) == 123);
//  BOOST_CHECK(string_to<double>(std::string("1.23")) == 1.23);
//  BOOST_CHECK(string_to<date>(dmystr) == easter);
  
  BOOST_CHECK(string_to<int>(std::string("abc"), 123) == 123);
  BOOST_CHECK(string_to<int>(std::string("7b"), &std::hex, mdyloc) == 123);
  BOOST_CHECK(string_to<int>(std::string("xx"), &std::hex, 123) == 123);
  BOOST_CHECK(string_to<int>(std::string("ab"), mdyloc, 123) == 123);

  BOOST_CHECK(string_to<int>(std::string("xx"), &std::hex, mdyloc, 123) == 123);

  basic_string_convert<std::string> conv;
  BOOST_CHECK(conv.to_string(123) == "123");
  BOOST_CHECK(conv.to_string(1.23) == "1.23");
  BOOST_CHECK(conv.to_string(easter) == dmystr);
  return;
}

int test_main(int, char** const) {
  string_convert_test();
  return 0;
}
