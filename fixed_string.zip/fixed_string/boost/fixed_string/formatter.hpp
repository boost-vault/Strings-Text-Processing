// (C) Copyright 2003-2005: Reece H. Dunn
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FORMATTER_HPP
#define BOOST_FORMATTER_HPP

#if ( defined(_MSC_VER) && (_MSC_VER >= 1020)) || defined(__WAVE__)
#  pragma once
#endif

#include <boost/fixed_string/fixed_string.hpp>
#include <cstdarg>

namespace boost
{

/** @brief A printf-style function object to help simplify string formatting.
  */

template
<
   size_t n, typename CharT = char,
   class CharStringTraits = std::char_traits< CharT >,
   class FmtPolicy = detail::format_policy< CharT >
>
struct formatterex: public fixed_string< n, CharT, CharStringTraits, FmtPolicy >
{
   /** @brief Format the string buffer using printf-style semantics.
     *
     * @param fs  The format string. See the printf documentation for details
     *    on the format specifiers available.
     * @param ... The format string arguments.
     * @return    This object that contains the formatted string.
     */

   formatterex & operator()( const char * fs ... )
   {
      va_list args;
      va_start( args, fs );
      format( fs, args );
      va_end( args );

      return *this;
   }

   /** @brief Format the string buffer using printf-style semantics.
     *
     * @param fs  The format string. See the printf documentation for details
     *    on the format specifiers available.
     * @param ... The format string arguments.
     */

   formatterex( const char * fs ... )
   {
      va_list args;
      va_start( args, fs );
      format( fs, args );
      va_end( args );
   }

   /** @brief Create a string buffer to hold the formatted string. */

   formatterex() throw()
   {
   }
};

/** @brief A 512 narrow-character buffer formatting object. */

typedef formatterex< 512 > formatter;

/** @brief A 512 wide-character buffer formatting object. */

typedef formatterex< 512, wchar_t > wformatter;

}

#endif
