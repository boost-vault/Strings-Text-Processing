// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// detail.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the 
// Boost Software License, Version 1.0. (See accompanying file 
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_STRINGS_DETAIL_HPP_INCLUDED
#define BOOST_STRINGS_DETAIL_HPP_INCLUDED

//#include <boost/config.hpp>
//#undef BOOST_HAS_THREADS
#define BOOST_USE_ASM_ATOMIC_H
#include <boost/detail/atomic_count.hpp>
#include <boost/intrusive_ptr.hpp>
#include "strings_fwd.hpp"

namespace boost { namespace strings {

  template<typename CharT, typename Traits, class StringClass>
  class mutable_operations;
  
  namespace detail {
    template<typename CharT, typename Traits>
    struct repr {
      boost::detail::atomic_count refs_;
      unsigned capacity_;
      unsigned length_;
      CharT data_[];

      static unsigned adjust(unsigned sz, unsigned& capacity) {
	sz+=sizeof(repr);
	sz=(sz+7)&~7;
	capacity=sz-sizeof(repr);
	return sz;
      }

      static repr * allocate(unsigned sz) {
	unsigned capax=0;
	repr * res=static_cast<repr*>(::calloc(adjust(sz,capax),1));
	res->capacity_=capax;
	//new(res) repr();
	return res;
      }

      static void deallocate(repr * r) {
	::free(r);
      }

      static repr * reallocate(repr * ptr, unsigned nsz) {
	if(!ptr) return allocate(nsz);
	unsigned ln = ptr->length_;
	if(nsz < ln + (ln >> 1))
	  nsz = ln + (ln >> 1);
	repr * nrep = allocate(nsz);
	Traits::copy(nrep->data_,ptr->data_,ln);
	nrep->length_ = ln;
	deallocate(ptr);
	return nrep;
      }
    };

    template<typename CharT, typename Traits>
    inline void intrusive_ptr_add_ref(repr<CharT,Traits> *r) { ++r->refs_; }

    template<typename CharT, typename Traits>
    inline void intrusive_ptr_release(repr<CharT,Traits> *r) { 
      if(!--r->refs_) repr<CharT,Traits>::deallocate(r); 
    }

    template<typename CharT, typename Traits>
    class internals {
      friend class temp_string<CharT,Traits>;
      typedef repr<CharT, Traits> repr_t;
      intrusive_ptr<repr_t> rep;
      CharT* begin_;
      CharT* end_;
      static CharT zero_;
    public:
      internals(const intrusive_ptr<repr_t>& r)
	:rep(r),begin_(r?r->data_:&zero_),end_(r?r->data_+r->length_:&zero_) {}

      internals(intrusive_ptr<repr_t>& r):begin_(r?r->data_:&zero_),end_(r?r->data_+r->length_:&zero_) {
	rep.swap(r);
      }

      internals(const CharT * s=0):begin_(&zero_),end_(&zero_) {
	if(s) {
	  unsigned sz=Traits::length(s);
	  if(sz) {
	    rep=repr_t::allocate(sz+1);
	    Traits::copy(rep->data_,s,sz);
	    rep->length_=sz;

	    begin_=rep->data_;
	    end_=rep->data_+sz;
	  }

	}
      }

      void clear() {
	rep=0;
	begin_=&zero_;
	end_=&zero_;
      }

      void move_to(internals &other) {
	rep.swap(other.rep);
	other.begin_=begin_;
	other.end_=end_;
	clear();
      }

      bool unique() const { return !rep || rep->refs_==1; }
      unsigned size() const { return end_-begin_; }
      unsigned capacity() const { return rep?rep->capacity_:0; }

      internals clone() const {
	unsigned sz=size();
	intrusive_ptr<repr_t> r;
	if(sz) {
	  r=repr_t::allocate(sz+1);
	  Traits::copy(r->data_,begin_,sz);
	  r->length_=rep->length_;
	}
	return internals(r);
      }

      void assign(const internals& o) {
	unsigned sz=o.size();
	if(capacity()>sz) {
	  Traits::copy(begin_,o.begin(),sz);
	  rep->length_=sz;
	  end_=begin_+sz;
	} else {
	  clear();
	  *this=o.clone();
	}
      }

      void reserve(unsigned newsize) {
	if(!rep) {
	  *this=internals(repr_t::allocate(newsize));
	  return;
	}
	if(capacity()<=newsize) {
	  repr_t * ptr= rep.get();
	  ++ptr->refs_;
	  clear();
	  *this=internals(repr_t::reallocate(ptr,newsize));
	}	
      }

      void append(const CharT *b, const CharT *e) {
	unsigned sz=e-b;
	if(!sz) return;
	reserve(size() + sz);

	Traits::copy(end_,b,sz);
	rep->length_+=sz;
	end_+=sz;
      }

      void normalize() { *end_=CharT(); }

      CharT * begin() const { return begin_; }
      CharT * end() const { return end_; }
    };

    template<typename CharT, typename Traits>
    CharT internals<CharT,Traits>::zero_=CharT();



    template<typename CharT, typename Traits>
    class rep_accessor {
      friend class mutable_operations<CharT,Traits,temp_string<CharT,Traits> >;
      friend class mutable_operations<CharT,Traits,string_builder<CharT,Traits> >;
      template<typename T>
      static typename T::internals_t&
      rep(T* t) { return t->rep; }

      template<typename T>
      static typename T::internals_t const&
      rep(const T* t) { return t->rep; }

    };
  }
}}
#endif
