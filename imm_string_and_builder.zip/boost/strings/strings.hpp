// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// strings.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the 
// Boost Software License, Version 1.0. (See accompanying file 
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_STRINGS_STRINGS_HPP_INCLUDED
#define BOOST_STRINGS_SRTINGS_HPP_INCLUDED

#include "detail.hpp"
#include <string>

namespace boost { namespace strings {

  template<typename CharT, typename Traits, class StringClass>
  class mutable_operations {
    typedef detail::internals<CharT,Traits > internals_t;
    internals_t& rep();
    const internals_t& rep() const;
  public:
    typedef Traits             traits_type;
    typedef typename Traits::char_type value_type;
    typedef unsigned	       size_type;
    typedef int		       difference_type;
    typedef CharT&	       reference;
    typedef const CharT&       const_reference;
    typedef CharT*	       pointer;
    typedef const CharT*       const_pointer;
    typedef CharT*             iterator;
    typedef const CharT *      const_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
    typedef std::reverse_iterator<iterator>	  reverse_iterator;

    unsigned size() const { return rep.size(); }
    unsigned capacity() const { return rep.capacity(); }

    void reserve(unsigned new_cap) { rep()->reserve(new_cap); }

    StringClass& append(const temp_string<CharT,Traits >&);
    StringClass& append(const imm_string<CharT,Traits >&);
    StringClass& append(const string_builder<CharT,Traits >&);

    reference operator[](unsigned i) { return *(rep().begin()+i); }
    pointer   data() { return rep().begin(); }
    iterator  begin() { return rep().begin(); }
    iterator  end() { return rep().end(); }

    const_iterator cbegin() const { return rep().begin(); }
    const_iterator cend() const { return rep().end(); }

    // mutating operators and methods are defined in terms of temp_string
    template<typename S2>
    StringClass& operator+=(const S2& r) {
      return append(r);
    }

  protected:
    template<typename T>
    static internals_t const&
    get_rep(const T* t) { return detail::rep_accessor<CharT,Traits>::rep(t); }

  };

  // the moveable, temporary string
  // invariant: rep has only one ref
  template<typename CharT, typename Traits>
  class temp_string : public mutable_operations<CharT, Traits, temp_string<CharT, Traits > > {
    typedef detail::internals<CharT, Traits > internals_t;
    mutable internals_t rep;
    friend class detail::rep_accessor<CharT,Traits>;
  private: // used only by other two classes in release()
    temp_string(const internals_t& r):rep(r) {}
    friend class imm_string<CharT,Traits>;
    friend class string_builder<CharT,Traits>;
  public:
    typedef Traits             traits_type;
    typedef typename Traits::char_type value_type;
    typedef unsigned	       size_type;
    typedef int		       difference_type;
    typedef CharT&	       reference;
    typedef const CharT&       const_reference;
    typedef CharT*	       pointer;
    typedef const CharT*       const_pointer;
    typedef CharT*             iterator;
    typedef const CharT *      const_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
    typedef std::reverse_iterator<iterator>	  reverse_iterator;
    
    
    temp_string(const CharT *s):rep(s) {}
    temp_string(const std::string& s) {
      unsigned sz=s.size();
      const char *ptr=s.c_str();
      rep.append(ptr,ptr+sz);
    }

    temp_string(const temp_string& t) { t.move_to(rep); } // move semantics
    temp_string(const string_builder<CharT,Traits>&r);               // always deep copy builders
    temp_string(const imm_string<CharT,Traits>&r);                   // deep copy here

    // this is called when the ownership of the rep is moved
    void move_to(internals_t& orep) const { rep.move_to(orep); }
    temp_string& operator=(const temp_string& t) { t.move_to(rep); return *this; }

    // release is identity on temp_string
    temp_string& release() { return *this; }
    // release is ok also on const temp_string
    temp_string<CharT,Traits> release() const {
      internals_t t;
      rep.move_to(t);
      return temp_string<CharT, Traits >(t);
    }
  };

  // the immutable string behaves as const char *
  // the content cannot be changed, but you can assign a new content to it.
  // release() can be used when we want cast from a string type to an other,
  // destroying the source (it is a move-semantic cast).
  // otherwise cast is implicit, but does deep copy
  template<typename CharT, typename Traits>
  class imm_string {
    typedef detail::internals<CharT, Traits > internals_t;
    internals_t rep;
    friend class detail::rep_accessor<CharT,Traits>;
  public:
    typedef Traits             traits_type;
    typedef typename Traits::char_type value_type;
    typedef unsigned	       size_type;
    typedef int		       difference_type;
    typedef const CharT&       reference;
    typedef const CharT&       const_reference;
    typedef const CharT*       pointer;
    typedef const CharT*       const_pointer;
    typedef const CharT*       iterator;
    typedef const CharT*       const_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
    typedef std::reverse_iterator<iterator>	  reverse_iterator;


    imm_string(const temp_string<CharT,Traits>& t) { t.move_to(rep); rep.normalize(); } // move temp->imm
    imm_string& operator=(const temp_string<CharT,Traits>& t) {
      t.move_to(rep);
      rep.normalize();
      return *this;
    }

    // autogenerated copy constructor and operator= do shallow copy
    value_type operator[](unsigned i) const { return *(rep.begin()+i); }
    const CharT * c_str() const { return rep.begin(); }
    const_iterator begin() const { return rep.begin(); }
    const_iterator end() const { return rep.end(); }
    unsigned size() const { return rep.size(); }

    temp_string<CharT,Traits> release() { // see comment above the class declaration
      internals_t t;
      rep.move_to(t);
      if(t.unique()) return temp_string<CharT, Traits >(t);
      return temp_string<CharT,Traits>(t.clone());
    }

    // mutating operators and methods on the whole string are defined in terms of temp_string
    template<typename S2>
    imm_string& operator+=(const S2& r) {
      temp_string<CharT,Traits> t(release());
      this->operator=(t+r);
      return *this;
    }

    template<typename S2>
    imm_string&append(const S2& r) {
      temp_string<CharT,Traits> t(release());
      this->operator=(t.append(r));
      return *this;
    }
  };

  // the string builder behaves as vector<char>
  // the content can be changed, but you can assign a new content to it
  // invariant: rep has only one ref 
  // release() can be used when we want cast from a string type to an other,
  // destroying the source (it is a move-semantic cast).
  template<typename CharT, typename Traits>
  class string_builder : public mutable_operations<CharT, Traits, string_builder<CharT, Traits > > {
    typedef detail::internals<CharT, Traits> internals_t;
    internals_t rep;
    friend class detail::rep_accessor<CharT,Traits>;
  public:
    string_builder(const temp_string<CharT,Traits>& t) { t.move_to(rep); } // move temp-> builder
    string_builder(const string_builder&r):rep(r.rep.clone()) {} // always deep copy builders
    string_builder& operator=(const temp_string<CharT,Traits>& t) {
      t.move_to(rep); 
      return *this;
    }

    string_builder& operator=(const string_builder& t) {
      rep.assign(t.rep);
      return *this;
    }

    temp_string<CharT,Traits> release() { // see comment above the class declaration
      internals_t t;
      rep.move_to(t);
      // we can assume as invariant that string_builder always owns the rep (refcount==1)
      return temp_string<CharT,Traits>(t);
    }

  };

  template<typename CharT, typename Traits>
  inline temp_string<CharT,Traits>::temp_string(const string_builder<CharT, Traits>&r)
    :rep(get_rep(&r).clone()) {} // always deep copy builders
  template<typename CharT, typename Traits>
  inline temp_string<CharT,Traits>::temp_string(const imm_string<CharT, Traits >&r)
    :rep(get_rep(&r).clone()) {} // deep copy here

  // all free functions and free operators return temp_string
  template<typename S1,typename S2>
  inline temp_string<typename S1::value_type,typename S1::traits_type> operator +(const S1& a, const S2& b) {
    temp_string<typename S1::value_type,typename S1::traits_type> r(a);
    r.append(b);
    return r;
  }

  template<typename CharT, typename Traits, class StringClass>
  inline typename mutable_operations<CharT, Traits,StringClass>::internals_t& 
  mutable_operations<CharT,Traits,StringClass>::rep() {
    return detail::rep_accessor<CharT,Traits>::rep(static_cast<StringClass*>(this)); 
  }

  template<typename CharT, typename Traits, class StringClass>
  inline typename mutable_operations<CharT, Traits,StringClass>::internals_t const& 
  mutable_operations<CharT,Traits,StringClass>::rep() const {
    return detail::rep_accessor<CharT,Traits>::rep(static_cast<const StringClass*>(this)); 
  }

  template<typename CharT, typename Traits, class StringClass>
  inline StringClass& mutable_operations<CharT, Traits, StringClass>::append(const temp_string<CharT,Traits >& o) {
    rep().append(o.cbegin(), o.cend());
    return *static_cast<StringClass*>(this);
  }
  template<typename CharT, typename Traits, class StringClass>
  inline StringClass& mutable_operations<CharT, Traits, StringClass>::append(const imm_string<CharT,Traits >& o) {
    rep().append(o.begin(), o.end());
    return *static_cast<StringClass*>(this);
  }
  template<typename CharT, typename Traits, class StringClass>
  inline StringClass& mutable_operations<CharT, Traits, StringClass>::append(const string_builder<CharT,Traits >& o) {
    rep().append(o.begin(), o.end());
    return *static_cast<StringClass*>(this);
  }

  template<typename CharT, typename Traits>
  inline std::basic_ostream<CharT,Traits> & operator <<(std::basic_ostream<CharT,Traits>& o,
						 imm_string<CharT, Traits> s) {
    o.write(s.begin(),s.size());
    return o;
  }

  template<typename CharT, typename Traits>
  inline std::basic_ostream<CharT,Traits> & operator <<(std::basic_ostream<CharT,Traits>& o,
						 temp_string<CharT, Traits> s) {
    o.write(s.begin(),s.size());
    return o;
  }

  template<typename CharT, typename Traits>
  inline std::basic_ostream<CharT,Traits> & operator <<(std::basic_ostream<CharT,Traits>& o,
						 string_builder<CharT, Traits> s) {
    o.write(s.begin(),s.size());
    return o;
  }

}}
#endif
