// -*- C++ -*-
///////////////////////////////////////////////////////////////////////////////////////////////
// strings_fwd.hpp

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the 
// Boost Software License, Version 1.0. (See accompanying file 
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_STRINGS_STRINGS_FWD_HPP_INCLUDED
#define BOOST_STRINGS_SRTINGS_FWD_HPP_INCLUDED

namespace std {
  template<typename CharT>
  class char_traits;
  
  template<typename CharT, typename Traits>
  class basic_ostream;
}

namespace boost { namespace strings {
  template<typename CharT, typename Traits=std::char_traits<CharT> >
  class imm_string;
  template<typename CharT, typename Traits=std::char_traits<CharT> >
  class temp_string;
  template<typename CharT, typename Traits=std::char_traits<CharT> >
  class string_builder;

  template<typename CharT, typename Traits>
  std::basic_ostream<CharT,Traits> & operator <<(std::basic_ostream<CharT,Traits>& o,
						 imm_string<CharT, Traits> s);
  template<typename CharT, typename Traits>
  std::basic_ostream<CharT,Traits> & operator <<(std::basic_ostream<CharT,Traits>& o,
						 temp_string<CharT, Traits> s);
  template<typename CharT, typename Traits>
  std::basic_ostream<CharT,Traits> & operator <<(std::basic_ostream<CharT,Traits>& o,
						 string_builder<CharT, Traits> s);
}}
#endif
