///////////////////////////////////////////////////////////////////////////////////////////////
// main.cc

// Copyright (c) 2006 Corrado Zoccolo
//
// Use, modification and distribution are subject to the 
// Boost Software License, Version 1.0. (See accompanying file 
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include "../strings.hpp"
#include <boost/timer.hpp>

using namespace boost::strings;
using namespace std;

enum { NUM_TESTS=10000000 };

template<typename T>
void test0(T& str) {
  boost::timer t;
  int sum=0;
  for(int i=0;i<NUM_TESTS;++i)
    sum+=fun0(str);
  std::cout<<"Took "<<t.elapsed()<<" s  on "<<typeid(str).name() << " # "<<sum<<std::endl;
}

template<typename T>
void test(T& str) {
  boost::timer t;
  int sum=0;
  for(int i=0;i<NUM_TESTS;++i)
    sum+=fun(str);
  std::cout<<"Took "<<t.elapsed()<<" s  on "<<typeid(str).name() << " # "<<sum<<std::endl;
}

template<typename T>
void testR(T& str) {
  boost::timer t;
  int sum=0;
  for(int i=0;i<NUM_TESTS;++i)
    sum+=funR(str);
  std::cout<<"Took "<<t.elapsed()<<" s  on "<<typeid(str).name() << " # "<<sum<<std::endl;
}

template<typename T>
void test_temp_string(T& str) {
  boost::timer t;
  for(int i=0;i<NUM_TESTS;++i)
    fun_move(str);
  std::cout<<"Took "<<t.elapsed()<<" s  on "<<typeid(str).name() << std::endl;
}

template<typename T>
void test_move(T& str) {
  boost::timer t;
  for(int i=0;i<NUM_TESTS;++i)
    str=fun_move(str.release());
  std::cout<<"Took "<<t.elapsed()<<" s  on "<<typeid(str).name() <<std::endl;
}

int main() {
  const char * c_s="ciao";
  imm_string<char> i_s("ciao");
  string_builder<char> s_b("ciao");
  std::string s_s("ciao");

  std::cout<<"Baseline (const char *, without atomic count)"<<std::endl;
  test0(c_s);
  std::cout<<"Baseline (const char *, with atomic count)"<<std::endl;
  test(c_s);

  std::cout<<"Pass by value"<<std::endl;
  test(i_s);
  test(s_b);
  test(s_s);

  std::cout<<"Pass by reference"<<std::endl;
  testR(i_s);
  testR(s_b);
  testR(s_s);

  i_s+="aa";
  s_b+="aa";
  s_s+="aa";
  std::cout<<"Modified, Pass by value"<<std::endl;
  test(i_s);
  test(s_b);
  test(s_s);

  std::cout<<"Modified, Pass by reference"<<std::endl;
  testR(i_s);
  testR(s_b);
  testR(s_s);

  {
    temp_string<char> t=i_s.release();
    t[0]='a';
    i_s=t;
  }

  s_b[0]='a';
  s_s[0]='a';

  std::cout<<"Leaked, Pass by value"<<std::endl;
  test(i_s);
  test(s_b);
  test(s_s);

  std::cout<<"Leaked, Pass by reference"<<std::endl;
  testR(i_s);
  testR(s_b);
  testR(s_s);

  std::cout<<"Temp String, with copy"<<std::endl;
  test_temp_string(i_s);
  test_temp_string(s_b);
  test_temp_string(s_s); // allowed from std::string

  std::cout<<"Temp String, Move semantics"<<std::endl;
  test_move(i_s);
  test_move(s_b);

  s_b+=i_s;
}


int fun0(const char* a) {
  int s=0;
  while(*a) s+=*a++;
  return s;
}

int fun(const char* a) {
  boost::detail::atomic_count refs_(0);
  int s=0;
  ++refs_;
  while(*a) s+=*a++;
  --refs_;
  return s;
}

int fun(imm_string<char> a) {
  int s=0;
  for(imm_string<char>::iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return s;
}

int fun(string_builder<char> a) {
  int s=0;
  for(string_builder<char>::iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return s;
}

temp_string<char> fun_move(temp_string<char> a) {
  int s=0;
  for(temp_string<char>::iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return a;
}

int fun(std::string a) {
  int s=0;
  for(std::string::iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return s;
}

int funR(const imm_string<char>& a) {
  int s=0;
  for(imm_string<char>::iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return s;
}

int funR(string_builder<char>& a) {
  int s=0;
  for(string_builder<char>::iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return s;
}

int funR(const std::string& a) {
  int s=0;
  for(std::string::const_iterator i=a.begin(); i!= a.end(); ++i) {
    s+=*i;
  }
  return s;
}
