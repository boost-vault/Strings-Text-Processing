#ifndef EXPERIMENTS3_TAG_KIND_ARITY_HPP
#define EXPERIMENTS3_TAG_KIND_ARITY_HPP
#include "tag_kinds.hpp"
namespace boost{namespace proto{namespace tags{

  /// \brief
  /// Representation of tag in an expression tree.
  ///
  /// \c Tag is type that represents the operation encoded by
  ///             this expvession. It is typically one of the structs
  ///             in the \c boost::proto::tag namespace, but it doesn't
  ///             have to be. If the \c Tag type is \c boost::proto::tag::terminal
  ///             then this \c expv\<\> type represents a leaf in the
  ///             expvession tree.
  ///
  /// \c TagKind is the kind of expression (see tag_kinds.hpp).
  ///
  /// \c Arity is the arity of the operation. I.e. the number of
  ///             children types that must be provided for the operation.
  template
  < class Tag
  , tag_kinds TagKind
  , unsigned Arity
  >
struct tag_kind_arity
{
};

}}}//exit boost::proto::tags
#endif

