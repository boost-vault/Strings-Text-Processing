#ifndef EXPERIMENTS3_TAG_KINDS_HPP
#define EXPERIMENTS3_TAG_KINDS_HPP
namespace boost{namespace proto{namespace tags{
/// \brief
/// Enumeration of different tag kinds
enum tag_kinds
{ tag_valu //expression contains values, i.e. actual member variables.
, tag_gram //expression grammar tag
, tag_pred //predicate grammar tag
};

}}}//exit boost::proto::tags
#endif

