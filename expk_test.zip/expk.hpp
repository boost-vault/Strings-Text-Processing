#ifndef BOOST_PP_IS_ITERATING
//Purpose:
//  Prototype using tags with arities instead of separate
//  arity in the expr template.
//ChangeLog:
//  2008-03-29.0650
//    WHAT:
//      cp'ed from proto/expr.hpp
//    WHY:
//      Preparation for modifying to use tag_arity instead of just tag
//      as first arg.  Will rename to expk (expression values) to
//      avoid name conflict.
//
//***BelowHere** is where proto/expr.hpp (except for 1st line) was copied.
    ///////////////////////////////////////////////////////////////////////////////
    /// \file expk.hpp
    /// Contains definition of expk\<\> class template.
    //
    //  Copyright 2008 Eric Niebler. Distributed under the Boost
    //  Software License, Version 1.0. (See accompanying file
    //  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

    #ifndef BOOST_PROTO_EXPK_HPP_EAN_04_01_2005
    #define BOOST_PROTO_EXPK_HPP_EAN_04_01_2005

    #include <boost/proto/detail/prefix.hpp>
    #include <boost/preprocessor/cat.hpp>
    #include <boost/preprocessor/arithmetic/inc.hpp>
    #include <boost/preprocessor/arithmetic/dec.hpp>
    #include <boost/preprocessor/selection/max.hpp>
    #include <boost/preprocessor/iteration/iterate.hpp>
    #include <boost/preprocessor/facilities/intercept.hpp>
    #include <boost/preprocessor/repetition/repeat.hpp>
    #include <boost/preprocessor/repetition/repeat_from_to.hpp>
    #include <boost/preprocessor/repetition/enum_trailing.hpp>
    #include <boost/preprocessor/repetition/enum_params.hpp>
    #include <boost/preprocessor/repetition/enum_binary_params.hpp>
    #include <boost/preprocessor/repetition/enum_trailing_params.hpp>
    #include <boost/preprocessor/repetition/enum_trailing_binary_params.hpp>
    #include <boost/utility/result_of.hpp>
    #include <boost/utility/addressof.hpp>
    
    #include "proto_fwd.hpp"
    #include "tag_kind_arity.hpp"
    #include <boost/mpl/has_xxx.hpp>
    #include <boost/mpl/assert.hpp>
    
    #include <boost/proto/ref.hpp>
    #include <boost/proto/args.hpp>
    #include <boost/proto/traits.hpp>
    #include <boost/proto/detail/suffix.hpp>

    #if defined(_MSC_VER) && (_MSC_VER >= 1020)
    # pragma warning(push)
    # pragma warning(disable : 4510) // default constructor could not be generated
    # pragma warning(disable : 4512) // assignment operator could not be generated
    # pragma warning(disable : 4610) // user defined constructor required
    #endif

    namespace boost { namespace proto
    {

        namespace detail
        {
        /// INTERNAL ONLY
        ///
        #define BOOST_PROTO_ARG(z, n, data)                                                         \
            typedef typename Args::BOOST_PP_CAT(arg, n) BOOST_PP_CAT(proto_arg, n);                 \
            BOOST_PP_CAT(proto_arg, n) BOOST_PP_CAT(arg, n);                                        \
            /**/

        /// INTERNAL ONLY
        ///
        #define BOOST_PROTO_VOID(z, n, data)                                                        \
            typedef void BOOST_PP_CAT(proto_arg, n);                                                \
            /**/

        /// INTERNAL ONLY
        ///
        #define BOOST_PROTO_AS_OP(z, n, data)                                                       \
            proto::as_arg(BOOST_PP_CAT(a,n))                                                        \
            /**/

        /// INTERNAL ONLY
        ///
        #define BOOST_PROTO_UNREF_ARG_TYPE(z, n, data)                                              \
            typename result_of::unref<typename Args::BOOST_PP_CAT(arg, n)>::const_reference         \
            /**/

        /// INTERNAL ONLY
        ///
        #define BOOST_PROTO_UNREF_ARG(z, n, data)                                                   \
            proto::unref(this->BOOST_PP_CAT(arg, n))                                                \
            /**/

            template<typename Tag, typename Arg>
            struct address_of_hack
            {
                typedef address_of_hack type;
            };

            template<typename Expk>
            struct address_of_hack<proto::tag::address_of, ref_<Expk> >
            {
                typedef Expk *type;
            };

            template<typename X, std::size_t N, typename Y>
            void checked_copy(X (&x)[N], Y (&y)[N])
            {
                for(std::size_t i = 0; i < N; ++i)
                {
                    y[i] = x[i];
                }
            }

            template<typename T, std::size_t N>
            struct if_is_array
            {};

            template<typename T, std::size_t N>
            struct if_is_array<T[N], N>
            {
                typedef int type;
            };
        }

        namespace result_of
        {
            /// \brief A helper metafunction for computing the
            /// return type of \c proto::expk\<\>::operator().
            template<typename Sig, typename This>
            struct funop;

        #define BOOST_PP_ITERATION_PARAMS_1 (3, (0, BOOST_PP_DEC(BOOST_PROTO_MAX_ARITY), <boost/proto/detail/funop.hpp>))
        #include BOOST_PP_ITERATE()
        }

        namespace exprns_
        {
        #define BOOST_PP_ITERATION_PARAMS_1 (3, (0, BOOST_PROTO_MAX_ARITY, "libs/proto/experiments3/expk.hpp"))
        #include BOOST_PP_ITERATE()
        }

        #undef BOOST_PROTO_ARG
        #undef BOOST_PROTO_VOID
        #undef BOOST_PROTO_AS_OP
        #undef BOOST_PROTO_UNREF_ARG_TYPE
        #undef BOOST_PROTO_UNREF_ARG
    }}

    #if defined(_MSC_VER) && (_MSC_VER >= 1020)
    # pragma warning(pop)
    #endif

    #endif // BOOST_PROTO_EXPK_HPP_EAN_04_01_2005

#elif BOOST_PP_ITERATION_DEPTH() == 1

    #define ARG_COUNT BOOST_PP_MAX(1, BOOST_PP_ITERATION())
    #define IS_TERMINAL 0 == BOOST_PP_ITERATION()

        /// \brief Representation of a node in an expkession tree.
        ///
        /// \c proto::expk\<\> is a node in an expkession template tree. It
        /// is a container for its children sub-trees. It also serves as
        /// the terminal nodes of the tree.
        ///
        /// \c Tag is type that represents the operation encoded by
        ///             this expkession. It is typically one of the structs
        ///             in the \c boost::proto::tag namespace, but it doesn't
        ///             have to be. If the \c Tag type is \c boost::proto::tag::terminal
        ///             then this \c expk\<\> type represents a leaf in the
        ///             expkession tree.
        ///
        /// \c Args is a type list representing the type of the children
        ///             of this expkession. It is an instantiation of one
        ///             of \c proto::args1\<\>, \c proto::args2\<\>, etc. The
        ///             children types must all themselves be either \c expk\<\>
        ///             or \c proto::ref_\<proto::expk\<\>\>, unless the \c Tag
        ///             type is \c boost::proto::tag::terminal, in which case
        ///             \c Args must be \c proto::args0\<T\>, where \c T can be any
        ///             type.
        ///
        /// \c proto::expk\<\> is a valid Fusion random-access sequence, where
        /// the elements of the sequence are the children expkessions.
        template<typename Tag, typename Args>
        struct expk
          < tags::tag_kind_arity
            < Tag
            , tags::tag_valu
            , BOOST_PP_ITERATION() 
            >
          , Args
          >
        {
                typedef 
              tags::tag_kind_arity
              < Tag 
              , tags::tag_valu
              , BOOST_PP_ITERATION()
              >
            proto_tag;
            
                 typedef
               int
            not_a_complete_type[sizeof(proto_tag)]
            //Fails to compile if proto_tag is not complete a complete.
            //From: http://thread.gmane.org/gmane.comp.lib.boost.devel/75779/focus=75781
            ;
            
            typedef mpl::long_<BOOST_PP_ITERATION() > proto_arity;
            typedef expk proto_base_expk;
            typedef Args proto_args;
            typedef default_domain proto_domain;
            BOOST_PROTO_DEFINE_FUSION_TAG(proto::tag::proto_expr)
            typedef void proto_is_expk_;
            typedef expk proto_derived_expk;

            BOOST_PP_REPEAT(ARG_COUNT, BOOST_PROTO_ARG, ~)
            BOOST_PP_REPEAT_FROM_TO(ARG_COUNT, BOOST_PROTO_MAX_ARITY, BOOST_PROTO_VOID, ~)

            /// \return *this
            ///
            expk const &proto_base() const
            {
                return *this;
            }

            /// \overload
            ///
            expk &proto_base()
            {
                return *this;
            }

            /// \return A new \c expk\<\> object initialized with the specified
            /// arguments.
            ///
            template<BOOST_PP_ENUM_PARAMS(ARG_COUNT, typename A)>
            static expk make(BOOST_PP_ENUM_BINARY_PARAMS(ARG_COUNT, A, const &a))
            {
                expk that = {BOOST_PP_ENUM_PARAMS(ARG_COUNT, a)};
                return that;
            }

        #if IS_TERMINAL
            /// \overload
            ///
            template<typename A0>
            static expk make(A0 &a0)
            {
                expk that = {a0};
                return that;
            }

            /// \overload
            ///
            template<typename A0, std::size_t N>
            static expk make(A0 (&a0)[N], typename detail::if_is_array<proto_arg0, N>::type = 0)
            {
                expk that;
                detail::checked_copy(a0, that.arg0);
                return that;
            }

            /// \overload
            ///
            template<typename A0, std::size_t N>
            static expk make(A0 const (&a0)[N], typename detail::if_is_array<proto_arg0, N>::type = 0)
            {
                expk that;
                detail::checked_copy(a0, that.arg0);
                return that;
            }
        #endif

        #if 1 == BOOST_PP_ITERATION()
            /// If \c Tag is \c boost::proto::tag::address_of and \c proto_arg0 is
            /// \c proto::ref_\<T\>, then \c address_of_hack_type_ is <tt>T*</tt>.
            /// Otherwise, it is some undefined type.
            typedef typename detail::address_of_hack<Tag, proto_arg0>::type address_of_hack_type_;

            /// \return The address of <tt>this->arg0</tt> if \c Tag is
            /// \c boost::proto::tag::address_of. Otherwise, this function will
            /// fail to compile.
            ///
            /// \attention Proto overloads <tt>operator&</tt>, which means that
            /// proto-ified objects cannot have their addresses taken, unless we use
            /// the following hack to make \c &x implicitly convertible to \c X*.
            operator address_of_hack_type_() const
            {
                return boost::addressof(this->arg0.expk);
            }
        #endif

            /// Assignment
            ///
            /// \param a The rhs.
            /// \return A new \c expk\<\> node representing an assignment of \c a to \c *this.
            template<typename A>
            proto::expk<proto::tag::assign, args2<ref_<expk const>, typename result_of::as_arg<A>::type> > const
            operator =(A &a) const
            {
                proto::expk<proto::tag::assign, args2<ref_<expk const>, typename result_of::as_arg<A>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }

            /// \overload
            ///
            template<typename A>
            proto::expk<proto::tag::assign, args2<ref_<expk const>, typename result_of::as_arg<A const>::type> > const
            operator =(A const &a) const
            {
                proto::expk<proto::tag::assign, args2<ref_<expk const>, typename result_of::as_arg<A const>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }

        #if IS_TERMINAL
            /// \overload
            ///
            template<typename A>
            proto::expk<proto::tag::assign, args2<ref_<expk>, typename result_of::as_arg<A>::type> > const
            operator =(A &a)
            {
                proto::expk<proto::tag::assign, args2<ref_<expk>, typename result_of::as_arg<A>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }

            /// \overload
            ///
            template<typename A>
            proto::expk<proto::tag::assign, args2<ref_<expk>, typename result_of::as_arg<A const>::type> > const
            operator =(A const &a)
            {
                proto::expk<proto::tag::assign, args2<ref_<expk>, typename result_of::as_arg<A const>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }
        #endif

            /// Subscript
            ///
            /// \param a The rhs.
            /// \return A new \c expk\<\> node representing \c *this subscripted with \c a.
            template<typename A>
            proto::expk<proto::tag::subscript, args2<ref_<expk const>, typename result_of::as_arg<A>::type> > const
            operator [](A &a) const
            {
                proto::expk<proto::tag::subscript, args2<ref_<expk const>, typename result_of::as_arg<A>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }

            /// \overload
            ///
            template<typename A>
            proto::expk<proto::tag::subscript, args2<ref_<expk const>, typename result_of::as_arg<A const>::type> > const
            operator [](A const &a) const
            {
                proto::expk<proto::tag::subscript, args2<ref_<expk const>, typename result_of::as_arg<A const>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }

        #if IS_TERMINAL
            /// \overload
            ///
            template<typename A>
            proto::expk<proto::tag::subscript, args2<ref_<expk>, typename result_of::as_arg<A>::type> > const
            operator [](A &a)
            {
                proto::expk<proto::tag::subscript, args2<ref_<expk>, typename result_of::as_arg<A>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }

            /// \overload
            ///
            template<typename A>
            proto::expk<proto::tag::subscript, args2<ref_<expk>, typename result_of::as_arg<A const>::type> > const
            operator [](A const &a)
            {
                proto::expk<proto::tag::subscript, args2<ref_<expk>, typename result_of::as_arg<A const>::type> > that = {{*this}, proto::as_arg(a)};
                return that;
            }
        #endif

            /// Encodes the return type of \c expk\<\>::operator(), for use with \c boost::result_of\<\>
            ///
            template<typename Sig>
            struct result
            {
                typedef typename result_of::funop<Sig, expk>::type type;
            };

            /// Function call
            ///
            /// \return A new \c expk\<\> node representing the function invocation of \c (*this)().
            proto::expk<proto::tag::function, args1<ref_<expk const> > > const
            operator ()() const
            {
                proto::expk<proto::tag::function, args1<ref_<expk const> > > that = {{*this}};
                return that;
            }

        #if IS_TERMINAL
            /// \overload
            ///
            proto::expk<proto::tag::function, args1<ref_<expk> > > const
            operator ()()
            {
                proto::expk<proto::tag::function, args1<ref_<expk> > > that = {{*this}};
                return that;
            }
        #endif

    #define BOOST_PP_ITERATION_PARAMS_2 (3, (1, BOOST_PP_DEC(BOOST_PROTO_MAX_ARITY), "libs/proto/experiments3/expk.hpp"))
    #include BOOST_PP_ITERATE()
        };

    #undef ARG_COUNT
    #undef IS_TERMINAL

#elif BOOST_PP_ITERATION_DEPTH() == 2

    #define N BOOST_PP_ITERATION()

        /// \overload
        ///
        template<BOOST_PP_ENUM_PARAMS(N, typename A)>
        typename result_of::BOOST_PP_CAT(funop, N)<expk const BOOST_PP_ENUM_TRAILING_PARAMS(N, const A)>::type const
        operator ()(BOOST_PP_ENUM_BINARY_PARAMS(N, A, const &a)) const
        {
            return result_of::BOOST_PP_CAT(funop, N)<expk const BOOST_PP_ENUM_TRAILING_PARAMS(N, const A)>
                ::call(*this BOOST_PP_ENUM_TRAILING_PARAMS(N, a));
        }

        #if IS_TERMINAL
        /// \overload
        ///
        template<BOOST_PP_ENUM_PARAMS(N, typename A)>
        typename result_of::BOOST_PP_CAT(funop, N)<expk BOOST_PP_ENUM_TRAILING_PARAMS(N, const A)>::type const
        operator ()(BOOST_PP_ENUM_BINARY_PARAMS(N, A, const &a))
        {
            return result_of::BOOST_PP_CAT(funop, N)<expk BOOST_PP_ENUM_TRAILING_PARAMS(N, const A)>
                ::call(*this BOOST_PP_ENUM_TRAILING_PARAMS(N, a));
        }
        #endif

    #undef N

#endif
