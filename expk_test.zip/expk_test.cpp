#include "expk.hpp"

namespace boost{namespace proto{namespace tags{

enum tags2_nums
{ tag2_shift_right
, tag2_bitwise_or
, tag2_cross_product
, tag2_disjoint_sum
, tag2_apply
};
template<tags2_nums>
struct tag2
{};

template<tags2_nums Tag2Num,tag_kinds TagKind, unsigned Arity>
struct tag_kind_arity<tag2<Tag2Num>,TagKind,Arity>
/// \brief
///   Disable all arities...
;
template<tags2_nums Tag2Num,tag_kinds TagKind>
struct tag_kind_arity<tag2<Tag2Num>,TagKind,2>
/// \brief
///   ...except 2 arity.
{
};
template<class Tag,int Arity>
struct fold
;
template<tags2_nums Tag2Num, tag_kinds TagKind, unsigned Arity>
struct fold<tag_kind_arity<tag2<Tag2Num>,TagKind,2>,Arity>
/**@brief
 *  The fold of binary operator, tag2<Tag2Num>, Arity times.
 *  If Arity==0, the result should be the unit element
 *  for binary operator. For example, for arithmetic
 *  times operator, the unit element is 1. For arithmetic
 *  plus operator, the unit element is 0.  If no such
 *  element exists, then Arity must be restricted to > 0.
 */
{};

}}}//exit boost::proto::tags

using namespace boost::proto;

typedef tags::tag_kind_arity<tags::tag2<tags::tag2_shift_right>,tags::tag_valu,2> tag_shift_right_2;
expk<tag_shift_right_2,args2<int,int> > shift_right_int_int={1,2};

typedef tags::tag_kind_arity<tags::tag2<tags::tag2_shift_right>,tags::tag_valu,1> tag_shift_right_1;
//tag_shift_right_1 shift_right_1_valu;//should fail to compile.
//expk<tag_shift_right_1,args1<int> > shift_right_int;//fails to compile.



