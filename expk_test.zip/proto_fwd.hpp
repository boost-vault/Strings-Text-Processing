#ifndef EXPERIMENTS3_PREOTO_FWD_HPP
#define EXPERIMENTS3_PREOTO_FWD_HPP
#include <boost/proto/proto_fwd.hpp>
namespace boost{namespace proto{

    namespace exprns_
    {
        template<typename Tag, typename Args>
        struct expk;
    }
    
    using exprns_::expk;
    
}}//exit boost::proto namespace
#endif
